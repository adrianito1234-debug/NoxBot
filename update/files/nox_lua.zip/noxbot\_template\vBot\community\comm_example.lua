--[[
  ═══ PLANTILLA NoxBot Scripts (comunidad) ═══
  1. Copia este archivo → community/mi_script.lua
  2. Añade entrada en community/_manifest.lua (mismo id)
  3. El .lua NO se ejecuta hasta que el usuario activa el switch (o ya estaba ON al login)

  Reglas anti-lag:
  - Nada pesado fuera de noxCommunityScript(...)
  - macros/hooks solo dentro; siempre comprobar config.enabled
  - preferir macro(500+) en lugar de macro(10) salvo necesidad
]]

noxCommunityScript(function(config)
  if type(config.note) ~= "string" then
    config.note = "Plantilla — edita community/comm_example.lua"
  end

  -- Ejemplo: macro liviano (no corre lógica si está OFF)
  macro(1000, function()
    if not config.enabled then return end
    -- tu lógica aquí
  end)
end)
