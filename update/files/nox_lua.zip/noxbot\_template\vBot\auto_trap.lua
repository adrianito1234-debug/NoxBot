if type(setDefaultTab) ~= "function" then function setDefaultTab(name) end end
setDefaultTab("Tools")

local TRAP_IDLE = 3481
local TRAP_ARMED = 3482
local DEPLOY_RANGE = 2
local KEEP_RANGE = 5
local ACTION_DELAY = 350

local STEP = {
  [0] = {0, -1},
  [1] = {1, 0},
  [2] = {0, 1},
  [3] = {-1, 0},
  [4] = {1, -1},
  [5] = {1, 1},
  [6] = {-1, 1},
  [7] = {-1, -1}
}

local autoTrap = addToggle("autoTrap", "Auto Trap")

local nextAction = 0

local function isTrapId(itemId)
  return itemId == TRAP_IDLE or itemId == TRAP_ARMED
end

local function samePos(a, b)
  return a.x == b.x and a.y == b.y and a.z == b.z
end

local function reachableTiles(playerPos)
  local tiles = {}
  local myTile = g_map.getTile(playerPos)

  if myTile then
    table.insert(tiles, myTile)
  end

  for _, tile in ipairs(getNearTiles(playerPos)) do
    table.insert(tiles, tile)
  end

  return tiles
end

local function findTrapOnGround(playerPos)
  for _, tile in ipairs(reachableTiles(playerPos)) do
    local trap = nil

    for _, item in ipairs(tile:getItems()) do
      if isTrapId(item:getId()) then
        trap = item
      end
    end

    if trap then
      local top = tile:getTopMoveThing()
      local cover = nil

      if top and top:isItem() and not isTrapId(top:getId()) and not top:isNotMoveable() then
        cover = top
      end

      return trap, cover, tile:getPosition()
    end
  end
end

local function spareTile(playerPos, trapPos)
  for _, tile in ipairs(getNearTiles(trapPos)) do
    local tilePos = tile:getPosition()

    if tile:isWalkable() and not tile:hasCreature() and not samePos(tilePos, playerPos) then
      return tilePos
    end
  end
end

local function freeSlot()
  for _, container in pairs(getContainers()) do
    if not container.lootContainer and container:getItemsCount() < container:getCapacity() then
      return container:getSlotPosition(container:getItemsCount())
    end
  end
end

local function closestMonster(playerPos)
  local closest, closestDist = nil, nil

  for _, spec in ipairs(getSpectators()) do
    if spec:isMonster() and (g_game.getClientVersion() < 960 or spec:getType() < 3) then
      local dist = getDistanceBetween(playerPos, spec:getPosition())

      if dist <= DEPLOY_RANGE and (not closestDist or dist < closestDist) then
        closest, closestDist = spec, dist
      end
    end
  end

  return closest
end

local function nextMonsterStep(playerPos)
  local monster = closestMonster(playerPos)
  if not monster then return nil end

  local monsterPos = monster:getPosition()
  local path = findPath(monsterPos, playerPos, 8, { precision = 1 })
  if not path or not path[1] then return nil end

  local step = STEP[path[1]]
  if not step then return nil end

  local stepPos = { x = monsterPos.x + step[1], y = monsterPos.y + step[2], z = monsterPos.z }
  if getDistanceBetween(playerPos, stepPos) > 1 then return nil end

  local tile = g_map.getTile(stepPos)
  if not tile or not tile:isWalkable() or tile:hasCreature() then return nil end

  return stepPos
end

local function trapTarget(playerPos)
  return nextMonsterStep(playerPos) or playerPos
end

macro(200, function()
  if not autoTrap.enabled then return end
  if now < nextAction then return end

  local playerPos = player:getPosition()
  if not playerPos then return end

  local trap, cover, trapPos = findTrapOnGround(playerPos)

  if trap and cover then
    local dest = spareTile(playerPos, trapPos)
    if not dest then return end

    g_game.move(cover, dest, cover:getCount())
    nextAction = now + ACTION_DELAY
    return
  end

  if trap then
    if getMonsters(KEEP_RANGE) == 0 then
      local slot = freeSlot()
      if not slot then return end

      g_game.move(trap, slot, 1)
      nextAction = now + ACTION_DELAY
      return
    end

    if trap:getId() == TRAP_ARMED then return end

    local target = trapTarget(playerPos)

    if not samePos(trapPos, target) then
      g_game.move(trap, target, 1)
      nextAction = now + ACTION_DELAY
      return
    end

    use(trap)
    nextAction = now + ACTION_DELAY
    return
  end

  if getMonsters(DEPLOY_RANGE) == 0 then return end

  local storedTrap = findItem(TRAP_IDLE) or findItem(TRAP_ARMED)
  if not storedTrap then return end

  g_game.move(storedTrap, trapTarget(playerPos), 1)
  nextAction = now + ACTION_DELAY
end)
