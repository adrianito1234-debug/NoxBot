-- NoxBot Private Script: Spells Single Multi
noxCommunityScript(function(config)
  if type(config.enabled) ~= "boolean" then config.enabled = false end

local singleTargetSpell = 'Barrier'
local multiTargetSpell = 'Ki Repulsion'
local distance = 3
local amountOfMonsters = 2
local manaPercent = 20
local hpPercent = 20

local yv=macro(250, "Spells Single Multi",  function()
    local specAmount = 0
    if not g_game.isAttacking() then
        return
    end
    for i,mob in ipairs(getSpectators()) do
        if (getDistanceBetween(player:getPosition(), mob:getPosition()) <= distance and mob:isMonster()) then
            specAmount = specAmount + 1
        end
    end
    if (specAmount >= amountOfMonsters) then
        if (manapercent() >= config.manaPercent) and (hppercent() >= config.hpPercent) then
            say(config.multiTargetSpell)
        end
    else
        if (manapercent() >= config.manaPercent) and (hppercent() >= config.hpPercent) then
            say(config.singleTargetSpell)
        end
    end
end)
local ICON_ID = 13414 -- id ikony
addIcon("nazwa ikony", {item={id = ICON_ID}, movable=true}, function(icon, isOn)
  yv.setOn(isOn) 
end)
UI.Label("Single Target Spell:")
UI.TextEdit(config.singleTargetSpell or "Barrier", function(widget, text)
    config.singleTargetSpell = text
end)

UI.Label("Multi Target Spell:")
UI.TextEdit(config.multiTargetSpell or "Ki Repulsion", function(widget, text)
    config.multiTargetSpell = text
end)

UI.Label("Mana Percent:")
UI.TextEdit(tostring(config.manaPercent or 20), function(widget, text)
    config.manaPercent = tonumber(text)
end)

UI.Label("HP Percent:")
UI.TextEdit(tostring(config.hpPercent or 20), function(widget, text)
    config.hpPercent = tonumber(text)
end)

UI.Separator()
end)