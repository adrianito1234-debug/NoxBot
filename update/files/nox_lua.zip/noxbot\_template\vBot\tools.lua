-- tools tab
setDefaultTab("Tools")

if type(storage.moneyItems) ~= "table" then
  storage.moneyItems = {3031, 3035}
end
if type(noxAsList) == "function" then
  storage.moneyItems = noxAsList(storage.moneyItems)
end
macro(1000, "Exchange money", function()
  if not storage.moneyItems[1] then return end
  local containers = g_game.getContainers()
  for index, container in pairs(containers) do
    if not container.lootContainer then -- ignore monster containers
      for i, item in ipairs(container:getItems()) do
        if item:getCount() == 100 then
          for m, moneyId in ipairs(storage.moneyItems) do
            local id = noxItemId and noxItemId(moneyId) or (type(moneyId) == "table" and moneyId.id or moneyId)
            if id and item:getId() == id then
              return g_game.use(item)
            end
          end
        end
      end
    end
  end
end)

local moneyContainer = UI.Container(function(widget, items)
  storage.moneyItems = items
end, true)
moneyContainer:setHeight(35)
moneyContainer:setItems(storage.moneyItems)

UI.Separator()

macro(60000, "Send message on trade", function()
  local trade = getChannelId("advertising")
  if not trade then
    trade = getChannelId("trade")
  end
  local msg = storage.autoTradeMessage
  if trade and type(msg) == "string" and msg:len() > 0 then
    sayChannel(trade, msg)
  end
end)
if not storage.autoTradeMessage or storage.autoTradeMessage == "I'm using NoxBot" then
  storage.autoTradeMessage = "I'm using NoxBot"
end
UI.TextEdit(storage.autoTradeMessage, function(widget, text)
  storage.autoTradeMessage = text
end)

UI.Separator()
