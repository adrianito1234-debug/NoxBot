-- NoxBot Private Script: Dolar Change
noxCommunityScript(function(config)
  if type(config.enabled) ~= "boolean" then config.enabled = false end

local moneyIds = {3031, 3035, 3043} -- Zeni, Dollar, Gold ingot
macro(1000, "Dolar Change", function()
  local containers = g_game.getContainers()
  for index, container in pairs(containers) do
    if not container.lootContainer then -- ignore monster containers
      for i, item in ipairs(container:getItems()) do
        if item:getCount() == 100 then
          for m, moneyId in ipairs(moneyIds) do
            if item:getId() == moneyId then
              return g_game.use(item)           
            end
          end
        end
      end
    end
  end
end)
end)