local probe = context and context.OpcodeProbe
if not probe then
  return
end

setDefaultTab("Tools")

local ui = setupUI([[
Panel
  height: 54

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    text-align: center
    !text: tr('Opcode Extractor')

  Label
    id: status
    anchors.top: title.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    text-align: center
    text: idle
    font: verdana-11px-rounded

  Button
    id: openFolder
    anchors.top: status.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 18
    text: Open output folder
    visible: false
]])
ui:setId("opcodeExtractor")

local function refresh()
  local st = probe.getStatus()
  if st.active then
    ui.status:setText("REC  S->C:" .. st.sc .. "  EXT:" .. st.ext .. "  API:" .. st.api)
    ui.openFolder:setVisible(st.dir ~= nil)
  else
    ui.status:setText("idle")
    ui.openFolder:setVisible(false)
  end
end

ui.title.onClick = function(widget)
  local on = not widget:isOn()
  widget:setOn(on)
  if on then
    if not probe.start() then
      widget:setOn(false)
      ui.status:setText("could not start (no write dir)")
      return
    end
  else
    probe.stop()
  end
  refresh()
end

ui.openFolder.onClick = function()
  local st = probe.getStatus()
  if st.dir and g_platform and g_platform.openDir then
    pcall(g_platform.openDir, st.dir)
  end
end

macro(1000, function()
  if probe.isActive() then
    refresh()
  end
end)

refresh()
