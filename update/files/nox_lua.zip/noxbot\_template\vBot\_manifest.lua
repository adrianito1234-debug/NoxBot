-- NoxBot Private Scripts manifest (auto-generated)
return {
  { id = "comm_zz2pot1spell_cooldown", title = "2Pot1spell Cooldown", kind = "toggle"
 },
  { id = "comm_zz2spellscooldown", title = "2Spellscooldown", kind = "toggle"
 },
  { id = "comm_zzzadvlure", title = "Advlure", kind = "toggle"
 },
  { id = "comm_zafk", title = "Afk", kind = "toggle"
 },
  { id = "comm_zalert_custommsg", title = "Alert Custommsg", kind = "toggle"
 },
  { id = "comm_alert_vip_login", title = "Alert Vip Login", kind = "toggle"
 },
  { id = "comm_zzalertacustommsg", title = "Alertacustommsg", kind = "toggle"
 },
  { id = "comm_zzalertalowsupplies", title = "Alertalowsupplies", kind = "toggle"
 },
  { id = "comm_zzalertaplayerattacked", title = "Alertaplayerattacked", kind = "toggle"
 },
  { id = "comm_zzalertaskull", title = "Alertaskull", kind = "toggle"
 },
  { id = "comm_zantipush", title = "Antipush", kind = "maker"
, window = "CommzantipushWindow", button = "Setup"
 },
  { id = "comm_zatk_anti_reflect", title = "Atk Anti Reflect", kind = "toggle"
 },
  { id = "comm_zatk_facetarget", title = "Atk Facetarget", kind = "toggle"
 },
  { id = "comm_zatk_noks", title = "Atk Noks", kind = "toggle"
 },
  { id = "comm_zatk_safeaoe_simple", title = "Atk Safeaoe Simple", kind = "toggle"
 },
  { id = "comm_zatk_speller", title = "Atk Speller", kind = "toggle"
 },
  { id = "comm_zatk_target_icon_hold", title = "Atk Target Icon Hold", kind = "toggle"
 },
  { id = "comm_zatk_target_icon_use", title = "Atk Target Icon Use", kind = "toggle"
 },
  { id = "comm_zatk_target_rune_icon", title = "Atk Target Rune Icon", kind = "toggle"
 },
  { id = "comm_aura", title = "Aura", kind = "toggle"
 },
  { id = "comm_z_auto_party", title = "Auto Party", kind = "maker"
, window = "Commz_auto_partyWindow", button = "Setup"
 },
  { id = "comm_zautobuff", title = "Autobuff", kind = "maker"
, window = "CommzautobuffWindow", button = "Setup"
 },
  { id = "comm_zzautoclosefyi", title = "Autoclosefyi", kind = "toggle"
 },
  { id = "comm_zzzautoenterevent", title = "Autoenterevent", kind = "toggle"
 },
  { id = "comm_zzautoequiphpmp", title = "Autoequiphpmp", kind = "maker"
, window = "CommzzautoequiphpmpWindow", button = "Setup"
 },
  { id = "comm_zzautoequipmobile", title = "Autoequipmobile", kind = "toggle"
 },
  { id = "comm_autoexplorer", title = "Autoexplorer", kind = "toggle"
 },
  { id = "comm_autojump", title = "Autojump", kind = "toggle"
 },
  { id = "comm_zautologout", title = "Autologout", kind = "toggle"
 },
  { id = "comm_autoloot_add", title = "Autoloot Add", kind = "toggle"
 },
  { id = "comm_zzautowaveenemy", title = "Autowaveenemy", kind = "toggle"
 },
  { id = "comm_zzavoiditems", title = "Avoiditems", kind = "toggle"
 },
  { id = "comm_zzavoidpositions_top", title = "Avoidpositions Top", kind = "toggle"
 },
  { id = "comm_zzbancast", title = "Bancast", kind = "toggle"
 },
  { id = "comm_zzbombtarget", title = "Bombtarget", kind = "toggle"
 },
  { id = "comm_zzbossspellandantistuck", title = "Bossspellandantistuck", kind = "toggle"
 },
  { id = "comm_yybosstimer", title = "Bosstimer", kind = "toggle"
 },
  { id = "comm_cave_target_on_off", title = "Cave Target On Off", kind = "toggle"
 },
  { id = "comm_zzcheckpartymembers", title = "Checkpartymembers", kind = "toggle"
 },
  { id = "comm_zzclickreuse", title = "Clickreuse", kind = "toggle"
 },
  { id = "comm_zzconjurecheckamount", title = "Conjurecheckamount", kind = "toggle"
 },
  { id = "comm_zcont_orderitems", title = "Cont Orderitems", kind = "toggle"
 },
  { id = "comm_zzcontainernextpage", title = "Containernextpage", kind = "toggle"
 },
  { id = "comm_zcustom_tradeoff", title = "Custom Tradeoff", kind = "toggle"
 },
  { id = "comm_zcustommsgalarm", title = "Custommsgalarm", kind = "toggle"
 },
  { id = "comm_zzcustomspellattack", title = "Customspellattack", kind = "toggle"
 },
  { id = "comm_zzdash_bugmap", title = "Dash Bugmap", kind = "toggle"
 },
  { id = "comm_dolar_change", title = "Dolar Change", kind = "toggle"
 },
  { id = "comm_yydropitemsonfeet", title = "Dropitemsonfeet", kind = "toggle"
 },
  { id = "comm_zzdrunkchecker", title = "Drunkchecker", kind = "toggle"
 },
  { id = "comm_zequip_enchanted", title = "Equip Enchanted", kind = "toggle"
 },
  { id = "comm_zescondertudo", title = "Escondertudo", kind = "toggle"
 },
  { id = "comm_zfightback", title = "Fightback", kind = "maker"
, window = "CommzfightbackWindow", button = "Setup"
 },
  { id = "comm_zzfishing", title = "Fishing", kind = "toggle"
 },
  { id = "comm_zzfullruna", title = "Fullruna", kind = "toggle"
 },
  { id = "comm_zzgetoutfit", title = "Getoutfit", kind = "toggle"
 },
  { id = "comm_zzholdflower", title = "Holdflower", kind = "toggle"
 },
  { id = "comm_zzholdposition", title = "Holdposition", kind = "toggle"
 },
  { id = "comm_yyhouserefill", title = "Houserefill", kind = "toggle"
 },
  { id = "comm_yyhouserefill_adv", title = "Houserefill Adv", kind = "toggle"
 },
  { id = "comm_zzhousetraining", title = "Housetraining", kind = "toggle"
 },
  { id = "comm_hunt_anti_invisible", title = "Hunt Anti Invisible", kind = "toggle"
 },
  { id = "comm_icon_countattackers", title = "Icon Countattackers", kind = "toggle"
 },
  { id = "comm_zzzziconconstructor", title = "Iconconstructor", kind = "toggle"
 },
  { id = "comm_zjump", title = "Jump", kind = "toggle"
 },
  { id = "comm_zkina_advlure", title = "Kina Advlure", kind = "toggle"
 },
  { id = "comm_zloot_freeitems_simple", title = "Loot Freeitems Simple", kind = "toggle"
 },
  { id = "comm_zzluremonsters", title = "Luremonsters", kind = "toggle"
 },
  { id = "comm_zzluresimple", title = "Luresimple", kind = "toggle"
 },
  { id = "comm_zmaker_multispell", title = "Maker Multispell", kind = "maker"
, window = "Commzmaker_multispellWindow", button = "Setup"
 },
  { id = "comm_zmaker_vocation", title = "Maker Vocation", kind = "maker"
, window = "Commzmaker_vocationWindow", button = "Setup"
 },
  { id = "comm_zmisc_bossrewardchest", title = "Misc Bossrewardchest", kind = "toggle"
 },
  { id = "comm_zmisc_listitems_byvivo", title = "Misc Listitems Byvivo", kind = "toggle"
 },
  { id = "comm_zmisc_spy", title = "Misc Spy", kind = "toggle"
 },
  { id = "comm_zmisc_superdash", title = "Misc Superdash", kind = "toggle"
 },
  { id = "comm_zmisc_toggleicons_cave_tgt", title = "Misc Toggleicons Cave Tgt", kind = "toggle"
 },
  { id = "comm_zmorreu", title = "Morreu", kind = "toggle"
 },
  { id = "comm_zzmovepouch", title = "Movepouch", kind = "toggle"
 },
  { id = "comm_zznewlure", title = "Newlure", kind = "toggle"
 },
  { id = "comm_open_next_bag", title = "Open Next Bag", kind = "toggle"
 },
  { id = "comm_zoutfit_encomenda", title = "Outfit Encomenda", kind = "toggle"
 },
  { id = "comm_zpally_conjured_arrow", title = "Pally Conjured Arrow", kind = "toggle"
 },
  { id = "comm_paralize", title = "Paralize", kind = "toggle"
 },
  { id = "comm_zparceltarget_top", title = "Parceltarget Top", kind = "toggle"
 },
  { id = "comm_zpartyrefill", title = "Partyrefill", kind = "toggle"
 },
  { id = "comm_zzpausecavexmonsters", title = "Pausecavexmonsters", kind = "toggle"
 },
  { id = "comm_zzplayerattack", title = "Playerattack", kind = "toggle"
 },
  { id = "comm_zzptpassleader", title = "Ptpassleader", kind = "toggle"
 },
  { id = "comm_zpvp_8pot_simple", title = "Pvp 8Pot Simple", kind = "toggle"
 },
  { id = "comm_zpvp_antipush_simple", title = "Pvp Antipush Simple", kind = "toggle"
 },
  { id = "comm_zpvp_pot_mousepos", title = "Pvp Pot Mousepos", kind = "toggle"
 },
  { id = "comm_zpvp_ssa_aol_mouse", title = "Pvp Ssa Aol Mouse", kind = "toggle"
 },
  { id = "comm_zzquivernextpage", title = "Quivernextpage", kind = "toggle"
 },
  { id = "comm_zzrandomchests", title = "Randomchests", kind = "toggle"
 },
  { id = "comm_zzreset_getlevelonpanel", title = "Reset Getlevelonpanel", kind = "toggle"
 },
  { id = "comm_zrunemaker_house", title = "Runemaker House", kind = "toggle"
 },
  { id = "comm_zrunemaker_trainer", title = "Runemaker Trainer", kind = "toggle"
 },
  { id = "comm_zzrunemakeroldversion", title = "Runemakeroldversion", kind = "toggle"
 },
  { id = "comm_zzruneontargetcomicon", title = "Runeontargetcomicon", kind = "toggle"
 },
  { id = "comm_zzsafeaoerune", title = "Safeaoerune", kind = "toggle"
 },
  { id = "comm_zzsafeaoespell_targeted", title = "Safeaoespell Targeted", kind = "toggle"
 },
  { id = "comm_zzsafespell_target_icon", title = "Safespell Target Icon", kind = "toggle"
 },
  { id = "comm_screenshotondeath", title = "Screenshotondeath", kind = "toggle"
 },
  { id = "comm_sense", title = "Sense", kind = "toggle"
 },
  { id = "comm_simple_e_ring", title = "Simple E Ring", kind = "toggle"
 },
  { id = "comm_yysimplecheckstamina", title = "Simplecheckstamina", kind = "toggle"
 },
  { id = "comm_zzsimplepartyaccept", title = "Simplepartyaccept", kind = "toggle"
 },
  { id = "comm_yysimplereopenbp", title = "Simplereopenbp", kind = "toggle"
 },
  { id = "comm_zzsimplesortitems", title = "Simplesortitems", kind = "toggle"
 },
  { id = "comm_zzsimplespellcooldown", title = "Simplespellcooldown", kind = "toggle"
 },
  { id = "comm_zzsimpletogglebot", title = "Simpletogglebot", kind = "toggle"
 },
  { id = "comm_zzsmartautoattack", title = "Smartautoattack", kind = "toggle"
 },
  { id = "comm_zzsortitems_advanced", title = "Sortitems Advanced", kind = "maker"
, window = "Commzzsortitems_advancedWindow", button = "Setup"
 },
  { id = "comm_zzsortitemsesell", title = "Sortitemsesell", kind = "maker"
, window = "CommzzsortitemsesellWindow", button = "Setup"
 },
  { id = "comm_zzspellbytargethp", title = "Spellbytargethp", kind = "toggle"
 },
  { id = "comm_spells_cooldown", title = "Spells Cooldown", kind = "toggle"
 },
  { id = "comm_spells_single_multi", title = "Spells Single Multi", kind = "toggle"
 },
  { id = "comm_zzstaminarefill", title = "Staminarefill", kind = "toggle"
 },
  { id = "comm_zzstaminarefillsimple", title = "Staminarefillsimple", kind = "toggle"
 },
  { id = "comm_yysupplycheck", title = "Supplycheck", kind = "toggle"
 },
  { id = "comm_ztasker", title = "Tasker", kind = "toggle"
 },
  { id = "comm_ztasker_arinar", title = "Tasker Arinar", kind = "toggle"
 },
  { id = "comm_zzztoploginnext", title = "Toploginnext", kind = "toggle"
 },
  { id = "comm_ztraptarget", title = "Traptarget", kind = "toggle"
 },
  { id = "comm_zzuhandsd", title = "Uhandsd", kind = "toggle"
 },
  { id = "comm_zui_autoclosewindow", title = "Ui Autoclosewindow", kind = "toggle"
 },
  { id = "comm_zzunstackitems", title = "Unstackitems", kind = "toggle"
 },
  { id = "comm_zzuseitemdelay", title = "Useitemdelay", kind = "toggle"
 },
  { id = "comm_zzuseitemonground", title = "Useitemonground", kind = "toggle"
 },
  { id = "comm_zzuseitemonplayer", title = "Useitemonplayer", kind = "toggle"
 },
  { id = "comm_zzusewithonground", title = "Usewithonground", kind = "toggle"
 },
  { id = "comm_yyusewithonground_oldrope", title = "Usewithonground Oldrope", kind = "toggle"
 },
  { id = "comm_zzwalkintoid", title = "Walkintoid", kind = "toggle"
 },
  { id = "comm_wave_spell", title = "Wave Spell", kind = "toggle"
 },
  { id = "comm_zzxmonsterlevel", title = "Xmonsterlevel", kind = "toggle"
 },
}
