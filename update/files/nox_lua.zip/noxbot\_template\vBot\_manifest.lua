-- NoxBot Private Scripts (lazy load)
return {
  { id = "comm_auto_follow", title = "Auto Follow", kind = "toggle" },
}
