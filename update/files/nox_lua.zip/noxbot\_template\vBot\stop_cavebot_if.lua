setDefaultTab("Cave")

local config, window = addMaker("stopCavebotIf", "Stop Cavebot if", "StopCavebotIfWindow", "Setup")

if type(config.manaEnabled) ~= "boolean" then
  config.manaEnabled = false
end
if type(config.manaPercent) ~= "number" then
  config.manaPercent = 30
end
if type(config.suppliesEnabled) ~= "boolean" then
  config.suppliesEnabled = false
end
if type(config.staminaEnabled) ~= "boolean" then
  config.staminaEnabled = false
end
if type(config.staminaValue) ~= "string" then
  config.staminaValue = "40:00"
end
if type(config.logoutEnabled) ~= "boolean" then
  config.logoutEnabled = false
end
if type(config.staminaMaxSeen) ~= "number" then
  config.staminaMaxSeen = 0
end

bindSwitch(window.manaEnabled, config, "manaEnabled")
bindSwitch(window.suppliesEnabled, config, "suppliesEnabled")
bindSwitch(window.staminaEnabled, config, "staminaEnabled")
bindSwitch(window.logoutEnabled, config, "logoutEnabled")

window.manaPercent:setValue(config.manaPercent)
window.manaPercent.onValueChange = function(widget, value)
  config.manaPercent = value
end

window.staminaValue:setText(config.staminaValue)
window.staminaValue.onTextChange = function(widget, text)
  local cleaned = text:gsub("[^0-9:]", "")
  if cleaned ~= text then
    widget:setText(cleaned)
    return
  end
  config.staminaValue = cleaned
end

local function parseStaminaThreshold(text)
  local hours, minutes = tostring(text or ""):match("^(%d+):(%d+)$")
  if not hours or not minutes then
    return nil
  end

  return tonumber(hours) * 60 + tonumber(minutes)
end

local stoppedByModule = false
local lastLogoutAttempt = 0

local function runLogout()
  if now - lastLogoutAttempt < 5000 then
    return
  end
  lastLogoutAttempt = now
  modules.game_interface.tryLogout(false)
end

macro(500, function()
  local caveOn = false
  if type(CaveBot) == "table" and type(CaveBot.isOn) == "function" then
    caveOn = CaveBot.isOn()
  end
  if caveOn then
    if not config.enabled then
      return
    end

    local currentStamina = stamina()
    if currentStamina > config.staminaMaxSeen then
      config.staminaMaxSeen = currentStamina
    end

    local reason = nil

    if config.manaEnabled and manapercent() < config.manaPercent then
      reason = "mana below " .. config.manaPercent .. "%"
    end

    if not reason and config.suppliesEnabled and Supplies and Supplies.hasEnough then
      local supplyData = Supplies.hasEnough()
      if type(supplyData) == "table" then
        reason = "supplies below minimum (item " .. supplyData.id .. ")"
      end
    end

    if not reason and config.staminaEnabled and config.staminaMaxSeen > 0 then
      local threshold = parseStaminaThreshold(config.staminaValue)
      if threshold and currentStamina < threshold then
        reason = "stamina below " .. config.staminaValue
      end
    end

    if reason then
      print("[Stop Cavebot if] " .. reason)
      if type(CaveBot.setOff) == "function" then CaveBot.setOff() end
      stoppedByModule = true
    end

    return
  end

  if not config.enabled or not config.logoutEnabled or not stoppedByModule then
    return
  end

  if isPzLocked() then
    return
  end

  print("[Stop Cavebot if] Cavebot off and PZ lost, logging out")
  stoppedByModule = false
  runLogout()
end)
