local tracked = {}

local function chebyshev(a, b)
  return math.max(math.abs(a.x - b.x), math.abs(a.y - b.y))
end

local function isFacingMe(creature, cpos, ppos)
  local dir = creature:getDirection()
  local dx = ppos.x - cpos.x
  local dy = ppos.y - cpos.y
  if dir == 0 then return dy < 0 end
  if dir == 1 then return dx > 0 end
  if dir == 2 then return dy > 0 end
  if dir == 3 then return dx < 0 end
  if dir == 4 then return dx > 0 and dy < 0 end
  if dir == 5 then return dx > 0 and dy > 0 end
  if dir == 6 then return dx < 0 and dy > 0 end
  if dir == 7 then return dx < 0 and dy < 0 end
  return false
end

local ui = setupUI([[
Panel
  height: 36

  BotSwitch
    id: title
    anchors.fill: parent
    text-align: center
    text-wrap: true
]])
ui:setId("ignoreNotTargeting")
ui.title:setText("Ignore mobs that aren't targeting me")

if storage.ignoreNotTargetingMe == nil then
  storage.ignoreNotTargetingMe = false
end

ui.title:setOn(storage.ignoreNotTargetingMe)
ui.title.onClick = function(widget)
  storage.ignoreNotTargetingMe = not storage.ignoreNotTargetingMe
  widget:setOn(storage.ignoreNotTargetingMe)
  tracked = {}
end

local function markMine(id, dist)
  local entry = tracked[id]
  if not entry then
    entry = {lastDist = dist, closing = 0, facingStreak = 0}
    tracked[id] = entry
  end
  entry.mine = true
  entry.seen = now
end

macro(150, function()
  if not storage.ignoreNotTargetingMe then return end
  local ppos = player:getPosition()
  if not ppos then return end
  local attacking = g_game.getAttackingCreature()
  local attackingId = attacking and attacking:getId() or nil
  for _, spec in ipairs(g_map.getSpectatorsInRange(ppos, false, 8, 8)) do
    if spec:isMonster() then
      local id = spec:getId()
      local cpos = spec:getPosition()
      local dist = chebyshev(cpos, ppos)
      local entry = tracked[id]
      if not entry then
        entry = {lastDist = dist, closing = 0, facingStreak = 0}
        tracked[id] = entry
      end
      if dist < entry.lastDist then
        entry.closing = math.min(entry.closing + 1, 4)
      elseif dist > entry.lastDist then
        entry.closing = math.max(entry.closing - 1, -4)
      end
      entry.lastDist = dist
      if isFacingMe(spec, cpos, ppos) then
        entry.facingStreak = entry.facingStreak + 1
      else
        entry.facingStreak = 0
      end
      if id == attackingId or dist <= 1 then
        entry.mine = true
      end
      entry.seen = now
    end
  end
  for id, entry in pairs(tracked) do
    if not entry.seen or now - entry.seen > 5000 then
      tracked[id] = nil
    end
  end
end)

onMissle(function(missle)
  if not storage.ignoreNotTargetingMe then return end
  local ppos = player:getPosition()
  if not ppos then return end
  local src = missle:getSource()
  if src.z ~= ppos.z then return end
  if chebyshev(missle:getDestination(), ppos) > 1 then return end
  local tile = g_map.getTile(src)
  if not tile then return end
  local creatures = tile:getCreatures()
  if not creatures then return end
  for _, c in ipairs(creatures) do
    if c:isMonster() then
      markMine(c:getId(), chebyshev(src, ppos))
    end
  end
end)

TargetBot.isCreatureIgnored = function(creature)
  if not storage.ignoreNotTargetingMe then return false end
  if not creature:isMonster() then return false end
  local entry = tracked[creature:getId()]
  return not (entry and entry.mine)
end

TargetBot.isCorpseContested = function(pos)
  if not pos then return false end
  for _, sp in ipairs(g_map.getSpectatorsInRange(pos, false, 1, 1)) do
    if sp:isPlayer() and not sp:isLocalPlayer() then
      return true
    end
  end
  return false
end
