setDefaultTab("Jitter")

UI.Separator()
UI.Label("Input")
UI.Separator()

local panelName = "simulator"
local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    text-align: center
    width: 130
    !text: tr('Simulator')

  Button
    id: edit
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 3
    height: 17
    text: Setup
]])
ui:setId(panelName)

local function engineConfig()
  if context.InputSim then
    return context.InputSim.getConfig()
  end
  if type(context.storage.simulator) ~= "table" then
    context.storage.simulator = { enabled = false }
  end
  return context.storage.simulator
end

local function syncSimulatorStorage()
  local cfg = engineConfig()
  if context.InputSim then
    context.InputSim.setEnabled(cfg.enabled == true)
  elseif type(context.storage.simulator) == "table" then
    context.storage.simulator.enabled = cfg.enabled == true
  end
  if saveConfig then
    saveConfig()
  end
end

local cfg = engineConfig()
if type(cfg.enabled) ~= "boolean" then
  cfg.enabled = false
end

ui.title:setOn(cfg.enabled)
ui.title.onClick = function(widget)
  cfg.enabled = not widget:isOn()
  widget:setOn(cfg.enabled)
  syncSimulatorStorage()
end

ui.edit.onClick = function()
  if context.Simulator and context.Simulator.showSettings then
    context.Simulator.showSettings()
  else
    warn("Simulator settings are loaded from GameBot (restart bot if Edit is unavailable).")
  end
end

if context.InputSim and context.InputSim.registerUiStateGetter then
  context.InputSim.registerUiStateGetter(function()
    local sw = ui.title
    if not sw then
      return nil
    end
    return sw:isOn() == true
  end)
end

macro(400, function()
  if not context.InputSim then
    return
  end
  context.InputSim.syncCamStreamFlag()
end)

syncSimulatorStorage()

Simulator = context.Simulator
