-- NoxBot Private Script: Hold Position
noxCommunityScript(function(config)
  if type(config.enabled) ~= "boolean" then config.enabled = false end

  local holdPos = nil

  -- Macro sin nombre: arranca ON y solo mira config.enabled (toggle Private Scripts)
  macro(100, function()
    if not config.enabled then
      holdPos = nil
      return
    end

    local p = player:getPosition()
    if not holdPos then
      holdPos = { x = p.x, y = p.y, z = p.z }
      return
    end

    if p.x == holdPos.x and p.y == holdPos.y and p.z == holdPos.z then
      return
    end

    if findPath(p, holdPos) then
      autoWalk(holdPos)
      return
    end

    if type(getNearTiles) == "function" then
      for _, tile in pairs(getNearTiles(holdPos)) do
        local pos = tile:getPosition()
        if findPath(p, pos) then
          autoWalk(pos)
          return
        end
      end
    end
  end)
end)
