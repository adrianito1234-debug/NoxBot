-- NoxBot Private Script: Hold Position
noxCommunityScript(function(config)
  if type(config.enabled) ~= "boolean" then config.enabled = false end

  local holdPos = nil
  local walkOpts = {
    ignoreNonPathable = true,
    ignoreCreatures = true,
    precision = 0,
  }

  local function samePos(a, b)
    return a and b and a.x == b.x and a.y == b.y and a.z == b.z
  end

  local function goBack()
    if not holdPos then return end
    local p = pos()
    if samePos(p, holdPos) then return end
    if p.z ~= holdPos.z then return end
    autoWalk(holdPos, 30, walkOpts)
  end

  macro(50, function()
    if not config.enabled then
      holdPos = nil
      return
    end
    local p = pos()
    if not holdPos then
      holdPos = { x = p.x, y = p.y, z = p.z }
      return
    end
    if player:isWalking() and not samePos(p, holdPos) then
      -- sigue intentando si te empujaron mid-walk
    end
    goBack()
  end)

  onPlayerPositionChange(function(newPos, oldPos)
    if not config.enabled or not holdPos then return end
    if not samePos(newPos, holdPos) then
      goBack()
    end
  end)
end)
