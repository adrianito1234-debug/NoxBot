﻿pcall(function() dofile("vBot/nox_version.lua") end)
local version = (type(noxCanonicalVersion) == "function" and noxCanonicalVersion()) or "3.0.16"

local logoConfigName = ""
pcall(function()
  local m = modules.nox_bot or modules.game_bot
  if m and m.contentsPanel and m.contentsPanel.config then
    logoConfigName = m.contentsPanel.config:getCurrentOption().text or ""
  end
end)
if logoConfigName == "" then
  pcall(function()
    local n = g_game.getCharacterName() or ""
    logoConfigName = n:gsub("%s+", "_")
  end)
end

local function noxLogoB64(moduleName)
  local b64lib = (type(base64) == "table" and base64) or (type(context) == "table" and context.base64)
  if not b64lib or type(b64lib.decode) ~= "function" then return nil end
  local bases = {
    "/noxbot/" .. logoConfigName .. "/vBot/",
    "/noxbot/_template/vBot/",
    "/noxbot/pack/nox_bot/",
    "/modules/nox_bot/",
  }
  for _, base in ipairs(bases) do
    local path = base .. moduleName
    local okRead, chunk = pcall(g_resources.readFileContents, path)
    if okRead and type(chunk) == "string" and #chunk > 50 then
      local embedded = chunk:match("return%s+%[%[([%s%S]-)%]%]")
      if embedded then
        embedded = embedded:gsub("%s+", "")
        local okDec, raw = pcall(b64lib.decode, embedded)
        if okDec and type(raw) == "string" and #raw > 100 then return raw end
      end
    end
  end
  return nil
end

local function noxReadLauncherFile(name)
  local roots = {}
  pcall(function()
    local home = os.getenv and (os.getenv("USERPROFILE") or os.getenv("HOME"))
    if home and home ~= "" then
      roots[#roots + 1] = home .. "/Desktop/Proyecto Nox/NoxBot-Dev/"
      roots[#roots + 1] = home .. "/Desktop/NoxBot 1.0/"
      roots[#roots + 1] = home .. "/Desktop/NoxBot/"
    end
  end)
  for _, root in ipairs(roots) do
    local ok, data = pcall(function()
      local f = io.open(root .. name, "rb")
      if not f then return nil end
      local raw = f:read("*a")
      f:close()
      return raw
    end)
    if ok and type(data) == "string" and #data > 0 then return data end
  end
  return nil
end

local function applyLogo(widget, candidates)
  if not widget then return false end
  local b64lib = (type(base64) == "table" and base64) or (type(context) == "table" and context.base64)
  for _, name in ipairs({ "noxbot_logo_top.png", "noxbot_mini.png", "noxbot_icon.png" }) do
    local raw = noxReadLauncherFile(name)
    if raw and b64lib and type(b64lib.encode) == "function" and widget.img and type(widget.img.setImageSourceBase64) == "function" then
      if pcall(function() widget.img:setImageSourceBase64(b64lib.encode(raw)) end) then
        return true
      end
    end
  end
  local raw = noxLogoB64("nox_logo_b64.lua") or noxLogoB64("nox_mini_b64.lua")
  if raw and b64lib and type(b64lib.encode) == "function" and widget.img and type(widget.img.setImageSourceBase64) == "function" then
    if pcall(function() widget.img:setImageSourceBase64(b64lib.encode(raw)) end) then
      return true
    end
  end
  for _, path in ipairs(candidates) do
    local ok = false
    if type(base64) == "table" and type(base64.encode) == "function" and widget.img and type(widget.img.setImageSourceBase64) == "function" then
      local okRead, data = pcall(g_resources.readFileContents, path)
      if okRead and type(data) == "string" and #data > 0 then
        ok = pcall(function() widget.img:setImageSourceBase64(base64.encode(data)) end)
      end
    end
    if not ok and widget.img then
      ok = pcall(function() widget.img:setImageSource(path) end)
    end
    if not ok then
      ok = pcall(function() widget:setImageSource(path) end)
    end
    if ok then return true end
  end
  return false
end

pcall(function()
  local logoTop = setupUI([[
Panel
  height: 72

  UIWidget
    id: img
    anchors.horizontalCenter: parent.horizontalCenter
    anchors.top: parent.top
    margin-top: 4
    size: 64 64
    phantom: false
]])
  local function paintLogo()
    local ok = false
    pcall(function()
      local m = modules.nox_bot
      if m and type(m.noxApplyMainTabLogo) == "function" then
        ok = m.noxApplyMainTabLogo(logoTop, logoConfigName)
      end
    end)
    if not ok then
      applyLogo(logoTop, {
        "/noxbot/" .. logoConfigName .. "/vBot/noxbot_logo_top.png",
        "/noxbot/" .. logoConfigName .. "/vBot/noxbot_mini.png",
        "/modules/nox_bot/noxbot_logo_top.png",
        "/modules/nox_bot/noxbot_mini.png",
        "/noxbot/pack/nox_bot/noxbot_logo_top.png",
        "noxbot_logo_top.png",
      })
    end
  end
  paintLogo()
  pcall(function()
    if scheduleEvent then
      scheduleEvent(paintLogo, 120)
      scheduleEvent(paintLogo, 600)
      scheduleEvent(paintLogo, 1500)
    end
  end)
  pcall(function()
    if modules.nox_bot then modules.nox_bot.__noxMainLogoPanel = logoTop end
  end)
  UI.Label("NoxBot v" .. version)
  local licLabel = "Licensed"
  pcall(function()
    if type(_G.__nox_sub_label) == "string" and _G.__nox_sub_label ~= "" then
      licLabel = _G.__nox_sub_label
    end
  end)
  if licLabel == "Licensed" then
    pcall(function()
      local candidates = { "license_status.txt" }
      if type(DATA) == "string" and DATA ~= "" then
        candidates[#candidates + 1] = DATA .. "/license_status.txt"
      end
      pcall(function()
        if g_resources and g_resources.readFileContents then
          local raw = g_resources.readFileContents("/noxbot/license_status.txt")
          if type(raw) == "string" then
            local t = raw:match("([^\r\n]+)")
            if t and t ~= "" then licLabel = t end
          end
        end
      end)
      if licLabel == "Licensed" then
        for _, p in ipairs(candidates) do
          local f = io.open(p, "r")
          if f then
            local raw = f:read("*a") or ""
            f:close()
            local t = tostring(raw):match("([^\r\n]+)")
            if t and t ~= "" then
              licLabel = t
              break
            end
          end
        end
      end
    end)
  end
  -- Claves lifetime de KeyAuth a veces llegan como "NNNN days left" (~20 aÃ±os).
  do
    local d = tostring(licLabel):match("^(%d+)%s+days?%s+left$")
    if d and tonumber(d) and tonumber(d) >= 3650 then
      licLabel = "Lifetime"
    end
  end
  UI.Label("License: " .. tostring(licLabel))
  UI.Separator()
end)

local REACTION_PRESETS = {
  medium = {
    healing   = { min = 200, max = 500 },
    attack    = { min = 450, max = 900 },
    targeting = { min = 450, max = 900 },
    looting   = { min = 500, max = 950 },
    equip     = { min = 500, max = 950 },
    actions   = { min = 450, max = 900 },
  },
  slow = {
    healing   = { min = 400, max = 800 },
    attack    = { min = 700, max = 1200 },
    targeting = { min = 700, max = 1200 },
    looting   = { min = 800, max = 1400 },
    equip     = { min = 800, max = 1400 },
    actions   = { min = 700, max = 1200 },
  },
  fast = {
    healing   = { min = 80, max = 220 },
    attack    = { min = 200, max = 450 },
    targeting = { min = 200, max = 450 },
    looting   = { min = 250, max = 500 },
    equip     = { min = 250, max = 500 },
    actions   = { min = 200, max = 450 },
  },
}

storage.noxReactions = storage.noxReactions or "medium"
local function applyReactions(name)
  local p = REACTION_PRESETS[name] or REACTION_PRESETS.medium
  storage.noxReactions = name
  storage.healingDelay = p.healing
  storage.attackDelay = p.attack
  storage.targetingDelay = p.targeting
  storage.lootingDelay = p.looting
  storage.equipDelay = p.equip
  storage.actionsDelay = p.actions
end
applyReactions(storage.noxReactions)

-- Fast / Medium / Slow: fila limpia izquierdaâ†’derecha, sin solaparse.
local reactionPanel = setupUI([[
Panel
  id: reactionRow
  height: 22
  margin-top: 4
  margin-bottom: 2

  BotSwitch
    id: fast
    text: Fast
    anchors.left: parent.left
    anchors.verticalCenter: parent.verticalCenter
    margin-left: 2
    size: 52 20
    text-align: center
    focusable: false

  BotSwitch
    id: medium
    text: Medium
    anchors.left: fast.right
    anchors.verticalCenter: parent.verticalCenter
    margin-left: 4
    size: 58 20
    text-align: center
    focusable: false

  BotSwitch
    id: slow
    text: Slow
    anchors.left: medium.right
    anchors.verticalCenter: parent.verticalCenter
    margin-left: 4
    size: 52 20
    text-align: center
    focusable: false
]])

local function paintReaction()
  if not reactionPanel then return end
  local cur = storage.noxReactions or "medium"
  for _, id in ipairs({"fast", "medium", "slow"}) do
    local btn = reactionPanel[id]
    if btn then
      local on = (id == cur)
      pcall(function() btn:setOn(on) end)
      pcall(function() btn:setColor(on and "#00CC33" or "#CC2222") end)
    end
  end
end

local function paintReactionSoon()
  paintReaction()
  if type(schedule) == "function" then
    schedule(20, paintReaction)
    schedule(80, paintReaction)
    schedule(200, paintReaction)
  end
end

if reactionPanel then
  paintReaction()
  for _, id in ipairs({"fast", "medium", "slow"}) do
    if reactionPanel[id] then
      pcall(function() reactionPanel[id]:setFocusable(false) end)
      reactionPanel[id].onClick = function()
        applyReactions(id)
        paintReactionSoon()
      end
    end
  end
end

UI.Separator()
