-- Version canonica: maximo entre version.txt, engine y bridge (io.open a DATA suele fallar en OTC).
function noxCanonicalVersion()
  local function take(raw)
    if type(raw) ~= "string" or #raw > 64 or raw:find("\0", 1, true) then return nil end
    return raw:match("^%s*(%d+%.%d+[%d%.]*)")
  end
  local function part(s, idx)
    local n = 0
    for w in tostring(s or ""):gmatch("%d+") do
      n = n + 1
      if n == idx then return tonumber(w) or 0 end
    end
    return 0
  end
  local function newer(a, b)
    if not a then return b end
    if not b then return a end
    for i = 1, 4 do
      local x, y = part(a, i), part(b, i)
      if x ~= y then return (x > y) and a or b end
    end
    return a
  end
  local best = nil
  local function consider(v)
    v = take(v)
    if v then best = newer(best, v) end
  end
  pcall(function()
    local t = _G.__nox_txt
    if type(t) == "table" then
      consider(t["version.txt"])
      consider(t["modules/nox_bot/version.txt"])
    end
  end)
  pcall(function()
    if g_resources and g_resources.readFileContents then
      for _, p in ipairs({
        "/modules/nox_bot/version.txt",
        "/noxbot/pack/nox_bot/version.txt",
      }) do
        local ok, raw = pcall(g_resources.readFileContents, p)
        if ok then consider(raw) end
      end
    end
  end)
  pcall(function()
    local d = tostring(DATA or "")
    if d ~= "" and io and io.open then
      local f = io.open(d .. "/version.txt", "r")
      if f then consider(f:read("*a")); f:close() end
    end
  end)
  consider(_G.__nox_ver)
  return best or "3.0.30"
end
