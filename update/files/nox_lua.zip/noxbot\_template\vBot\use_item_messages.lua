setDefaultTab("Main")

local panelName = "useItemMsgs"
local config, window = addMaker(panelName, "Use Item Msgs", "UseItemMsgsWindow", "Setup")

if type(config.hideUH) ~= "boolean" then
  config.hideUH = false
end
if type(config.hideSD) ~= "boolean" then
  config.hideSD = false
end
if type(config.hideMana) ~= "boolean" then
  config.hideMana = false
end

bindSwitch(window.hideUH, config, "hideUH")
bindSwitch(window.hideSD, config, "hideSD")
bindSwitch(window.hideMana, config, "hideMana")

local function textLooksLikeUseMsg(text)
  text = tostring(text or ""):lower()
  return text:find("using one of", 1, true) ~= nil
      or text:find("using the last", 1, true) ~= nil
end

local function parseUseItemName(text)
  text = tostring(text or ""):lower()
  if not textLooksLikeUseMsg(text) then
    return nil
  end
  local name = text:match("using one of%s+%d+%s+([%a%s%-]+)")
    or text:match("using the last%s+([%a%s%-]+)")
  if name then
    name = name:gsub("%s*%.%.%.$", ""):gsub("%s+$", "")
    if #name > 0 then return name end
  end
  local re = regexMatch(text, [[\d ([a-z A-Z]*)s...]])
  if re and re[1] and re[1][2] then
    return re[1][2]:lower()
  end
  return nil
end

local function classifyUseItem(name)
  if not name or name == "" then return nil end
  if name:find("vial", 1, true)
      or name:find("mana potion", 1, true)
      or name:find("spirit potion", 1, true)
      or name:find("strong mana", 1, true)
      or name:find("great mana", 1, true) then
    return "mana"
  end
  if name:find("sudden death", 1, true) then
    return "sd"
  end
  if name:find("healing rune", 1, true)
      or name:find("ultimate healing", 1, true)
      or name:find("intense healing", 1, true) then
    return "uh"
  end
  return nil
end

local function shouldSuppressDisplay(text)
  if not config.enabled then return false end
  local cat = classifyUseItem(parseUseItemName(text))
  if cat == "uh" then return config.hideUH end
  if cat == "sd" then return config.hideSD end
  if cat == "mana" then return config.hideMana end
  return false
end

vBot = vBot or {}
vBot.useItemMsgs = vBot.useItemMsgs or {}
vBot.useItemMsgs.shouldSuppress = shouldSuppressDisplay

pcall(function()
  if modules and modules.nox_bot then
    modules.nox_bot.useItemMsgShouldSuppress = shouldSuppressDisplay
  end
end)

local function clearUseItemOverlay(text)
  pcall(function()
    local p = g_game.getLocalPlayer()
    if p and p.clearText then
      local shown = p:getText() or ""
      if shown == text or textLooksLikeUseMsg(shown) then
        p:clearText()
      end
    end
  end)
  pcall(function()
    if player and player.clearText then
      local shown = player:getText() or ""
      if shown == text or textLooksLikeUseMsg(shown) then
        player:clearText()
      end
    end
  end)
  pcall(function()
    local mod = modules and modules.game_textmessage
    local panel = mod and mod.messagesPanel
    if not panel then return end
    if panel.centerTextMessagePanel and panel.centerTextMessagePanel.highCenterLabel then
      local lbl = panel.centerTextMessagePanel.highCenterLabel
      local shown = lbl:getText() or ""
      if shown == text or textLooksLikeUseMsg(shown) then
        lbl:setVisible(false)
        lbl:setText("")
      end
    end
    if panel.statusLabel then
      local shown = panel.statusLabel:getText() or ""
      if shown == text or textLooksLikeUseMsg(shown) then
        panel.statusLabel:setVisible(false)
        panel.statusLabel:setText("")
      end
    end
  end)
end

local function installDisplayHooks()
  local mod = modules and modules.game_textmessage
  if not mod or type(mod.displayMessage) ~= "function" then
    return false
  end
  if not mod.__noxUseItemMsgHook then
    mod.__noxUseItemMsgHook = true
    local origDisplay = mod.displayMessage
    mod.displayMessage = function(mode, msgText)
      if shouldSuppressDisplay(msgText) then
        return
      end
      return origDisplay(mode, msgText)
    end
    local function wrap(fnName)
      local orig = mod[fnName]
      if type(orig) ~= "function" then return end
      mod[fnName] = function(msgText)
        if shouldSuppressDisplay(msgText) then return end
        return orig(msgText)
      end
    end
    wrap("displayStatusMessage")
    wrap("displayGameMessage")
    wrap("displayFailureMessage")
  end
  return true
end

if not installDisplayHooks() then
  for _, delay in ipairs({ 50, 200, 500, 1000, 2000, 5000 }) do
    schedule(delay, installDisplayHooks)
  end
end

onTextMessage(function(mode, text)
  if not shouldSuppressDisplay(text) then return end
  clearUseItemOverlay(text)
  schedule(0, function() clearUseItemOverlay(text) end)
  schedule(25, function() clearUseItemOverlay(text) end)
end)

pcall(function()
  onStaticText(function(thing, text)
    if not shouldSuppressDisplay(text) then return end
    pcall(function()
      if thing and thing.destroy then
        thing:destroy()
      end
    end)
  end)
end)

-- Nostalrius paints "Using one of..." on the player sprite (not only status labels).
macro(10, function()
  if not config.enabled then return end
  local p = player
  if not p or not p.getText or not p.clearText then return end
  local shown = p:getText() or ""
  if not textLooksLikeUseMsg(shown) then return end
  if shouldSuppressDisplay(shown) then
    p:clearText()
  end
end)
