setDefaultTab("Tools")

local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    text-align: center
    width: 130
    !text: tr('Dropper')

  Button
    id: edit
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 3
    height: 17
    text: Setup
]])

local edit = setupUI([[
Panel
  height: 177

  Label
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    text-align: center
    text: Trash:

  BotContainer
    id: TrashItems
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    height: 32

  Label
    anchors.top: prev.bottom
    margin-top: 5
    anchors.left: parent.left
    anchors.right: parent.right
    text-align: center
    text: Use:

  BotContainer
    id: UseItems
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    height: 32

  Label
    anchors.top: prev.bottom
    margin-top: 5
    anchors.left: parent.left
    anchors.right: parent.right
    text-align: center
    text: Drop if below 150 cap:

  BotContainer
    id: CapItems
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    height: 32

  BotSwitch
    id: dropSqm
    anchors.top: prev.bottom
    anchors.left: parent.left
    margin-top: 6
    width: 130
    text-align: center
    text: Drop in specific SQM

  Button
    id: dropSqmSetup
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 3
    height: 17
    text: Setup
]])
edit:hide()

if not storage.dropper then
    storage.dropper = {
      enabled = false,
      trashItems = { 283, 284, 285 },
      useItems = { 21203, 14758 },
      capItems = { 21175 }
    }
end

local config = storage.dropper

if type(noxAsList) == "function" then
  config.trashItems = noxAsList(config.trashItems)
  config.useItems = noxAsList(config.useItems)
  config.capItems = noxAsList(config.capItems)
end

if type(config.dropSqm) ~= "boolean" then
    config.dropSqm = false
end
if type(config.dropPos) ~= "table" then
    config.dropPos = { x = 0, y = 0, z = 0 }
end

local showEdit = false
ui.edit.onClick = function(widget)
  showEdit = not showEdit
  if showEdit then
    edit:show()
  else
    edit:hide()
  end
end

ui.title:setOn(config.enabled)
ui.title.onClick = function(widget)
  config.enabled = not config.enabled
  ui.title:setOn(config.enabled)
end

UI.Container(function()
    config.trashItems = edit.TrashItems:getItems()
    end, true, nil, edit.TrashItems)
edit.TrashItems:setItems(config.trashItems)

UI.Container(function()
    config.useItems = edit.UseItems:getItems()
    end, true, nil, edit.UseItems)
edit.UseItems:setItems(config.useItems)

UI.Container(function()
    config.capItems = edit.CapItems:getItems()
    end, true, nil, edit.CapItems)
edit.CapItems:setItems(config.capItems)

local sqmWindow = UI.createWindow("DropperSqmWindow")
sqmWindow:hide()

local coordFields = {
    x = sqmWindow.posX,
    y = sqmWindow.posY,
    z = sqmWindow.posZ
}

local function refreshCoordFields()
    for key, field in pairs(coordFields) do
        field:setText(tostring(config.dropPos[key] or 0))
    end
end

for key, field in pairs(coordFields) do
    field.onTextChange = function(widget, text)
        config.dropPos[key] = tonumber(text) or 0
    end
end

refreshCoordFields()

sqmWindow.useCurrent.onClick = function()
    local playerPos = player:getPosition()
    if not playerPos then return end

    config.dropPos = { x = playerPos.x, y = playerPos.y, z = playerPos.z }
    refreshCoordFields()
end

edit.dropSqm:setOn(config.dropSqm)
edit.dropSqm.onClick = function(widget)
    config.dropSqm = not config.dropSqm
    widget:setOn(config.dropSqm)
end

edit.dropSqmSetup.onClick = function()
    sqmWindow:show()
    sqmWindow:raise()
    sqmWindow:focus()
end

local function canReachDropPos()
    local target = config.dropPos
    if not target or not target.x or target.x == 0 then return false end

    local playerPos = player:getPosition()
    if not playerPos or playerPos.z ~= target.z then return false end

    if math.max(math.abs(playerPos.x - target.x), math.abs(playerPos.y - target.y)) > 7 then
        return false
    end

    if not g_map.getTile(target) then return false end

    return true
end

local function dropToGround(item)
    if not config.dropSqm then
        dropItem(item)
        return true
    end

    if not canReachDropPos() then return false end

    g_game.move(item, config.dropPos, item:getCount())
    return true
end

local function properTable(t)
    if type(noxItemIds) == "function" then
      return noxItemIds(t)
    end
    local r = {}
    if type(t) ~= "table" then return r end
    for _, entry in pairs(t) do
      local id = type(entry) == "number" and entry or (type(entry) == "table" and entry.id)
      if id then table.insert(r, id) end
    end
    return r
end

macro(200, function()
    if not config.enabled then return end
    local tables = {properTable(config.capItems), properTable(config.useItems), properTable(config.trashItems)}

    local containers = getContainers()
    for i=1,3 do
        for _, container in pairs(containers) do
            for __, item in ipairs(container:getItems()) do
                for ___, userItem in ipairs(tables[i]) do
                    if item:getId() == userItem then
                        if i == 1 then
                            if freecap() < 150 and dropToGround(item) then return end
                        elseif i == 2 then
                            return use(item)
                        else
                            if dropToGround(item) then return end
                        end
                    end
                end
            end
        end
    end

end)
