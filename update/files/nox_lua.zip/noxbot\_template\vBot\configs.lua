--[[
  Configs HealBot / AttackBot / Supplies
  Garantiza carpetas escribibles antes de CUALQUIER save.
]]--

local function resolveConfigName()
  local name = ""
  if type(__noxbot_char_cfg) == "string" and __noxbot_char_cfg ~= "" then
    name = __noxbot_char_cfg
  end
  if name == "" then
    pcall(function()
      local m = modules.nox_bot or modules.game_bot
      if m and m.contentsPanel and m.contentsPanel.config then
        name = m.contentsPanel.config:getCurrentOption().text or ""
      end
    end)
  end
  if name == "" then
    pcall(function() name = tostring(g_game.getCharacterName() or ""):gsub("%s+", "_") end)
  end
  if name == "" then name = "_template" end
  return name
end

local function ensureDir(path)
  path = tostring(path or ""):gsub("\\", "/"):gsub("/+$", "")
  if path == "" then return end
  local acc = ""
  for part in path:gmatch("[^/]+") do
    acc = acc .. "/" .. part
    pcall(function()
      if g_resources.makeDir then g_resources.makeDir(acc) end
    end)
  end
end

local function ensureAllDirs(configName)
  ensureDir("/noxbot")
  ensureDir("/noxbot/" .. configName)
  ensureDir("/noxbot/" .. configName .. "/vBot_configs")
  ensureDir("/noxbot/" .. configName .. "/storage")
  ensureDir("/noxbot/" .. configName .. "/cavebot_configs")
  ensureDir("/noxbot/" .. configName .. "/targetbot_configs")
  for i = 0, 10 do
    ensureDir("/noxbot/" .. configName .. "/vBot_configs/profile_" .. i)
  end
end

local function getProfile()
  local p = 1
  pcall(function() p = tonumber(g_settings.getNumber("profile")) or 1 end)
  if not p or p < 1 then p = 1 end
  return p
end

local function physRoots()
  local roots = {}
  local function add(p)
    p = tostring(p or ""):gsub("\\", "/"):gsub("/+$", "")
    if p == "" then return end
    local low = p:lower()
    if low:match("/noxbot 1%.0$") then return end
    if not (low:find("noxbot_data", 1, true) or low:find("nostalrius", 1, true)) then
      return
    end
    for _, e in ipairs(roots) do if e == p then return end end
    roots[#roots + 1] = p
  end
  -- Nostalrius primero: ahi viven los configs reales del cliente.
  pcall(function()
    local home = os.getenv and (os.getenv("USERPROFILE") or os.getenv("HOME"))
    if home and home ~= "" then
      add(home .. "/AppData/Roaming/Nostalrius/Nostalrius_Profiles")
    end
  end)
  pcall(function()
    if g_resources.getWriteDir then add(g_resources.getWriteDir()) end
  end)
  if type(DATA) == "string" then add(DATA) end
  pcall(function()
    local home = os.getenv and (os.getenv("USERPROFILE") or os.getenv("HOME"))
    if home and home ~= "" then
      add(home .. "/Desktop/NoxBot 1.0/noxbot_data")
      add(home .. "/Desktop/NoxBot/noxbot_data")
    end
  end)
  return roots
end

local function isEmptyJson(data)
  if type(data) ~= "string" then return true end
  local s = data:gsub("%s+", "")
  return s == "" or s == "{}" or s == "[]" or s == "null"
end

local function physRead(virtPath)
  virtPath = tostring(virtPath or ""):gsub("\\", "/")
  if virtPath:sub(1, 1) ~= "/" then virtPath = "/" .. virtPath end
  local best, bestScore = nil, -1
  for _, root in ipairs(physRoots()) do
    local f = io and io.open and io.open(root .. virtPath, "rb")
    if f then
      local data = f:read("*a")
      f:close()
      if type(data) == "string" and not isEmptyJson(data) then
        local score = #data
        -- Preferir Nostalrius frente a stubs vacios del Desktop.
        if tostring(root):lower():find("nostalrius", 1, true) then
          score = score + 1000000
        end
        if score > bestScore then
          best, bestScore = data, score
        end
      end
    end
  end
  if best then return best end
  local ok, data = pcall(function()
    if g_resources.fileExists(virtPath) then
      return g_resources.readFileContents(virtPath)
    end
  end)
  if ok and type(data) == "string" and not isEmptyJson(data) then return data end
  return nil
end

local function physMkdir(path)
  path = tostring(path or ""):gsub("/", "\\"):gsub("\\+$", "")
  if path == "" then return end
  pcall(function()
    if g_resources and g_resources.makeDir then
      -- virtual path variant handled separately
    end
  end)
  -- Windows: md creates intermediates when quoted properly via powershell-less cmd
  pcall(function()
    os.execute('if not exist "' .. path .. '" mkdir "' .. path .. '"')
  end)
end

local function physWrite(virtPath, contents)
  virtPath = tostring(virtPath or ""):gsub("\\", "/")
  if virtPath:sub(1, 1) ~= "/" then virtPath = "/" .. virtPath end
  pcall(function()
    local parent = virtPath:match("^(.*)/[^/]+$")
    if parent then ensureDir(parent) end
    g_resources.writeFileContents(virtPath, contents)
  end)
  for _, root in ipairs(physRoots()) do
    pcall(function()
      local full = (root .. virtPath):gsub("/", "\\")
      local parent = full:match("^(.*)\\[^\\]+$")
      if parent then physMkdir(parent) end
      local f = io.open(root .. virtPath, "wb")
      if not f then f = io.open(full, "wb") end
      if f then f:write(contents) f:close() end
    end)
  end
end

local function noxFlagOn(v)
  return v == true or v == 1 or v == "1" or v == "true" or v == "on"
end

local function noxFlagOff(v)
  return v == false or v == 0 or v == "0" or v == "false" or v == "off"
end

-- On/Off de HealBot / Conditions / EQ / Eat Food.
-- El json del OTC tira booleanos. Fast/Medium y el On del motor SÍ
-- sobreviven: strings en storage + g_settings.setNode('noxbot').
local function noxSettingsIndex()
  local name, ver = "", ""
  pcall(function() name = tostring(g_game.getCharacterName() or "") end)
  pcall(function() ver = tostring(g_game.getClientVersion() or "") end)
  if name == "" then return nil end
  return name .. "_" .. ver
end

local function noxSettingsHpGet()
  local out = {}
  pcall(function()
    if not g_settings or not g_settings.getNode then return end
    local settings = g_settings.getNode("noxbot_hp") or {}
    local index = resolveConfigName()
    local s = index and (settings[index] or (noxSettingsIndex() and settings[noxSettingsIndex()]))
    if type(s) ~= "table" then return end
    local function pick(a, b)
      if noxFlagOn(a) or noxFlagOn(b) then return true end
      if noxFlagOff(a) or noxFlagOff(b) then return false end
      return nil
    end
    out.heal = pick(s.heal, s.hpHeal)
    out.cond = pick(s.cond, s.hpCond)
    out.eq = pick(s.eq, s.hpEq)
    out.food = pick(s.food, s.hpFood)
  end)
  return out
end

local function noxSettingsHpSet(flags)
  if type(flags) ~= "table" then return end
  pcall(function()
    if not g_settings or not g_settings.setNode then return end
    local settings = g_settings.getNode("noxbot_hp") or {}
    local index = resolveConfigName()
    if not index or index == "" then index = noxSettingsIndex() end
    if not index then return end
    settings[index] = type(settings[index]) == "table" and settings[index] or {}
    local s = settings[index]
    if flags.heal ~= nil then s.heal = flags.heal and 1 or 0 s.hpHeal = s.heal end
    if flags.cond ~= nil then s.cond = flags.cond and 1 or 0 s.hpCond = s.cond end
    if flags.eq ~= nil then s.eq = flags.eq and 1 or 0 s.hpEq = s.eq end
    if flags.food ~= nil then s.food = flags.food and 1 or 0 s.hpFood = s.food end
    g_settings.setNode("noxbot_hp", settings)
    if g_settings.save then g_settings.save() end
  end)
end

function noxReadHpOnOff()
  local out = noxSettingsHpGet()
  if type(storage) == "table" then
    if out.heal == nil and storage.hpHeal == "on" then out.heal = true end
    if out.heal == nil and storage.hpHeal == "off" then out.heal = false end
    if out.cond == nil and storage.hpCond == "on" then out.cond = true end
    if out.cond == nil and storage.hpCond == "off" then out.cond = false end
    if out.eq == nil and storage.hpEq == "on" then out.eq = true end
    if out.eq == nil and storage.hpEq == "off" then out.eq = false end
    if out.food == nil and storage.hpFood == "on" then out.food = true end
    if out.food == nil and storage.hpFood == "off" then out.food = false end
  end
  if out.heal == nil or out.cond == nil or out.eq == nil or out.food == nil then
    local cfg = resolveConfigName()
    local prof = getProfile()
    local raw = physRead("/noxbot/" .. cfg .. "/storage/hp_onoff.txt")
      or physRead("/noxbot/" .. cfg .. "/vBot_configs/profile_" .. prof .. "/hp_onoff.txt")
    if type(raw) == "string" and raw ~= "" then
      local function bit(key)
        local v = raw:match(key .. "%s*=%s*(%w+)")
        if v == nil then return nil end
        if noxFlagOn(v) then return true end
        if noxFlagOff(v) then return false end
        return nil
      end
      if out.heal == nil then out.heal = bit("heal") end
      if out.cond == nil then out.cond = bit("cond") end
      if out.eq == nil then out.eq = bit("eq") end
      if out.food == nil then out.food = bit("food") end
    end
  end
  if out.heal == nil and out.cond == nil and out.eq == nil and out.food == nil then
    return nil
  end
  return out
end

function noxWriteHpOnOff(patch)
  local cur = noxReadHpOnOff() or {}
  if type(patch) == "table" then
    if patch.heal ~= nil then cur.heal = not not patch.heal end
    if patch.cond ~= nil then cur.cond = not not patch.cond end
    if patch.eq ~= nil then cur.eq = not not patch.eq end
    if patch.food ~= nil then cur.food = not not patch.food end
  else
    if type(storage) == "table" then
      if storage.hpHeal == "on" or noxFlagOn(storage.healBotEnabled) then cur.heal = true end
      if storage.hpHeal == "off" then cur.heal = false end
      if storage.hpCond == "on" or noxFlagOn(storage.conditionsEnabled) then cur.cond = true end
      if storage.hpCond == "off" then cur.cond = false end
      if storage.hpEq == "on" then cur.eq = true end
      if storage.hpEq == "off" then cur.eq = false end
      if type(storage.EquipperPanel) == "table" and storage.EquipperPanel.enabled ~= nil then
        cur.eq = noxFlagOn(storage.EquipperPanel.enabled)
      end
      if storage.hpFood == "on" then cur.food = true end
      if storage.hpFood == "off" then cur.food = false end
      if type(storage.eatFood) == "table" and storage.eatFood.enabled ~= nil then
        cur.food = noxFlagOn(storage.eatFood.enabled)
      end
    end
    pcall(function()
      if type(HealBot) == "table" and type(HealBot.isOn) == "function" then
        cur.heal = not not HealBot.isOn()
      end
    end)
    pcall(function()
      if type(HealBotConfig) == "table" and type(HealBotConfig.ConditionPanel) == "table" then
        cur.cond = noxFlagOn(HealBotConfig.ConditionPanel.enabled)
      end
    end)
  end
  if type(storage) == "table" then
    if cur.heal ~= nil then
      storage.hpHeal = cur.heal and "on" or "off"
      storage.healBotEnabled = cur.heal
    end
    if cur.cond ~= nil then
      storage.hpCond = cur.cond and "on" or "off"
      storage.conditionsEnabled = cur.cond
    end
    if cur.eq ~= nil then
      storage.hpEq = cur.eq and "on" or "off"
      storage.EquipperPanel = type(storage.EquipperPanel) == "table" and storage.EquipperPanel or {}
      storage.EquipperPanel.enabled = cur.eq
    end
    if cur.food ~= nil then
      storage.hpFood = cur.food and "on" or "off"
      storage.eatFood = type(storage.eatFood) == "table" and storage.eatFood or {}
      storage.eatFood.enabled = cur.food
    end
  end
  noxSettingsHpSet(cur)
  local text = string.format("heal=%s\ncond=%s\neq=%s\nfood=%s\n",
    cur.heal and "1" or "0", cur.cond and "1" or "0", cur.eq and "1" or "0", cur.food and "1" or "0")
  local cfg = resolveConfigName()
  local prof = getProfile()
  ensureAllDirs(cfg)
  physWrite("/noxbot/" .. cfg .. "/storage/hp_onoff.txt", text)
  physWrite("/noxbot/" .. cfg .. "/vBot_configs/profile_" .. prof .. "/hp_onoff.txt", text)
end

function noxApplyHpOnOff()
  local flags = noxReadHpOnOff()
  if type(flags) ~= "table" then return end
  if flags.heal ~= nil and type(HealBot) == "table" and type(HealBot.restore) == "function" then
    HealBot.restore(flags.heal)
  end
  if type(vBot) == "table" then
    if flags.cond ~= nil then
      if type(vBot.restoreConditionsUi) == "function" then
        vBot.restoreConditionsUi(flags.cond)
      elseif type(vBot.syncConditionsUi) == "function" then
        vBot.syncConditionsUi(flags.cond)
      end
    end
    if flags.eq ~= nil and type(vBot.syncEquipperUi) == "function" then
      vBot.syncEquipperUi(flags.eq)
    end
    if flags.food ~= nil and type(vBot.syncEatFoodUi) == "function" then
      vBot.syncEatFoodUi(flags.food)
    end
  end
end

function noxReadModuleJson(which)
  local cfg = resolveConfigName()
  local prof = getProfile()
  local name = which == "eq" and "Equipper.json" or "EatFood.json"
  local raw = physRead("/noxbot/" .. cfg .. "/vBot_configs/profile_" .. prof .. "/" .. name)
    or physRead("/noxbot/" .. cfg .. "/storage/" .. name)
  if type(raw) ~= "string" or raw == "" or raw == "{}" then return nil end
  local ok, data = pcall(function() return json.decode(raw) end)
  if ok and type(data) == "table" then return data end
  return nil
end

function noxWriteModuleJson(which, tbl)
  if type(tbl) ~= "table" then return end
  local payload
  if type(encodePlain) == "function" then
    payload = encodePlain(tbl)
  end
  if type(payload) ~= "string" then
    local ok, encoded = pcall(function() return json.encode(tbl) end)
    if ok then payload = encoded end
  end
  if type(payload) ~= "string" then return end
  local cfg = resolveConfigName()
  local prof = getProfile()
  local name = which == "eq" and "Equipper.json" or "EatFood.json"
  ensureAllDirs(cfg)
  physWrite("/noxbot/" .. cfg .. "/vBot_configs/profile_" .. prof .. "/" .. name, payload)
  physWrite("/noxbot/" .. cfg .. "/storage/" .. name, payload)
end

local function pathsFor(configName, profile)
  local base = "/noxbot/" .. configName .. "/vBot_configs/profile_" .. profile
  return base,
    base .. "/HealBot.json",
    base .. "/AttackBot.json",
    base .. "/Supplies.json"
end

local configName = resolveConfigName()
ensureAllDirs(configName)
local profile = getProfile()
local profileBase, healBotFile, attackBotFile, suppliesFile = pathsFor(configName, profile)

HealBotConfig = HealBotConfig or {}
AttackBotConfig = AttackBotConfig or {}
SuppliesConfig = SuppliesConfig or {}

local function safeReadJson(path)
  local raw = physRead(path)
  if type(raw) ~= "string" or raw == "" or raw == "{}" or raw == "[]" then
    return {}
  end
  local ok, data = pcall(function() return json.decode(raw) end)
  if ok and type(data) == "table" then return data end
  return {}
end

-- JSON a veces deja healbot con claves "1".."5" (string). Sin [1] numérico
-- HealBot.lua creía que no había perfil y lo reseteaba a enabled=false.
local function normalizeHealbotArray(tbl)
  if type(tbl) ~= "table" then return tbl end
  if tbl[1] then return tbl end
  if tbl["1"] or tbl[0] then
    local fixed = {}
    for i = 1, 5 do
      fixed[i] = tbl[i] or tbl[tostring(i)] or tbl[i - 1] or {}
    end
    return fixed
  end
  return tbl
end

HealBotConfig = safeReadJson(healBotFile)
do
  -- Igual que AttackBot: storage/ es espejo del ultimo save y gana sobre profile_N stale.
  local alt = safeReadJson("/noxbot/" .. configName .. "/storage/HealBot.json")
  if alt.healbot or alt["healbot"] then
    HealBotConfig = alt
  end
end
AttackBotConfig = safeReadJson(attackBotFile)
do
  -- storage/AttackBot.json es el espejo del ultimo save (vBotConfigSave "atk").
  -- profile_N/AttackBot.json a veces se queda con un default viejo y al Off/On
  -- pisa lo que el usuario configuro. Si hay espejo, ese gana.
  local alt = safeReadJson("/noxbot/" .. configName .. "/storage/AttackBot.json")
  if alt.AttackBot or alt["AttackBot"] then
    AttackBotConfig = alt
  end
end
SuppliesConfig = safeReadJson(suppliesFile)

if type(HealBotConfig.healbot) == "table" then
  HealBotConfig.healbot = normalizeHealbotArray(HealBotConfig.healbot)
end

-- AttackBot: mismo problema que HealBot (claves "1".."5" + attackTable como mapa).
-- Sin normalizar, AttackBot.lua creía que no había perfil y lo borraba al Off/On.
local function normalizeMonstersField(m)
  if m == true or m == false then return m end
  if type(m) ~= "table" then return true end
  local list = {}
  for _, name in ipairs(m) do
    if type(name) == "string" and name ~= "" then list[#list + 1] = name end
  end
  if #list == 0 then
    for _, name in pairs(m) do
      if type(name) == "string" and name ~= "" then list[#list + 1] = name end
    end
  end
  return #list > 0 and list or true
end

local function normalizeAttackEntry(e)
  if type(e) ~= "table" then return nil end
  return {
    creatures = tostring(e.creatures or ""),
    monsters = normalizeMonstersField(e.monsters),
    mana = tonumber(e.mana) or 0,
    count = tonumber(e.count) or 1,
    minHp = tonumber(e.minHp) or 0,
    maxHp = tonumber(e.maxHp) or 100,
    cooldown = tonumber(e.cooldown) or 0,
    itemId = tonumber(e.itemId) or 0,
    spell = tostring(e.spell or ""),
    enabled = e.enabled ~= false,
    category = tonumber(e.category) or e.category or 1,
    patternCategory = tonumber(e.patternCategory) or e.patternCategory or 1,
    pattern = tonumber(e.pattern) or e.pattern or 1,
    tooltip = e.tooltip,
    orMore = not not e.orMore,
    description = tostring(e.description or "")
  }
end

local function defaultAttackProfile(i)
  return {
    enabled = false,
    attackTable = {},
    ignoreMana = true,
    Kills = false,
    Rotate = false,
    name = "Profile #" .. tostring(i or 1),
    Cooldown = true,
    Visible = false,
    pvpMode = false,
    KillsAmount = 1,
    PvpSafe = true,
    BlackListSafe = false,
    AntiRsRange = 5,
    Training = false
  }
end

local function normalizeAttackBotConfig(cfg)
  if type(cfg) ~= "table" then cfg = {} end
  local panel = cfg.AttackBot
  if type(panel) ~= "table" then
    panel = {}
  end
  if not panel[1] and (panel["1"] or panel[0]) then
    local fixed = {}
    for i = 1, 5 do
      fixed[i] = panel[i] or panel[tostring(i)] or panel[i - 1]
    end
    panel = fixed
  end
  local out = {}
  for i = 1, 5 do
    local p = panel[i] or panel[tostring(i)]
    if type(p) ~= "table" then
      out[i] = defaultAttackProfile(i)
    else
      local np = defaultAttackProfile(i)
      np.enabled = not not p.enabled
      np.ignoreMana = p.ignoreMana ~= false
      np.Kills = not not p.Kills
      np.Rotate = not not p.Rotate
      np.name = (type(p.name) == "string" and p.name ~= "") and p.name or ("Profile #" .. i)
      np.Cooldown = p.Cooldown ~= false
      np.Visible = false
      np.pvpMode = not not p.pvpMode
      np.KillsAmount = tonumber(p.KillsAmount) or 1
      np.PvpSafe = p.PvpSafe ~= false
      np.BlackListSafe = not not p.BlackListSafe
      np.AntiRsRange = tonumber(p.AntiRsRange) or 5
      np.Training = not not p.Training
      local at = {}
      local rawAt = p.attackTable
      if type(rawAt) == "table" then
        local n = tonumber(rawAt._n) or tonumber(rawAt.count) or 0
        if n < 1 then
          for k in pairs(rawAt) do
            local i = tonumber(k)
            if i and i > n then n = i end
          end
        end
        for i = 1, math.max(n, 0) do
          local e = rawAt[i] or rawAt[tostring(i)]
          local ne = normalizeAttackEntry(e)
          if ne then at[#at + 1] = ne end
        end
        if #at == 0 then
          for _, e in ipairs(rawAt) do
            local ne = normalizeAttackEntry(e)
            if ne then at[#at + 1] = ne end
          end
        end
        if #at == 0 then
          for _, e in pairs(rawAt) do
            local ne = normalizeAttackEntry(e)
            if ne then at[#at + 1] = ne end
          end
        end
      end
      np.attackTable = at
      out[i] = np
    end
  end
  cfg.AttackBot = out
  local cur = tonumber(cfg.currentBotProfile) or 1
  if cur < 1 or cur > 5 then cur = 1 end
  cfg.currentBotProfile = cur
  return cfg
end

do
  local function countAttackRules(at)
    if type(at) ~= "table" then return 0 end
    local n = 0
    for k, v in pairs(at) do
      if k ~= "_n" and k ~= "count" and type(v) == "table" then
        n = n + 1
      end
    end
    return n
  end
  local empty = not AttackBotConfig.AttackBot and not AttackBotConfig["AttackBot"]
  -- current.json (attackSetupJson) sobrevive Off/On del bot. Si tiene reglas, es la verdad.
  if type(storage) == "table" and type(storage.attackSetupJson) == "string" and storage.attackSetupJson ~= "" then
    local ok, data = pcall(function() return json.decode(storage.attackSetupJson) end)
    if ok and type(data) == "table" then
      local sp = (data.AttackBot and (data.AttackBot[1] or data.AttackBot["1"])) or nil
      local storageEntries = 0
      if type(sp) == "table" then
        storageEntries = countAttackRules(sp.attackTable)
      end
      if empty or storageEntries > 0 then
        AttackBotConfig = data
      end
    end
  end
end
AttackBotConfig = normalizeAttackBotConfig(AttackBotConfig)

-- Copia JSON-safe: solo string/number/bool y tablas. Claves numericas -> "1","2"..
-- El json.encode del OTC a veces tira tablas con [1]/[2] y deja el Setup vacio.
local function copyPlain(v, seen)
  seen = seen or {}
  local t = type(v)
  if t == "boolean" or t == "number" or t == "string" then return v end
  if t ~= "table" then return nil end
  if seen[v] then return seen[v] end
  local out = {}
  seen[v] = out
  for k, val in pairs(v) do
    local kt = type(k)
    local key
    if kt == "string" then
      key = k
    elseif kt == "number" then
      key = tostring(k)
    end
    if key then
      local cv = copyPlain(val, seen)
      if cv ~= nil then out[key] = cv end
    end
  end
  return out
end

local function pickIndex(tbl, i)
  if type(tbl) ~= "table" then return nil end
  return tbl[i] or tbl[tostring(i)] or tbl[i - 1]
end

local function listFromMap(tbl)
  local list = {}
  if type(tbl) ~= "table" then return list end
  local n = tonumber(tbl._n) or tonumber(tbl.count) or 0
  if n < 1 then
    for k in pairs(tbl) do
      local i = tonumber(k)
      if i and i > n then n = i end
    end
  end
  if n < 0 then n = 0 end
  for i = 1, n do
    local e = pickIndex(tbl, i)
    if type(e) == "table" then
      list[#list + 1] = e
    end
  end
  if #list == 0 then
    for _, e in ipairs(tbl) do
      if type(e) == "table" then list[#list + 1] = e end
    end
  end
  return list
end

local function mapFromList(list)
  local m = {}
  local n = 0
  if type(list) == "table" then
    for i, e in ipairs(list) do
      n = i
      m[tostring(i)] = copyPlain(e) or {}
    end
    if n == 0 then
      for k, e in pairs(list) do
        local i = tonumber(k)
        if i and type(e) == "table" then
          m[tostring(i)] = copyPlain(e) or {}
          if i > n then n = i end
        end
      end
    end
  end
  m._n = n
  return m
end

local COND_KEYS = {
  "enabled", "curePoison", "poisonCost", "cureCurse", "curseCost",
  "cureBleed", "bleedCost", "cureBurn", "burnCost", "cureElectrify",
  "electrifyCost", "cureParalyse", "paralyseCost", "paralyseSpell",
  "holdHaste", "hasteCost", "hasteSpell", "holdUtamo", "utamoCost",
  "holdUtana", "utanaCost", "holdUtura", "uturaType", "uturaCost",
  "ignoreInPz", "stopHaste", "curePosion",
  "energyRing", "energyOn", "energyOff", "energyItem", "energyWorn"
}

local function snapshotConditions(panel)
  local out = {}
  if type(panel) ~= "table" then return out end
  for _, k in ipairs(COND_KEYS) do
    local v = panel[k]
    local t = type(v)
    if t == "boolean" or t == "number" or t == "string" then
      out[k] = v
    end
  end
  return out
end

local function snapshotProfile(p)
  p = type(p) == "table" and p or {}
  return {
    enabled = not not p.enabled,
    name = tostring(p.name or ""),
    Visible = p.Visible ~= false,
    Cooldown = p.Cooldown ~= false,
    Interval = p.Interval ~= false,
    Conditions = p.Conditions ~= false,
    Delay = p.Delay ~= false,
    MessageDelay = not not p.MessageDelay,
    spells = mapFromList(p.spellTable),
    items = mapFromList(p.itemTable)
  }
end

local function buildHealSnapshot()
  local hb = HealBotConfig.healbot
  if type(hb) ~= "table" then hb = {} end
  local profiles = {}
  for i = 1, 5 do
    profiles[tostring(i)] = snapshotProfile(pickIndex(hb, i))
  end
  profiles._n = 5
  return {
    current = tonumber(HealBotConfig.currentHealBotProfile) or 1,
    profiles = profiles,
    conditions = snapshotConditions(HealBotConfig.ConditionPanel)
  }
end

local function applyProfile(snap)
  local p = {
    enabled = not not snap.enabled,
    name = tostring(snap.name or ""),
    Visible = snap.Visible ~= false,
    Cooldown = snap.Cooldown ~= false,
    Interval = snap.Interval ~= false,
    Conditions = snap.Conditions ~= false,
    Delay = snap.Delay ~= false,
    MessageDelay = not not snap.MessageDelay,
    spellTable = {},
    itemTable = {}
  }
  local spells = snap.spells or snap.spellTable
  local items = snap.items or snap.itemTable
  for i, e in ipairs(listFromMap(spells)) do
    p.spellTable[i] = {
      index = i,
      spell = tostring(e.spell or ""),
      sign = tostring(e.sign or "<"),
      origin = tostring(e.origin or "HP%"),
      cost = tonumber(e.cost) or 0,
      value = tonumber(e.value) or 0,
      enabled = e.enabled ~= false
    }
  end
  for i, e in ipairs(listFromMap(items)) do
    p.itemTable[i] = {
      index = i,
      item = tonumber(e.item) or 0,
      sign = tostring(e.sign or "<"),
      origin = tostring(e.origin or "HP%"),
      value = tonumber(e.value) or 0,
      enabled = e.enabled ~= false
    }
  end
  return p
end

local function applyHealSnapshot(src)
  if type(src) ~= "table" then return false end
  local applied = false
  if type(src.profiles) == "table" or type(src.healbot) == "table" then
    local hb = {}
    if type(src.profiles) == "table" then
      for i = 1, 5 do
        local sp = pickIndex(src.profiles, i) or src.profiles[tostring(i)]
        hb[i] = applyProfile(type(sp) == "table" and sp or {})
      end
    else
      local raw = normalizeHealbotArray(src.healbot)
      for i = 1, 5 do
        hb[i] = applyProfile(pickIndex(raw, i) or {})
      end
    end
    HealBotConfig.healbot = hb
    applied = true
  end
  local cond = src.conditions or src.ConditionPanel
  if type(cond) == "table" then
    HealBotConfig.ConditionPanel = HealBotConfig.ConditionPanel or {}
    for k, v in pairs(snapshotConditions(cond)) do
      HealBotConfig.ConditionPanel[k] = v
    end
    applied = true
  end
  local cur = tonumber(src.current or src.currentHealBotProfile)
  if cur and cur >= 1 and cur <= 5 then
    HealBotConfig.currentHealBotProfile = cur
  end
  return applied
end

local function encodePlain(tbl)
  local data = copyPlain(tbl) or {}
  local ok, payload = pcall(function() return json.encode(data, 2) end)
  if not (ok and type(payload) == "string") then
    ok, payload = pcall(function() return json.encode(data) end)
  end
  if ok and type(payload) == "string" then return payload end
  return nil
end

local function decodeSetupJson(raw)
  if type(raw) ~= "string" or raw == "" or raw == "{}" or raw == "[]" then
    return nil
  end
  local ok, data = pcall(function() return json.decode(raw) end)
  if ok and type(data) == "table" then return data end
  return nil
end

function noxSnapshotHeal()
  if type(storage) ~= "table" then return end
  local snap = buildHealSnapshot()
  local function countSnapRules(s)
    if type(s) ~= "table" or type(s.profiles) ~= "table" then return 0 end
    local n = 0
    for i = 1, 5 do
      local p = s.profiles[tostring(i)] or s.profiles[i]
      if type(p) == "table" then
        for _, key in ipairs({ "spells", "spellTable", "items", "itemTable" }) do
          local t = p[key]
          if type(t) == "table" then
            for k, v in pairs(t) do
              if k ~= "_n" and k ~= "count" and type(v) == "table" then
                n = n + 1
              end
            end
          end
        end
      end
    end
    return n
  end
  -- No pisar un setup bueno con un snapshot accidentalmente vacio (Off/On / UI sin refrescar).
  if countSnapRules(snap) == 0 then
    local old = decodeSetupJson(storage.healSetupJson)
    if not old and type(storage.healSetup) == "table" then old = storage.healSetup end
    if old and countSnapRules(old) > 0 then
      return
    end
  end
  storage.healSetup = snap
  local encoded = encodePlain(snap)
  if encoded then storage.healSetupJson = encoded end
  local n = tonumber(snap.current) or 1
  local p = pickIndex(snap.profiles, n)
  if type(p) == "table" then storage.healBotEnabled = not not p.enabled end
  if type(snap.conditions) == "table" then
    storage.conditionsEnabled = not not snap.conditions.enabled
  end
end

-- Setup (spells/items) en current.json. Si hay reglas ahi, ganan sobre HealBot.json vacio/stale.
if type(storage) == "table" then
  local src = decodeSetupJson(storage.healSetupJson)
  if not src and type(storage.healSetup) == "table" then
    src = storage.healSetup
  end
  if src then
    local function countSrcRules(s)
      if type(s) ~= "table" then return 0 end
      local profiles = s.profiles or s.healbot
      if type(profiles) ~= "table" then return 0 end
      local n = 0
      for i = 1, 5 do
        local p = profiles[i] or profiles[tostring(i)]
        if type(p) == "table" then
          for _, key in ipairs({ "spells", "spellTable", "items", "itemTable" }) do
            local t = p[key]
            if type(t) == "table" then
              for k, v in pairs(t) do
                if k ~= "_n" and k ~= "count" and type(v) == "table" then
                  n = n + 1
                end
              end
            end
          end
        end
      end
      return n
    end
    if countSrcRules(src) > 0 then
      applyHealSnapshot(src)
    end
  end
end
if type(HealBotConfig.healbot) == "table" then
  HealBotConfig.healbot = normalizeHealbotArray(HealBotConfig.healbot)
end

local function refreshPaths()
  configName = resolveConfigName()
  profile = getProfile()
  ensureAllDirs(configName)
  profileBase, healBotFile, attackBotFile, suppliesFile = pathsFor(configName, profile)
  ensureDir(profileBase)
end

local function snapshotAttackProfile(p, i)
  p = type(p) == "table" and p or {}
  local enabled = not not p.enabled
  if type(storage) == "table" and type(storage.attackBotEnabled) == "boolean" then
    local cur = tonumber((AttackBotConfig and AttackBotConfig.currentBotProfile) or 1) or 1
    if tonumber(i) == cur then
      enabled = storage.attackBotEnabled == true
    end
  end
  return {
    enabled = enabled,
    attackTable = mapFromList(p.attackTable),
    ignoreMana = p.ignoreMana ~= false,
    Kills = not not p.Kills,
    Rotate = not not p.Rotate,
    name = (type(p.name) == "string" and p.name ~= "") and p.name or ("Profile #" .. tostring(i or 1)),
    Cooldown = p.Cooldown ~= false,
    Visible = false,
    pvpMode = not not p.pvpMode,
    KillsAmount = tonumber(p.KillsAmount) or 1,
    PvpSafe = p.PvpSafe ~= false,
    BlackListSafe = not not p.BlackListSafe,
    AntiRsRange = tonumber(p.AntiRsRange) or 5,
    Training = not not p.Training
  }
end

local function snapshotAttackBot(cfg)
  cfg = type(cfg) == "table" and cfg or {}
  local panel = {}
  local src = cfg.AttackBot
  if type(src) ~= "table" then src = {} end
  for i = 1, 5 do
    panel[tostring(i)] = snapshotAttackProfile(src[i] or src[tostring(i)], i)
  end
  panel._n = 5
  return {
    currentBotProfile = tonumber(cfg.currentBotProfile) or 1,
    AttackBot = panel
  }
end

function vBotConfigSave(which)
  if not which then return end
  which = tostring(which):lower()
  refreshPaths()

  local file, tbl
  if which == "heal" then
    file, tbl = healBotFile, HealBotConfig
  elseif which == "atk" then
    file, tbl = attackBotFile, AttackBotConfig
  elseif which == "supply" then
    file, tbl = suppliesFile, SuppliesConfig
  else
    return
  end

  local payload
  if which == "heal" then
    payload = encodePlain(tbl)
  elseif which == "atk" then
    tbl = normalizeAttackBotConfig(tbl or AttackBotConfig)
    AttackBotConfig = tbl
    -- mapFromList + _n: OTC no tira el Spell Shooter al Off/On
    payload = encodePlain(snapshotAttackBot(tbl))
  else
    local ok, encoded = pcall(function() return json.encode(tbl or {}, 2) end)
    if not (ok and type(encoded) == "string") then
      ok, encoded = pcall(function() return json.encode(tbl or {}) end)
    end
    if ok and type(encoded) == "string" then payload = encoded end
  end
  if type(payload) ~= "string" then
    if type(onError) == "function" then
      onError("Error encoding config: " .. tostring(file))
    end
    return
  end

  if which == "atk" and type(storage) == "table" then
    storage.attackSetupJson = payload
  end

  local function tryWrite()
    physWrite(file, payload)
    if which == "atk" then
      -- espejo en storage/ por si vBot_configs falla en algun cliente
      local cfg = resolveConfigName()
      physWrite("/noxbot/" .. cfg .. "/storage/AttackBot.json", payload)
    elseif which == "heal" then
      local cfg = resolveConfigName()
      physWrite("/noxbot/" .. cfg .. "/storage/HealBot.json", payload)
    end
  end

  local wok, werr = pcall(tryWrite)
  if not wok then
    refreshPaths()
    wok, werr = pcall(tryWrite)
  end
  if not wok and type(onError) == "function" then
    onError("No se pudo guardar " .. tostring(file) .. ": " .. tostring(werr))
  end
end

-- alias por si algun script usa otro nombre
vBotConfigSave = vBotConfigSave

-- Sin autoguardado periodico: guarda en Off del bot, Close de ventanas y al salir.
-- (El macro cada 15s era hitch + coñazo en Nostalrius.)
