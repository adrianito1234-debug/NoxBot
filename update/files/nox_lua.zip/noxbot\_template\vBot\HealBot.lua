local standBySpells = false
local standByItems = false

local red = "#ff0800" -- "#ff0800" / #ea3c53 best
local blue = "#7ef9ff"

setDefaultTab("HP")
local healPanelName = "healbot"
local ui = setupUI([[
Panel
  height: 40

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    text-align: center
    width: 130
    !text: tr('HealBot')

  Button
    id: settings
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 3
    height: 17
    text: Setup

  Button
    id: 1
    anchors.top: prev.bottom
    anchors.left: parent.left
    text: 1
    margin-right: 2
    margin-top: 4
    size: 17 17

  Button
    id: 2
    anchors.verticalCenter: prev.verticalCenter
    anchors.left: prev.right
    text: 2
    margin-left: 4
    size: 17 17

  Button
    id: 3
    anchors.verticalCenter: prev.verticalCenter
    anchors.left: prev.right
    text: 3
    margin-left: 4
    size: 17 17

  Button
    id: 4
    anchors.verticalCenter: prev.verticalCenter
    anchors.left: prev.right
    text: 4
    margin-left: 4
    size: 17 17

  Button
    id: 5
    anchors.verticalCenter: prev.verticalCenter
    anchors.left: prev.right
    text: 5
    margin-left: 4
    size: 17 17

  Label
    id: name
    anchors.verticalCenter: prev.verticalCenter
    anchors.left: prev.right
    anchors.right: parent.right
    text-align: center
    margin-left: 4
    height: 17
    text: Profile #1
    background: #292A2A
]])
if not ui then return end
ui:setId(healPanelName)

for i = 1, 5 do
  local b = ui:recursiveGetChildById(tostring(i))
  if b then b:hide() end
end
local profileNameLabel = ui:recursiveGetChildById("name")
if profileNameLabel then profileNameLabel:hide() end

local function defaultHealProfile(i)
  return {
    enabled = false,
    spellTable = {},
    itemTable = {},
    name = "Profile #" .. i,
    Visible = true,
    Cooldown = true,
    Interval = true,
    Conditions = false,
    Delay = true,
    MessageDelay = false
  }
end

-- Completa huecos. NUNCA pisa spellTable/itemTable que ya vinieron de storage.
if type(HealBotConfig[healPanelName]) ~= "table" then
  HealBotConfig[healPanelName] = {}
end
do
  local src = HealBotConfig[healPanelName]
  if not src[1] and (src["1"] or src[0]) then
    local fixed = {}
    for i = 1, 5 do
      fixed[i] = src[i] or src[tostring(i)]
    end
    HealBotConfig[healPanelName] = fixed
    src = fixed
  end
  for i = 1, 5 do
    local p = src[i] or src[tostring(i)]
    if type(p) ~= "table" then
      src[i] = defaultHealProfile(i)
    else
      src[i] = p
      if type(p.spellTable) ~= "table" then p.spellTable = {} end
      if type(p.itemTable) ~= "table" then p.itemTable = {} end
      -- JSON OTC: claves "1","2"+_n. Compactar a array real para # y la UI.
      if type(noxAsList) == "function" then
        p.spellTable = noxAsList(p.spellTable)
        p.itemTable = noxAsList(p.itemTable)
      end
      if type(p.name) ~= "string" or p.name == "" then p.name = "Profile #" .. i end
    end
  end
end

if not HealBotConfig.currentHealBotProfile or HealBotConfig.currentHealBotProfile == 0 or HealBotConfig.currentHealBotProfile > 5 then
  HealBotConfig.currentHealBotProfile = 1
end

-- finding correct table, manual unfortunately
local currentSettings
local setActiveProfile = function()
  local n = HealBotConfig.currentHealBotProfile
  currentSettings = HealBotConfig[healPanelName][n]
end
setActiveProfile()

local function healOrigin(entry)
  local o = tostring(entry and entry.origin or "HP%")
  if o == "Current Health" then return "HP" end
  if o == "Current Mana" then return "MP" end
  if o == "Health Percent" then return "HP%" end
  if o == "Mana Percent" then return "MP%" end
  if o == "Burst Damage" then return "burst" end
  return o
end

local function isHpHealOrigin(entry)
  local o = healOrigin(entry)
  return o == "HP%" or o == "HP" or o == "burst"
end

local function healSpellOnCooldown(words)
  if type(words) ~= "string" or words == "" then return false end
  local cd = false
  pcall(function()
    if getSpellCoolDown and getSpellCoolDown(words) then cd = true end
  end)
  return cd
end

-- Plan B: tiro como Xyro HealBot — g_game.useInventoryItemWith(id, player).
-- Manas ceden a healFirst. ID = el del drag.
local function fireHealItem(itemId, isHpHeal)
  itemId = tonumber(itemId) or 0
  if itemId <= 100 then return false end
  if not isHpHeal then
    if type(vBot) == "table" and type(vBot.healFirst) == "function" and vBot.healFirst() then
      return false
    end
  end
  if type(TargetBot) == "table" and type(TargetBot.useItem) == "function" then
    pcall(function() TargetBot.useItem(itemId, nil, player) end)
    return true
  end
  pcall(function() g_game.useInventoryItemWith(itemId, player) end)
  return true
end

local function matchesHealTrigger(entry)
  if type(entry) ~= "table" or entry.enabled == false then
    return false
  end
  local sign = tostring(entry.sign or "<")
  local value = tonumber(entry.value) or 0
  local function check(current)
    current = tonumber(current) or 0
    if sign == "=" then
      return current == value
    elseif sign == ">" then
      return current >= value
    end
    return current <= value
  end
  local origin = healOrigin(entry)
  if origin == "HP%" then
    return check(hppercent())
  elseif origin == "HP" then
    return check(hp())
  elseif origin == "MP%" then
    return check(manapercent())
  elseif origin == "MP" then
    return check(mana())
  elseif origin == "burst" then
    return check(burstDamageValue())
  end
  return false
end

local activeProfileColor = function()
  for i=1,5 do
    if i == HealBotConfig.currentHealBotProfile then
      ui[i]:setColor("green")
    else
      ui[i]:setColor("white")
    end
  end
end
activeProfileColor()

-- Igual que Manatrain: el switch vive SOLO en storage.healbot.enabled.
-- HealBot.json / flags / g_settings ya no tocan este boton.
if type(storage.healbot) ~= "table" then storage.healbot = {} end
if type(storage.healbot.enabled) ~= "boolean" then
  storage.healbot.enabled = false
end
currentSettings.enabled = storage.healbot.enabled

local function persistHeal()
  pcall(function()
    if type(noxSnapshotHeal) == "function" then noxSnapshotHeal() end
  end)
  pcall(function()
    if type(vBotConfigSave) == "function" then vBotConfigSave("heal") end
  end)
end

local function syncHealSwitch()
  if type(storage.healbot) ~= "table" then storage.healbot = {} end
  currentSettings.enabled = storage.healbot.enabled
  pcall(function() ui.title:setOn(storage.healbot.enabled) end)
end

ui.title:setOn(storage.healbot.enabled)
ui.title.onClick = function(widget)
  storage.healbot.enabled = not storage.healbot.enabled
  currentSettings.enabled = storage.healbot.enabled
  widget:setOn(storage.healbot.enabled)
end

ui.settings.onClick = function(widget)
  healWindow:show()
  healWindow:raise()
  healWindow:focus()
end

rootWidget = g_ui.getRootWidget()
if rootWidget then
  healWindow = UI.createWindow('HealWindow', rootWidget)
  healWindow:hide()

  healWindow.onVisibilityChange = function(widget, visible)
    if not visible then
      persistHeal()
      healWindow.healer:show()
      healWindow.settings:hide()
      healWindow.settingsButton:setText("Settings")
    end
  end

  healWindow.settingsButton.onClick = function(widget)
    if healWindow.healer:isVisible() then
      healWindow.healer:hide()
      healWindow.settings:show()
      widget:setText("Back")
    else
      healWindow.healer:show()
      healWindow.settings:hide()
      widget:setText("Settings")
    end
  end

  local setProfileName = function()
    ui.name:setText(currentSettings.name)
  end
  healWindow.settings.profiles.Name.onTextChange = function(widget, text)
    currentSettings.name = text
    setProfileName()
    persistHeal()
  end
  healWindow.settings.list.Visible.onClick = function(widget)
    currentSettings.Visible = not currentSettings.Visible
    healWindow.settings.list.Visible:setChecked(currentSettings.Visible)
    persistHeal()
  end
  healWindow.settings.list.Cooldown.onClick = function(widget)
    currentSettings.Cooldown = not currentSettings.Cooldown
    healWindow.settings.list.Cooldown:setChecked(currentSettings.Cooldown)
    persistHeal()
  end
  healWindow.settings.list.Interval.onClick = function(widget)
    currentSettings.Interval = not currentSettings.Interval
    healWindow.settings.list.Interval:setChecked(currentSettings.Interval)
    persistHeal()
  end
  healWindow.settings.list.Conditions.onClick = function(widget)
    currentSettings.Conditions = not currentSettings.Conditions
    healWindow.settings.list.Conditions:setChecked(currentSettings.Conditions)
    persistHeal()
  end
  healWindow.settings.list.Delay.onClick = function(widget)
    currentSettings.Delay = not currentSettings.Delay
    healWindow.settings.list.Delay:setChecked(currentSettings.Delay)
    persistHeal()
  end
  healWindow.settings.list.MessageDelay.onClick = function(widget)
    currentSettings.MessageDelay = not currentSettings.MessageDelay
    healWindow.settings.list.MessageDelay:setChecked(currentSettings.MessageDelay)
    persistHeal()
  end

  local refreshSpells = function()
    if currentSettings.spellTable then
      if type(noxAsList) == "function" then
        currentSettings.spellTable = noxAsList(currentSettings.spellTable)
      end
      healWindow.healer.spells.spellList:destroyChildren()
      for _, entry in ipairs(currentSettings.spellTable) do
        if type(entry) == "table" then
          local label = UI.createWidget("SpellEntry", healWindow.healer.spells.spellList)
          label.enabled:setChecked(entry.enabled)
          label.enabled.onClick = function(widget)
            standBySpells = false
            standByItems = false
            entry.enabled = not entry.enabled
            label.enabled:setChecked(entry.enabled)
            persistHeal()
          end
          label.remove.onClick = function(widget)
            standBySpells = false
            standByItems = false
            table.removevalue(currentSettings.spellTable, entry)
            reindexTable(currentSettings.spellTable)
            label:destroy()
            persistHeal()
          end
          label:setText("(MP>" .. entry.cost .. ") " .. entry.origin .. entry.sign .. entry.value .. ": " .. entry.spell)
        end
      end
    end
  end
  refreshSpells()

  local refreshItems = function()
    if currentSettings.itemTable then
      if type(noxAsList) == "function" then
        currentSettings.itemTable = noxAsList(currentSettings.itemTable)
      end
      healWindow.healer.items.itemList:destroyChildren()
      for _, entry in ipairs(currentSettings.itemTable) do
        if type(entry) == "table" then
          local label = UI.createWidget("ItemEntry", healWindow.healer.items.itemList)
          label.enabled:setChecked(entry.enabled)
          label.enabled.onClick = function(widget)
            standBySpells = false
            standByItems = false
            entry.enabled = not entry.enabled
            label.enabled:setChecked(entry.enabled)
            persistHeal()
          end
          label.remove.onClick = function(widget)
            standBySpells = false
            standByItems = false
            table.removevalue(currentSettings.itemTable, entry)
            reindexTable(currentSettings.itemTable)
            label:destroy()
            persistHeal()
          end
          label.id:setItemId(entry.item)
          label:setText(entry.origin .. entry.sign .. entry.value .. ": " .. entry.item)
        end
      end
    end
  end
  refreshItems()

  healWindow.healer.spells.MoveUp.onClick = function(widget)
    local input = healWindow.healer.spells.spellList:getFocusedChild()
    if not input then return end
    local index = healWindow.healer.spells.spellList:getChildIndex(input)
    if index < 2 then return end

    local t = currentSettings.spellTable

    t[index],t[index-1] = t[index-1], t[index]
    healWindow.healer.spells.spellList:moveChildToIndex(input, index - 1)
    healWindow.healer.spells.spellList:ensureChildVisible(input)
    persistHeal()
  end

  healWindow.healer.spells.MoveDown.onClick = function(widget)
    local input = healWindow.healer.spells.spellList:getFocusedChild()
    if not input then return end
    local index = healWindow.healer.spells.spellList:getChildIndex(input)
    if index >= healWindow.healer.spells.spellList:getChildCount() then return end

    local t = currentSettings.spellTable

    t[index],t[index+1] = t[index+1],t[index]
    healWindow.healer.spells.spellList:moveChildToIndex(input, index + 1)
    healWindow.healer.spells.spellList:ensureChildVisible(input)
    persistHeal()
  end

  healWindow.healer.items.MoveUp.onClick = function(widget)
    local input = healWindow.healer.items.itemList:getFocusedChild()
    if not input then return end
    local index = healWindow.healer.items.itemList:getChildIndex(input)
    if index < 2 then return end

    local t = currentSettings.itemTable

    t[index],t[index-1] = t[index-1], t[index]
    healWindow.healer.items.itemList:moveChildToIndex(input, index - 1)
    healWindow.healer.items.itemList:ensureChildVisible(input)
    persistHeal()
  end

  healWindow.healer.items.MoveDown.onClick = function(widget)
    local input = healWindow.healer.items.itemList:getFocusedChild()
    if not input then return end
    local index = healWindow.healer.items.itemList:getChildIndex(input)
    if index >= healWindow.healer.items.itemList:getChildCount() then return end

    local t = currentSettings.itemTable

    t[index],t[index+1] = t[index+1],t[index]
    healWindow.healer.items.itemList:moveChildToIndex(input, index + 1)
    healWindow.healer.items.itemList:ensureChildVisible(input)
    persistHeal()
  end

  healWindow.healer.spells.addSpell.onClick = function(widget)

    local spellFormula = healWindow.healer.spells.spellFormula:getText():trim()
    local manaCost = tonumber(healWindow.healer.spells.manaCost:getText())
    local spellTrigger = tonumber(healWindow.healer.spells.spellValue:getText())
    local spellSource = healWindow.healer.spells.spellSource:getCurrentOption().text
    local spellEquasion = healWindow.healer.spells.spellCondition:getCurrentOption().text
    local source
    local equasion

    if not manaCost then
      warn("HealBot: incorrect mana cost value!")
      healWindow.healer.spells.spellFormula:setText('')
      healWindow.healer.spells.spellValue:setText('')
      healWindow.healer.spells.manaCost:setText('')
      return
    end
    if not spellTrigger then
      warn("HealBot: incorrect condition value!")
      healWindow.healer.spells.spellFormula:setText('')
      healWindow.healer.spells.spellValue:setText('')
      healWindow.healer.spells.manaCost:setText('')
      return
    end

    if spellSource == "Current Mana" then
      source = "MP"
    elseif spellSource == "Current Health" then
      source = "HP"
    elseif spellSource == "Mana Percent" then
      source = "MP%"
    elseif spellSource == "Health Percent" then
      source = "HP%"
    else
      source = "burst"
    end

    if spellEquasion == "Above" then
      equasion = ">"
    elseif spellEquasion == "Below" then
      equasion = "<"
    else
      equasion = "="
    end

    if spellFormula:len() > 0 then
      table.insert(currentSettings.spellTable,  {index = #currentSettings.spellTable+1, spell = spellFormula, sign = equasion, origin = source, cost = manaCost, value = spellTrigger, enabled = true})
      healWindow.healer.spells.spellFormula:setText('')
      healWindow.healer.spells.spellValue:setText('')
      healWindow.healer.spells.manaCost:setText('')
    end
    standBySpells = false
    standByItems = false
    refreshSpells()
    persistHeal()
  end

  healWindow.healer.items.addItem.onClick = function(widget)

    local id = healWindow.healer.items.itemId:getItemId()
    local trigger = tonumber(healWindow.healer.items.itemValue:getText())
    local src = healWindow.healer.items.itemSource:getCurrentOption().text
    local eq = healWindow.healer.items.itemCondition:getCurrentOption().text
    local source
    local equasion

    if not trigger then
      warn("HealBot: incorrect trigger value!")
      healWindow.healer.items.itemId:setItemId(0)
      healWindow.healer.items.itemValue:setText('')
      return
    end

    if src == "Current Mana" then
      source = "MP"
    elseif src == "Current Health" then
      source = "HP"
    elseif src == "Mana Percent" then
      source = "MP%"
    elseif src == "Health Percent" then
      source = "HP%"
    else
      source = "burst"
    end

    if eq == "Above" then
      equasion = ">"
    elseif eq == "Below" then
      equasion = "<"
    else
      equasion = "="
    end

    if id > 100 then
      table.insert(currentSettings.itemTable, {index = #currentSettings.itemTable+1,item = id, sign = equasion, origin = source, value = trigger, enabled = true})
      standBySpells = false
      standByItems = false
      refreshItems()
      healWindow.healer.items.itemId:setItemId(0)
      healWindow.healer.items.itemValue:setText('')
      persistHeal()
    end
  end

  healWindow.closeButton.onClick = function(widget)
    healWindow:hide()
  end

  local loadSettings = function()
    currentSettings.enabled = storage.healbot.enabled
    ui.title:setOn(storage.healbot.enabled)
    setProfileName()
    healWindow.settings.profiles.Name:setText(currentSettings.name)
    refreshSpells()
    refreshItems()
    healWindow.settings.list.Visible:setChecked(currentSettings.Visible)
    healWindow.settings.list.Cooldown:setChecked(currentSettings.Cooldown)
    healWindow.settings.list.Delay:setChecked(currentSettings.Delay)
    healWindow.settings.list.MessageDelay:setChecked(currentSettings.MessageDelay)
    healWindow.settings.list.Interval:setChecked(currentSettings.Interval)
    healWindow.settings.list.Conditions:setChecked(currentSettings.Conditions)
  end
  loadSettings()

  local profileChange = function()
    setActiveProfile()
    activeProfileColor()
    loadSettings()
    persistHeal()
  end

  local resetSettings = function()
    currentSettings.enabled = false
    currentSettings.spellTable = {}
    currentSettings.itemTable = {}
    currentSettings.Visible = true
    currentSettings.Cooldown = true
    currentSettings.Delay = true
    currentSettings.MessageDelay = false
    currentSettings.Interval = true
    currentSettings.Conditions = true
    currentSettings.name = "Profile #" .. HealBotConfig.currentBotProfile
  end

  -- profile buttons
  for i=1,5 do
    local button = ui[i]
      button.onClick = function()
      HealBotConfig.currentHealBotProfile = i
      profileChange()
    end
  end

  healWindow.settings.profiles.ResetSettings.onClick = function()
    resetSettings()
    loadSettings()
    persistHeal()
  end

  -- public functions
  HealBot = {} -- global table

  HealBot.isOn = function()
    return storage.healbot and storage.healbot.enabled
  end

  HealBot.isOff = function()
    return not (storage.healbot and storage.healbot.enabled)
  end

  HealBot.setOff = function()
    storage.healbot.enabled = false
    syncHealSwitch()
  end

  HealBot.setOn = function()
    storage.healbot.enabled = true
    syncHealSwitch()
  end

  HealBot.restore = function(on)
    storage.healbot.enabled = not not on
    syncHealSwitch()
  end

  HealBot.getActiveProfile = function()
    return HealBotConfig.currentHealBotProfile -- returns number 1-5
  end

  HealBot.setActiveProfile = function(n)
    if not n or not tonumber(n) or n < 1 or n > 5 then
      return error("[HealBot] wrong profile parameter! should be 1 to 5 is " .. n)
    else
      HealBotConfig.currentHealBotProfile = n
      profileChange()
    end
  end

  HealBot.show = function()
    -- UI fuera del cliente (ImGui). El motor sigue aqui.
  end

  -- Prioridad absoluta: si una regla HP del usuario dispara (el % que puso),
  -- NADIE mas gasta mana (ni SD, ni magias, ni haste, ni manatrain).
  -- No exige mana: si no hay mana, igual se cede el turno para no tirar ataques.
  HealBot.needsHealing = function()
    if not currentSettings or not storage.healbot.enabled then
      return false
    end
    for _, entry in pairs(currentSettings.spellTable or {}) do
      if isHpHealOrigin(entry) and matchesHealTrigger(entry) then
        return true
      end
    end
    for _, entry in pairs(currentSettings.itemTable or {}) do
      if isHpHealOrigin(entry) and matchesHealTrigger(entry) then
        return true
      end
    end
    return false
  end
end

-- 25ms: un poco mas rapido que antes (40ms). El CD del server sigue mandando.
-- Si refresca rapido solo reintenta say; no spamea casts validos de mas.
macro(25, function()
  if not currentSettings or not storage.healbot.enabled then return end
  if standBySpells then return end
  local list = currentSettings.spellTable
  if type(list) ~= "table" then return end
  if type(noxAsList) == "function" then
    list = noxAsList(list)
    currentSettings.spellTable = list
  end
  local needHpSpell = false
  for _, entry in ipairs(list) do
    if type(entry) == "table" and entry.enabled ~= false
        and isHpHealOrigin(entry) and matchesHealTrigger(entry) then
      needHpSpell = true
      break
    end
  end
  local somethingIsOnCooldown = false
  local anyEnabled = false
  local function trySpell(entry, hpOnly)
    if type(entry) ~= "table" or entry.enabled == false then return false end
    anyEnabled = true
    if hpOnly and not isHpHealOrigin(entry) then return false end
    if not hpOnly and needHpSpell then return false end
    local cost = tonumber(entry.cost) or 0
    local words = tostring(entry.spell or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if words == "" or mana() < cost or not matchesHealTrigger(entry) then return false end
    if type(warnSpellLevel) == "function" and not warnSpellLevel(words) then
      return false
    elseif hpOnly then
      -- HP: sin groupBusy ni Cooldown interno; el server manda. Tira en cuanto toca.
    elseif vBot.spellReady and not vBot.spellReady(words) then
      somethingIsOnCooldown = true
      return false
    elseif currentSettings.Cooldown and healSpellOnCooldown(words) then
      somethingIsOnCooldown = true
      return false
    end
    -- sayHeal: no lo bloquea healFirst (antes solo pasaba exura* y el resto "fingia" cast).
    if type(vBot) == "table" and type(vBot.sayHeal) == "function" then
      return vBot.sayHeal(words)
    end
    say(words)
    return true
  end
  if needHpSpell then
    for _, entry in ipairs(list) do
      if trySpell(entry, true) then return end
    end
    return
  end
  for _, entry in ipairs(list) do
    if trySpell(entry, false) then return end
  end
  if anyEnabled and not somethingIsOnCooldown then
    standBySpells = true
  end
end)

-- items (Plan B: delay/tiro como Xyro; prioridad HP + healFirst en manas)
macro(100, function()
  if standByItems then return end
  if not currentSettings or not storage.healbot.enabled then return end
  local items = currentSettings.itemTable
  if type(items) ~= "table" then return end
  local empty = true
  for _ in pairs(items) do empty = false break end
  if empty then return end

  local needHpItemNow = false
  for _, entry in pairs(items) do
    if type(entry) == "table" and entry.enabled ~= false
        and isHpHealOrigin(entry) and matchesHealTrigger(entry) then
      needHpItemNow = true
      break
    end
  end

  -- Manas "Aaaah..." no frenan UH.
  if not needHpItemNow and currentSettings.MessageDelay and vBot.isUsingPotion then
    return
  end
  if currentSettings.Delay and vBot.isUsing and not needHpItemNow then
    return
  end

  if not needHpItemNow and not currentSettings.MessageDelay then
    delay(400, "healing")
  end
  if TargetBot.isOn() and TargetBot.Looting.getStatus():len() > 0 and currentSettings.Interval then
    if not needHpItemNow and not currentSettings.MessageDelay then
      delay(700, "healing")
    else
      delay(200, "healing")
    end
  end

  -- 1) HP heals primero (UH / health item)
  local triedHpHeal = false
  for _, entry in pairs(items) do
    if type(entry) == "table" and entry.enabled ~= false
        and isHpHealOrigin(entry) and matchesHealTrigger(entry) then
      -- Como Xyro: Visible solo si esta activado; si off, hotkey sin ver.
      if currentSettings.Visible and type(findItem) == "function" and not findItem(tonumber(entry.item) or 0) then
        -- siguiente
      else
        triedHpHeal = true
        fireHealItem(entry.item, true)
        return
      end
    end
  end

  -- 2) Mana / otros
  if needHpItemNow then return end
  if type(vBot) == "table" and type(vBot.healFirst) == "function" and vBot.healFirst() then
    return
  end
  for _, entry in pairs(items) do
    if type(entry) == "table" and entry.enabled ~= false and matchesHealTrigger(entry)
        and not isHpHealOrigin(entry) then
      if currentSettings.Visible and type(findItem) == "function" then
        if not findItem(tonumber(entry.item) or 0) then
          -- siguiente
        else
          fireHealItem(entry.item, false)
          return
        end
      else
        fireHealItem(entry.item, false)
        return
      end
    end
  end
  if not triedHpHeal then
    standByItems = true
  end
end)

onPlayerHealthChange(function(healthPercent)
  standByItems = false
  standBySpells = false
end)

pcall(function()
  onHealthChange(function()
    standByItems = false
    standBySpells = false
  end)
end)

onManaChange(function(player, mana, maxMana, oldMana, oldMaxMana)
  standByItems = false
  standBySpells = false
end)

syncHealSwitch()

