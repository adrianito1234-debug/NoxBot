-- NoxBot Private Script: Bosstimer
noxCommunityScript(function(config)
  if type(config.enabled) ~= "boolean" then config.enabled = false end

-- CaveBot Function

-- START CONFIG
local intervalo = (2 * 60 * 60) -- (em segundos) 2h x 60min x 60s
local nome_da_label = "goBoss" -- ir para essa label se já passou o intervalo
-- END CONFIG

config.lastBoss = config.lastBoss or os.time()
if os.time() - config.lastBoss >= intervalo then
  gotoLabel(nome_da_label)
  config.lastBoss = os.time()
end
return true
end)