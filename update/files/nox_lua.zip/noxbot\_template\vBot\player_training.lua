if type(setDefaultTab) ~= "function" then function setDefaultTab(name) end end
setDefaultTab("Tools")

UI.Separator()
UI.Label("Player Training")
UI.Separator()

local partyFriends = addToggle("autoPartyFriends", "Auto Party Friends")

local SHIELD_NONE = 0
local SHIELD_INVITED_ME = 1
local SHIELD_INVITED_BY_ME = 2

local leaderShields = { [4] = true, [6] = true, [8] = true, [10] = true }

macro(1000, function()
  if not partyFriends.enabled then return end

  local myShield = player:getShield()
  local canInvite = myShield == SHIELD_NONE or leaderShields[myShield]
  local canJoin = myShield == SHIELD_NONE or myShield == SHIELD_INVITED_BY_ME

  for _, spec in ipairs(getSpectators()) do
    if spec:isPlayer() and not spec:isLocalPlayer() and isFriend(spec) then
      local friendShield = spec:getShield()

      if canJoin and friendShield == SHIELD_INVITED_ME then
        return g_game.partyJoin(spec:getId())
      end

      if canInvite and friendShield == SHIELD_NONE then
        return g_game.partyInvite(spec:getId())
      end
    end
  end
end)

local attackFriend = addToggle("autoAttackFriend", "Auto Attack Friend")

local partyShields = { [3] = true, [4] = true, [5] = true, [6] = true,
                       [7] = true, [8] = true, [9] = true, [10] = true }

local function isPartyFriend(creature)
  if not creature:isPlayer() or creature:isLocalPlayer() then return false end
  if not partyShields[creature:getShield()] then return false end

  return isFriend(creature)
end

macro(500, function()
  if not attackFriend.enabled then return end

  local attacking = g_game.getAttackingCreature()

  if attacking and isFriend(attacking) and not partyShields[attacking:getShield()] then
    return g_game.cancelAttack()
  end

  if not partyShields[player:getShield()] then return end
  if attacking and isPartyFriend(attacking) then return end

  for _, spec in ipairs(getSpectators()) do
    if isPartyFriend(spec) then
      return g_game.attack(spec)
    end
  end
end)

local pickUp, pickUpWindow = addMaker("pickUp", "Pick up", "PickUpWindow", "Edit")

if type(pickUp.items) ~= "table" then
  pickUp.items = {}
end
if type(pickUp.equip) ~= "boolean" then
  pickUp.equip = type(pickUp.pickUpEquip) == "boolean" and pickUp.pickUpEquip or false
end

UI.Container(function(widget, items)
  pickUp.items = items
end, true, nil, pickUpWindow.pickUpItems)

pickUpWindow.pickUpItems:setItems(pickUp.items)

bindSwitch(pickUpWindow.doEquip, pickUp, "equip")

local function entryIdOf(entry)
  return type(entry) == "number" and entry or entry.id
end

local function idVariants(itemId)
  return { itemId, getInactiveItemId(itemId), getActiveItemId(itemId) }
end

local function matchesWantedId(itemId, wantedId)
  for _, variant in ipairs(idVariants(wantedId)) do
    if itemId == variant then return true end
  end

  return false
end

local function isWantedId(itemId)
  for _, entry in ipairs(pickUp.items) do
    if matchesWantedId(itemId, entryIdOf(entry)) then return true end
  end

  return false
end

local function isEquippedWanted(wantedId)
  for _, hand in ipairs({ getLeft(), getRight() }) do
    if hand and matchesWantedId(hand:getId(), wantedId) then
      return true
    end
  end

  return false
end

local function findWantedItem(wantedId)
  for _, container in pairs(getContainers()) do
    for _, containerItem in ipairs(container:getItems()) do
      if matchesWantedId(containerItem:getId(), wantedId) then
        return containerItem
      end
    end
  end

  for _, variant in ipairs(idVariants(wantedId)) do
    local item = findItem(variant)
    if item then return item end
  end
end

local function findHandSlotFor(wantedId)
  if isEquippedWanted(wantedId) then return nil end

  if not getLeft() then return SlotLeft end
  if not getRight() then return SlotRight end

  local left = getLeft()
  if left and not isWantedId(left:getId()) then return SlotLeft end

  local right = getRight()
  if right and not isWantedId(right:getId()) then return SlotRight end

  return nil
end

local function inventorySlotPosition(slot)
  return { x = 65535, y = slot, z = 0 }
end

local function tryEquipWanted(wantedId)
  local slot = findHandSlotFor(wantedId)
  if not slot then return false end

  local item = findWantedItem(wantedId)
  if not item then return false end

  g_game.move(item, inventorySlotPosition(slot), item:getCount())
  return true
end

local unitWeight = {}
local measuring = nil

local function resolveMeasure()
  if not measuring then return end

  local used = measuring.capBefore - freecap()
  if used > 0 then
    unitWeight[measuring.id] = used
  end

  measuring = nil
end

local function countThatFits(item)
  local itemId = item:getId()
  local weight = unitWeight[itemId]

  if not weight then
    measuring = { id = itemId, capBefore = freecap() }
    return 1
  end

  local fits = math.floor(freecap() / weight)
  if fits < 1 then return 0 end

  return math.min(item:getCount(), fits)
end

local function destinationSlot(itemId)
  local containers = getContainers()

  for _, container in pairs(containers) do
    for slot, containerItem in ipairs(container:getItems()) do
      if containerItem:getId() == itemId and containerItem:getCount() < 100 then
        return container:getSlotPosition(slot - 1)
      end
    end
  end

  for _, container in pairs(containers) do
    if container:getItemsCount() < container:getCapacity() then
      return container:getSlotPosition(container:getItemsCount())
    end
  end
end

local function findGroundItem()
  local playerPos = player:getPosition()
  if not playerPos then return nil end

  for offsetX = -1, 1 do
    for offsetY = -1, 1 do
      local tile = g_map.getTile({x = playerPos.x + offsetX, y = playerPos.y + offsetY, z = playerPos.z})

      if tile then
        for _, item in ipairs(tile:getItems()) do
          if isWantedId(item:getId()) then
            return item
          end
        end
      end
    end
  end
end

macro(300, function()
  if not pickUp.enabled then return end
  if not pickUp.items[1] then return end

  if pickUp.equip then
    for _, entry in ipairs(pickUp.items) do
      if tryEquipWanted(entryIdOf(entry)) then
        return
      end
    end
  end

  resolveMeasure()

  local item = findGroundItem()
  if not item then return end

  local count = countThatFits(item)
  if count < 1 then return end

  local slot = destinationSlot(item:getId())
  if not slot then return end

  g_game.move(item, slot, count)
end)
