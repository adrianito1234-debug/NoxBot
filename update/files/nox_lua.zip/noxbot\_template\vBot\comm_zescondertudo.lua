-- NoxBot Private Script: Escondertudo
noxCommunityScript(function(config)
  if type(config.enabled) ~= "boolean" then config.enabled = false end

local fxMacro = macro(213131311, "Escondertudo",function()end)

onAddThing(function(tile,thing)
  if fxMacro:isOff() then return end
  thing:setHidden(true)
end)

onStaticText(function(thing, text)
  if fxMacro:isOff() then return end
  g_map.cleanTexts()
end)

onAnimatedText(function(thing,text)
  if fxMacro:isOff() then return end
  g_map.cleanTexts()
end)
end)