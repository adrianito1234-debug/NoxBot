setDefaultTab("HP")

if type(storage.foodItems) ~= "table" then
  storage.foodItems = {3582, 3577}
end
if type(noxAsList) == "function" then
  storage.foodItems = noxAsList(storage.foodItems)
end
if type(storage.eatFood) ~= "table" then
  storage.eatFood = {}
end
local config = storage.eatFood
if type(config.enabled) ~= "boolean" then config.enabled = false end
if type(config.castFood) ~= "boolean" then config.castFood = false end
if type(config.spell) ~= "string" or config.spell == "" then config.spell = "exevo pan" end
if type(config.delay) ~= "number" or config.delay < 1 then config.delay = 30 end

local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    text-align: center
    width: 130
    !text: tr('Eat Food')

  Button
    id: setup
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 3
    height: 17
    text: Setup
]])
if not ui then return end
ui:setId("eatFood")

ui.title:setOn(config.enabled)
ui.title.onClick = function(widget)
  config.enabled = not config.enabled
  widget:setOn(config.enabled)
end

local window = UI.createWindow("EatFoodWindow")
window:hide()

UI.Container(function(widget, items)
  storage.foodItems = items
end, true, nil, window.foodItems)
window.foodItems:setItems(storage.foodItems)

window.foodSpell:setText(config.spell)
window.foodSpell.onTextChange = function(widget, text)
  config.spell = text
end

window.castFood:setOn(config.castFood)
window.castFood.onClick = function(widget)
  config.castFood = not config.castFood
  widget:setOn(config.castFood)
end

window.delayLabel:setText("Eat Delay: " .. config.delay)
window.eatDelay:setValue(config.delay)
window.eatDelay.onValueChange = function(scroll, value)
  config.delay = value
  window.delayLabel:setText("Eat Delay: " .. value)
end

window.closeButton.onClick = function()
  window:hide()
end

ui.setup.onClick = function()
  window:show()
  window:raise()
  window:focus()
end

local nextActionAt = 0
macro(500, function()
  if not config.enabled then return end
  if (player:getRegenerationTime() or 0) > 400 then return end
  if now < nextActionAt then return end
  nextActionAt = now + (config.delay * 1000) + math.random(0, 400)

  if config.castFood then
    if config.spell and config.spell ~= "" then
      cast(config.spell, 5000)
    end
    return
  end

  for _, container in pairs(g_game.getContainers()) do
    for __, item in ipairs(container:getItems()) do
      for i, foodItem in ipairs(storage.foodItems) do
        local fid = noxItemId and noxItemId(foodItem) or (type(foodItem) == "table" and foodItem.id or foodItem)
        if fid and item:getId() == fid then
          return g_game.use(item)
        end
      end
    end
  end
end)
