﻿setDefaultTab('main')
-- locales
local panelName = "AttackBot"
local currentSettings
local showSettings = false
local showItem = false
local category = 1
local patternCategory = 1
local pattern = 1
local mainWindow

-- label library

local categories = {
  "Targeted Spell (exori hur, exori flam, etc)",
  "Area Rune (avalanche, great fireball, etc)",
  "Targeted Rune (sudden death, icycle, etc)",
  "Empowerment (utito tempo, etc)",
  "Absolute Spell (exori, hells core, etc)",
}

local patterns = {
  -- targeted spells
  {
    "1 Sqm Range (exori ico)",
    "2 Sqm Range",
    "3 Sqm Range (strike spells)",
    "4 Sqm Range (exori san)",
    "5 Sqm Range (exori hur)",
    "6 Sqm Range",
    "7 Sqm Range (exori con)",
    "8 Sqm Range",
    "9 Sqm Range",
    "10 Sqm Range"
  },
  -- area runes
  {
    "Cross (explosion)",
    "Bomb (fire bomb)",
    "Ball (gfb, avalanche)"
  },
  -- empowerment/targeted rune
  {
    "1 Sqm Range",
    "2 Sqm Range",
    "3 Sqm Range",
    "4 Sqm Range",
    "5 Sqm Range",
    "6 Sqm Range",
    "7 Sqm Range",
    "8 Sqm Range",
    "9 Sqm Range",
    "10 Sqm Range",
  },
  -- absolute
  {
    "Adjacent (exori, exori gran)",
    "3x3 Wave (vis hur, tera hur)",
    "Small Area (mas san, exori mas)",
    "Medium Area (mas flam, mas frigo)",
    "Large Area (mas vis, mas tera)",
    "Short Beam (vis lux)",
    "Large Beam (gran vis lux)",
    "Sweep (exori min)", -- 8
    "Small Wave (gran frigo hur)",
    "Big Wave (flam hur, frigo hur)",
    "Huge Wave (gran flam hur)",
  }
}

  -- spellPatterns[category][pattern][1 - normal, 2 - safe]
local spellPatterns = {
  {}, -- blank, wont be used
  -- Area Runes,
  {
    {     -- cross
     [[
      010
      111
      010
     ]],
     -- cross SAFE
     [[
       01110
       01110
       11111
       11111
       11111
       01110
       01110
     ]]
    },
    { -- bomb
      [[
        111
        111
        111
      ]],
      -- bomb SAFE
      [[
        11111
        11111
        11111
        11111
        11111
      ]]
    },
    { -- ball
      [[
        0011100
        0111110
        1111111
        1111111
        1111111
        0111110
        0011100
      ]],
      -- ball SAFE
      [[
        000111000
        001111100
        011111110
        111111111
        111111111
        111111111
        011111110
        001111100
        000111000
      ]]
    },
  },
  {}, -- blank, wont be used
  -- Absolute
  {
    {-- adjacent
      [[
        111
        111
        111
      ]],
      -- adjacent SAFE
      [[
        11111
        11111
        11111
        11111
        11111
      ]]
    },
    { -- 3x3 Wave
      [[
        0000NNN0000
        0000NNN0000
        0000NNN0000
        00000N00000
        WWW00N00EEE
        WWWWW0EEEEE
        WWW00S00EEE
        00000S00000
        0000SSS0000
        0000SSS0000
        0000SSS0000
      ]],
      -- 3x3 Wave SAFE
      [[
        0000NNNNN0000
        0000NNNNN0000
        0000NNNNN0000
        0000NNNNN0000
        WWWW0NNN0EEEE
        WWWWWNNNEEEEE
        WWWWWW0EEEEEE
        WWWWWSSSEEEEE
        WWWW0SSS0EEEE
        0000SSSSS0000
        0000SSSSS0000
        0000SSSSS0000
        0000SSSSS0000
      ]]
    },
    { -- small area
      [[
        0011100
        0111110
        1111111
        1111111
        1111111
        0111110
        0011100
      ]],
      -- small area SAFE
      [[
        000111000
        001111100
        011111110
        111111111
        111111111
        111111111
        011111110
        001111100
        000111000
      ]]
    },
    { -- medium area
      [[
        00000100000
        00011111000
        00111111100
        01111111110
        01111111110
        11111111111
        01111111110
        01111111110
        00111111100
        00001110000
        00000100000
      ]],
      -- medium area SAFE
      [[
        0000011100000
        0000111110000
        0001111111000
        0011111111100
        0111111111110
        0111111111110
        1111111111111
        0111111111110
        0111111111110
        0011111111100
        0001111111000
        0000111110000
        0000011100000
      ]]
    },
    { -- large area
      [[
        0000001000000
        0000011100000
        0000111110000
        0001111111000
        0011111111100
        0111111111110
        1111111111111
        0111111111110
        0011111111100
        0001111111000
        0000111110000
        0000011100000
        0000001000000
      ]],
      -- large area SAFE
      [[
        000000010000000
        000000111000000
        000001111100000
        000011111110000
        000111111111000
        001111111111100
        011111111111110
        111111111111111
        011111111111110
        001111111111100
        000111111111000
        000011111110000
        000001111100000
        000000111000000
        000000010000000
      ]]
    },
    { -- short beam
      [[
        00000N00000
        00000N00000
        00000N00000
        00000N00000
        00000N00000
        WWWWW0EEEEE
        00000S00000
        00000S00000
        00000S00000
        00000S00000
        00000S00000
      ]],
      -- short beam SAFE
      [[
        00000NNN00000
        00000NNN00000
        00000NNN00000
        00000NNN00000
        00000NNN00000
        WWWWWNNNEEEEE
        WWWWWW0EEEEEE
        00000SSS00000
        00000SSS00000
        00000SSS00000
        00000SSS00000
        00000SSS00000
        00000SSS00000
      ]]
    },
    { -- large beam
      [[
        0000000N0000000
        0000000N0000000
        0000000N0000000
        0000000N0000000
        0000000N0000000
        0000000N0000000
        0000000N0000000
        WWWWWWW0EEEEEEE
        0000000S0000000
        0000000S0000000
        0000000S0000000
        0000000S0000000
        0000000S0000000
        0000000S0000000
        0000000S0000000
      ]],
      -- large beam SAFE
      [[
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        WWWWWWWNNNEEEEEEE
        WWWWWWWW0EEEEEEEE
        WWWWWWWSSSEEEEEEE
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
      ]],
    },
    {}, -- sweep, wont be used
    { -- small wave
      [[
        00NNN00
        00NNN00
        WW0N0EE
        WWW0EEE
        WW0S0EE
        00SSS00
        00SSS00
      ]],
      -- small wave SAFE
      [[
        00NNNNN00
        00NNNNN00
        WWNNNNNEE
        WWWWNEEEE
        WWWW0EEEE
        WWWWSEEEE
        WWSSSSSEE
        00SSSSS00
        00SSSSS00
      ]]
    },
    { -- large wave
      [[
        000NNNNN000
        000NNNNN000
        0000NNN0000
        WW00NNN00EE
        WWWW0N0EEEE
        WWWWW0EEEEE
        WWWW0S0EEEE
        WW00SSS00EE
        0000SSS0000
        000SSSSS000
        000SSSSS000
      ]],
      [[
        000NNNNNNN000
        000NNNNNNN000
        000NNNNNNN000
        WWWWNNNNNEEEE
        WWWWNNNNNEEEE
        WWWWWNNNEEEEE
        WWWWWW0EEEEEE
        WWWWWSSSEEEEE
        WWWWSSSSSEEEE
        WWWWSSSSSEEEE
        000SSSSSSS000
        000SSSSSSS000
        000SSSSSSS000
      ]]
    },
    { -- huge wave
      [[
        0000NNNNN0000
        0000NNNNN0000
        00000NNN00000
        00000NNN00000
        WW0000N0000EE
        WWWW00N00EEEE
        WWWWWW0EEEEEE
        WWWW00S00EEEE
        WW0000S0000EE
        00000SSS00000
        00000SSS00000
        0000SSSSS0000
        0000SSSSS0000
      ]],
      [[
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        WWWWWWWNNNEEEEEEE
        WWWWWWWW0EEEEEEEE
        WWWWWWWSSSEEEEEEE
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
      ]]
    }
  }
}

-- direction patterns
local ek = (voc() == 1 or voc() == 11) and true

local posN = ek and [[
  111
  000
  000
]] or [[
  00011111000
  00011111000
  00011111000
  00011111000
  00000100000
  00000000000
  00000000000
  00000000000
  00000000000
  00000000000
  00000000000
]]

local posE = ek and [[
  001
  001
  001
]] or   [[
  00000000000
  00000000000
  00000000000
  00000001111
  00000001111
  00000011111
  00000001111
  00000001111
  00000000000
  00000000000
  00000000000
]]
local posS = ek and [[
  000
  000
  111
]] or   [[
  00000000000
  00000000000
  00000000000
  00000000000
  00000000000
  00000000000
  00000100000
  00011111000
  00011111000
  00011111000
  00011111000
]]
local posW = ek and [[
  100
  100
  100
]] or   [[
  00000000000
  00000000000
  00000000000
  11110000000
  11110000000
  11111000000
  11110000000
  11110000000
  00000000000
  00000000000
  00000000000
]]

-- AttackBotConfig
-- Completa huecos. NUNCA pisa attackTable que ya vino de disco/storage.
if type(AttackBotConfig) ~= "table" then AttackBotConfig = {} end
if type(AttackBotConfig[panelName]) ~= "table" then
  AttackBotConfig[panelName] = {}
end
do
  local src = AttackBotConfig[panelName]
  if not src[1] and (src["1"] or src[0]) then
    local fixed = {}
    for i = 1, 5 do
      fixed[i] = src[i] or src[tostring(i)] or src[i - 1]
    end
    AttackBotConfig[panelName] = fixed
    src = fixed
  end
  local function defaultProfile(i)
    return {
      enabled = false,
      attackTable = {},
      ignoreMana = true,
      Kills = false,
      Rotate = false,
      name = "Profile #" .. i,
      Cooldown = true,
      Visible = false,
      pvpMode = false,
      KillsAmount = 1,
      PvpSafe = true,
      BlackListSafe = false,
      AntiRsRange = 5,
      Training = false
    }
  end
  local function toAttackList(tbl)
    local list = {}
    if type(tbl) ~= "table" then return list end
    for i, e in ipairs(tbl) do
      if type(e) == "table" then list[#list + 1] = e end
    end
    if #list > 0 then return list end
    local n = 0
    for k in pairs(tbl) do
      local i = tonumber(k)
      if i and i > n then n = i end
    end
    for i = 1, n do
      local e = tbl[i] or tbl[tostring(i)]
      if type(e) == "table" then list[#list + 1] = e end
    end
    return list
  end
  for i = 1, 5 do
    local p = src[i] or src[tostring(i)]
    if type(p) ~= "table" then
      src[i] = defaultProfile(i)
    else
      src[i] = p
      p.attackTable = toAttackList(p.attackTable)
      if type(p.name) ~= "string" or p.name == "" then p.name = "Profile #" .. i end
      if p.AntiRsRange == nil then p.AntiRsRange = 5 end
    end
  end
end

if not AttackBotConfig.currentBotProfile or AttackBotConfig.currentBotProfile == 0 or AttackBotConfig.currentBotProfile > 5 then
  AttackBotConfig.currentBotProfile = 1
end

-- create panel UI
ui = UI.createWidget("AttackBotBotPanel")
pcall(function()
  if ui.title then
    if ui.title.setHeight then ui.title:setHeight(17) end
  end
  if ui.settings then
    ui.settings:setText("Setup")
    if ui.settings.setFont then ui.settings:setFont("verdana-11px-rounded") end
    if ui.settings.setHeight then ui.settings:setHeight(17) end
  end
end)

for i = 1, 5 do
  local b = ui:recursiveGetChildById(tostring(i))
  if b then b:hide() end
end
local profileNameLabel = ui:recursiveGetChildById("name")
if profileNameLabel then profileNameLabel:hide() end

-- finding correct table, manual unfortunately
-- AttackBot On/Off: igual que HealBot, vive en storage para sobrevivir Off/On.
if type(storage) ~= "table" then storage = {} end
if type(storage.attackBotEnabled) ~= "boolean" then
  local p = AttackBotConfig and AttackBotConfig[panelName]
    and (AttackBotConfig[panelName][AttackBotConfig.currentBotProfile]
      or AttackBotConfig[panelName][tostring(AttackBotConfig.currentBotProfile or 1)])
  storage.attackBotEnabled = type(p) == "table" and not not p.enabled
end
do
  local n = AttackBotConfig.currentBotProfile or 1
  local p = AttackBotConfig[panelName] and (AttackBotConfig[panelName][n] or AttackBotConfig[panelName][tostring(n)])
  if type(p) == "table" then
    p.enabled = storage.attackBotEnabled == true
  end
end

local setActiveProfile = function()
  local n = AttackBotConfig.currentBotProfile
  currentSettings = AttackBotConfig[panelName][n]
  if type(currentSettings) == "table" then
    currentSettings.enabled = storage.attackBotEnabled == true
  end
end
setActiveProfile()

if not currentSettings.AntiRsRange then
  currentSettings.AntiRsRange = 5
end

local setProfileName = function()
  ui.name:setText(currentSettings.name)
end

local function syncAttackEnabled(on)
  on = not not on
  storage.attackBotEnabled = on
  setActiveProfile()
  if type(currentSettings) == "table" then
    currentSettings.enabled = on
  end
  pcall(function() ui.title:setOn(on) end)
end

-- small UI elements
ui.title.onClick = function(widget)
  syncAttackEnabled(not (storage.attackBotEnabled == true))
  vBotConfigSave("atk")
  if type(saveConfig) == "function" then pcall(saveConfig) end
end

ui.settings.onClick = function(widget)
  mainWindow:show()
  mainWindow:raise()
  mainWindow:focus()
end

  mainWindow = UI.createWindow("AttackBotWindow")
  mainWindow:hide()

  local panel = mainWindow.mainPanel
  local settingsUI = mainWindow.settingsPanel

  -- Nostalrius: SpinBox default max=1 si el OTUI no aplica min/max
  local function forceSpin(w, minv, maxv, val)
    if not w then return end
    pcall(function()
      if w.setMinimum then w:setMinimum(minv) end
      if w.setMaximum then w:setMaximum(maxv) end
      w.minimum = minv
      w.maximum = maxv
      if val ~= nil and w.setValue then w:setValue(val) end
    end)
  end
  forceSpin(panel.manaPercent, 0, 99, 1)
  forceSpin(panel.creatures, 1, 99, 1)
  forceSpin(panel.minHp, 0, 99, 0)
  forceSpin(panel.maxHp, 1, 100, 100)
  forceSpin(panel.cooldown, 0, 999999, 0)
  forceSpin(settingsUI.KillsAmount, 1, 10)
  forceSpin(settingsUI.AntiRsRange, 1, 10)

  local function saveAttacks(opts)
    opts = opts or {}
    setActiveProfile()
    if opts.fromUI then
      local list = {}
      local kids = {}
      pcall(function() kids = panel.entryList:getChildren() or {} end)
      for _, child in ipairs(kids) do
        if type(child) == "table" and type(child.params) == "table" then
          list[#list + 1] = child.params
        end
      end
      if #list > 0 or opts.allowEmpty then
        currentSettings.attackTable = list
      end
    end
    if type(currentSettings) == "table" then
      -- Items must be visible: siempre OFF (usar runas desde BP)
      currentSettings.Visible = false
      if type(currentSettings.attackTable) ~= "table" then
        currentSettings.attackTable = {}
      end
    end
    vBotConfigSave("atk")
    setActiveProfile()
  end

  mainWindow.onVisibilityChange = function(widget, visible)
    if not visible then
      -- Solo persiste memoria; no reconstruir desde UI
      vBotConfigSave("atk")
    end
  end

  -- main panel

    -- functions
    function toggleSettings()
      panel:setVisible(not showSettings)
      mainWindow.shooterLabel:setVisible(not showSettings)
      settingsUI:setVisible(showSettings)
      mainWindow.settingsLabel:setVisible(showSettings)
      mainWindow.settings:setText(showSettings and "Back" or "Settings")
    end
    toggleSettings()

    mainWindow.settings.onClick = function()
      showSettings = not showSettings
      toggleSettings()
    end

    function toggleItem()
      panel.monsters:setWidth(showItem and 405 or 341)
      panel.itemId:setVisible(showItem)
      panel.spellName:setVisible(not showItem)
    end
    toggleItem()

    function setCategoryText()
      panel.category.description:setText(categories[category])
    end
    setCategoryText()

    function setPatternText()
      panel.range.description:setText(patterns[patternCategory][pattern])
    end
    setPatternText()

    -- in/de/crementation buttons
    panel.previousCategory.onClick = function()
      if category == 1 then
        category = #categories
      else
        category = category - 1
      end

      showItem = (category == 2 or category == 3) and true or false
      patternCategory = category == 4 and 3 or category == 5 and 4 or category
      -- Targeted rune: default 8 sqm (SD). Resto empieza en 1.
      pattern = (category == 3) and 8 or 1
      toggleItem()
      setPatternText()
      setCategoryText()
    end
    panel.nextCategory.onClick = function()
      if category == #categories then
        category = 1
      else
        category = category + 1
      end

      showItem = (category == 2 or category == 3) and true or false
      patternCategory = category == 4 and 3 or category == 5 and 4 or category
      pattern = (category == 3) and 8 or 1
      toggleItem()
      setPatternText()
      setCategoryText()
    end
    panel.previousSource.onClick = function()
    end
    panel.nextSource.onClick = function()
    end
    panel.previousRange.onClick = function()
      local t = patterns[patternCategory]
      if pattern == 1 then
        pattern = #t
      else
        pattern = pattern - 1
      end
      setPatternText()
    end
    panel.nextRange.onClick = function()
      local t = patterns[patternCategory]
      if pattern == #t then
        pattern = 1
      else
        pattern = pattern + 1
      end
      setPatternText()
    end
    -- eo in/de/crementation

  ------- [[core table function]] -------
    function setupWidget(widget)
      local params = widget.params

      widget:setText(params.description)
      if params.itemId > 0 then
        widget.spell:setVisible(false)
        widget.id:setVisible(true)
        widget.id:setItemId(params.itemId)
      end
      widget:setTooltip(params.tooltip)
      widget.remove.onClick = function()
        panel.up:setEnabled(false)
        panel.down:setEnabled(false)
        widget:destroy()
        saveAttacks({ fromUI = true, allowEmpty = true })
      end
      widget.enabled:setChecked(params.enabled)
      widget.enabled.onClick = function()
        params.enabled = not params.enabled
        widget.enabled:setChecked(params.enabled)
        saveAttacks({ fromUI = true })
      end
      -- will serve as edit
      widget.onDoubleClick = function(widget)
        panel.manaPercent:setValue(params.mana)
        panel.creatures:setValue(params.count)
        panel.minHp:setValue(params.minHp)
        panel.maxHp:setValue(params.maxHp)
        panel.cooldown:setValue(params.cooldown)
        showItem = params.itemId > 100 and true or false
        panel.itemId:setItemId(params.itemId)
        panel.spellName:setText(params.spell or "")
        panel.orMore:setChecked(params.orMore)
        toggleItem()
        category = params.category
        patternCategory = params.patternCategory
        pattern = params.pattern
        setPatternText()
        setCategoryText()
        widget:destroy()
        -- Quitar de memoria ya; al pulsar New se vuelve a meter
        saveAttacks({ fromUI = true, allowEmpty = true })
      end
      widget.onClick = function(widget)
        if #panel.entryList:getChildren() == 1 then
          panel.up:setEnabled(false)
          panel.down:setEnabled(false)
        elseif panel.entryList:getChildIndex(widget) == 1 then
          panel.up:setEnabled(false)
          panel.down:setEnabled(true)
        elseif panel.entryList:getChildIndex(widget) == panel.entryList:getChildCount() then
          panel.up:setEnabled(true)
          panel.down:setEnabled(false)
        else
          panel.up:setEnabled(true)
          panel.down:setEnabled(true)
        end
      end
    end

    -- refreshing values
    function refreshAttacks()
      if not currentSettings.attackTable then
        currentSettings.attackTable = {}
      end
      -- Compacta mapas JSON ("1","2") a array real para #attackTable y el macro.
      do
        local src = currentSettings.attackTable
        local list = {}
        for i, e in ipairs(src) do
          if type(e) == "table" then list[#list + 1] = e end
        end
        if #list == 0 then
          local n = 0
          for k in pairs(src) do
            local i = tonumber(k)
            if i and i > n then n = i end
          end
          for i = 1, n do
            local e = src[i] or src[tostring(i)]
            if type(e) == "table" then list[#list + 1] = e end
          end
        end
        currentSettings.attackTable = list
      end

      panel.entryList:destroyChildren()
      for i, entry in ipairs(currentSettings.attackTable) do
        local label = UI.createWidget("AttackEntry", panel.entryList)
        label.params = entry
        setupWidget(label)
      end
    end
    refreshAttacks()
    panel.up:setEnabled(false)
    panel.down:setEnabled(false)

    -- adding values
    panel.addEntry.onClick = function(wdiget)
      -- first variables
      local creatures = panel.monsters:getText():lower()
      local monsters = (creatures:len() == 0 or creatures == "*" or creatures == "monster names") and true or string.split(creatures, ",")
      local mana = panel.manaPercent:getValue()
      local count = panel.creatures:getValue()
      local minHp = panel.minHp:getValue()
      local maxHp = panel.maxHp:getValue()
      local cooldown = panel.cooldown:getValue()
      local itemId = panel.itemId:getItemId()
      local spell = panel.spellName:getText()
      local tooltip = monsters ~= true and creatures
      local orMore = panel.orMore:isChecked()

      -- validation
      if showItem and itemId < 100 then
        return warn("[AttackBot]: please fill item ID!")
      elseif not showItem and (spell:lower() == "spell name" or spell:len() == 0) then
        return warn("[AttackBot]: please fill spell name!")
      end

      local regex = patternCategory ~= 1 and [[^[^\(]+]] or [[^[^R]+]]
      local rangeLabel = "Range"
      pcall(function()
        local m = regexMatch(patterns[patternCategory][pattern], regex)
        if m and m[1] and m[1][1] then
          rangeLabel = tostring(m[1][1]):gsub("^%s+", ""):gsub("%s+$", "")
        end
      end)
      local categoryName = "attack"
      pcall(function()
        local m = regexMatch(categories[category], [[^[^ ]+]])
        if m and m[1] and m[1][1] then
          categoryName = tostring(m[1][1]):gsub("^%s+", ""):gsub("%s+$", ""):lower()
        end
      end)
      local specificMonsters = monsters == true and "Any Creatures" or "Creatures"
      local attackType = showItem and ("rune " .. itemId) or spell

      local countDescription = orMore and (count .. "+") or tostring(count)

      local params = {
        creatures = creatures,
        monsters = monsters,
        mana = mana,
        count = count,
        minHp = minHp,
        maxHp = maxHp,
        cooldown = cooldown,
        itemId = itemId,
        spell = spell,
        enabled = true,
        category = category,
        patternCategory = patternCategory,
        pattern = pattern,
        tooltip = tooltip,
        orMore = orMore,
        description = "[" .. rangeLabel .. "] " .. countDescription .. " " .. specificMonsters .. ": " .. attackType .. ", " .. categoryName .. " (" .. minHp .. "%-" .. maxHp .. "%)"
      }

      -- Re-bind por si un save anterior regenero AttackBotConfig
      setActiveProfile()
      if type(currentSettings) ~= "table" then
        return warn("[AttackBot]: no active profile")
      end
      if type(currentSettings.attackTable) ~= "table" then
        currentSettings.attackTable = {}
      end
      table.insert(currentSettings.attackTable, params)
      refreshAttacks()
      resetFields()
      saveAttacks()
      -- Tras normalize el save crea tablas nuevas: re-apuntar currentSettings
      setActiveProfile()
      refreshAttacks()
    end

    -- moving values
    -- up
    panel.up.onClick = function(widget)
      local focused = panel.entryList:getFocusedChild()
      local n = panel.entryList:getChildIndex(focused)

      if n-1 == 1 then
        widget:setEnabled(false)
      end
      panel.down:setEnabled(true)
      panel.entryList:moveChildToIndex(focused, n-1)
      panel.entryList:ensureChildVisible(focused)
      saveAttacks({ fromUI = true })
    end
    -- down
    panel.down.onClick = function(widget)
      local focused = panel.entryList:getFocusedChild()
      local n = panel.entryList:getChildIndex(focused)

      if n + 1 == panel.entryList:getChildCount() then
        widget:setEnabled(false)
      end
      panel.up:setEnabled(true)
      panel.entryList:moveChildToIndex(focused, n+1)
      panel.entryList:ensureChildVisible(focused)
      saveAttacks({ fromUI = true })
    end

    panel.removeEntry.onClick = function()
      local focused = panel.entryList:getFocusedChild()
      if not focused then
        return warn("[AttackBot]: select an entry to delete")
      end
      panel.up:setEnabled(false)
      panel.down:setEnabled(false)
      focused:destroy()
      saveAttacks({ fromUI = true, allowEmpty = true })
      refreshAttacks()
    end

  -- [[settings panel]] --
  settingsUI.profileName.onTextChange = function(widget, text)
    currentSettings.name = text
    setProfileName()
    vBotConfigSave("atk")
  end
  settingsUI.IgnoreMana.onClick = function(widget)
    currentSettings.ignoreMana = not currentSettings.ignoreMana
    settingsUI.IgnoreMana:setChecked(currentSettings.ignoreMana)
    vBotConfigSave("atk")
  end
  settingsUI.Rotate.onClick = function(widget)
    currentSettings.Rotate = not currentSettings.Rotate
    settingsUI.Rotate:setChecked(currentSettings.Rotate)
    vBotConfigSave("atk")
  end
  settingsUI.Kills.onClick = function(widget)
    currentSettings.Kills = not currentSettings.Kills
    settingsUI.Kills:setChecked(currentSettings.Kills)
    vBotConfigSave("atk")
  end
  settingsUI.Cooldown.onClick = function(widget)
    currentSettings.Cooldown = not currentSettings.Cooldown
    settingsUI.Cooldown:setChecked(currentSettings.Cooldown)
    vBotConfigSave("atk")
  end
  settingsUI.Visible.onClick = function(widget)
    -- Siempre OFF: runas desde backpack
    currentSettings.Visible = false
    settingsUI.Visible:setChecked(false)
    vBotConfigSave("atk")
  end
  settingsUI.PvpMode.onClick = function(widget)
    currentSettings.pvpMode = not currentSettings.pvpMode
    settingsUI.PvpMode:setChecked(currentSettings.pvpMode)
    vBotConfigSave("atk")
  end
  settingsUI.PvpSafe.onClick = function(widget)
    currentSettings.PvpSafe = not currentSettings.PvpSafe
    settingsUI.PvpSafe:setChecked(currentSettings.PvpSafe)
    vBotConfigSave("atk")
  end
  settingsUI.Training.onClick = function(widget)
    currentSettings.Training = not currentSettings.Training
    settingsUI.Training:setChecked(currentSettings.Training)
    vBotConfigSave("atk")
  end
  settingsUI.BlackListSafe.onClick = function(widget)
    currentSettings.BlackListSafe = not currentSettings.BlackListSafe
    settingsUI.BlackListSafe:setChecked(currentSettings.BlackListSafe)
    vBotConfigSave("atk")
  end
  settingsUI.KillsAmount.onValueChange = function(widget, value)
    currentSettings.KillsAmount = value
    vBotConfigSave("atk")
  end
  settingsUI.AntiRsRange.onValueChange = function(widget, value)
    currentSettings.AntiRsRange = value
    vBotConfigSave("atk")
  end

   -- window elements
  mainWindow.closeButton.onClick = function()
    showSettings = false
    toggleSettings()
    resetFields()
    mainWindow:hide()
  end

  -- core functions
  function resetFields()
    showItem = false
    toggleItem()
    pattern = 1
    patternCategory = 1
    category = 1
    setPatternText()
    setCategoryText()
    panel.manaPercent:setText(1)
    panel.creatures:setText(1)
    panel.minHp:setValue(0)
    panel.maxHp:setValue(100)
    panel.cooldown:setValue(0)
    panel.monsters:setText("monster names")
    panel.itemId:setItemId(0)
    panel.spellName:setText("spell name")
    panel.orMore:setChecked(false)
  end
  resetFields()

  function loadSettings()
    setActiveProfile()
    local on = storage.attackBotEnabled == true
    if type(currentSettings) == "table" then currentSettings.enabled = on end
    ui.title:setOn(on)
    setProfileName()
    refreshAttacks()
    settingsUI.profileName:setText(currentSettings.name)
    settingsUI.Visible:setChecked(false)
    currentSettings.Visible = false
    settingsUI.Cooldown:setChecked(currentSettings.Cooldown)
    settingsUI.PvpMode:setChecked(currentSettings.pvpMode)
    settingsUI.PvpSafe:setChecked(currentSettings.PvpSafe)
    settingsUI.BlackListSafe:setChecked(currentSettings.BlackListSafe)
    settingsUI.AntiRsRange:setValue(currentSettings.AntiRsRange)
    settingsUI.IgnoreMana:setChecked(currentSettings.ignoreMana)
    settingsUI.Rotate:setChecked(currentSettings.Rotate)
    settingsUI.Kills:setChecked(currentSettings.Kills)
    settingsUI.KillsAmount:setValue(currentSettings.KillsAmount)
    settingsUI.Training:setChecked(currentSettings.Training)
  end
  loadSettings()

  local activeProfileColor = function()
    for i=1,5 do
      if i == AttackBotConfig.currentBotProfile then
        ui[i]:setColor("green")
      else
        ui[i]:setColor("white")
      end
    end
  end
  activeProfileColor()

  local profileChange = function()
    setActiveProfile()
    activeProfileColor()
    loadSettings()
    resetFields()
    vBotConfigSave("atk")
  end

  for i=1,5 do
    local button = ui[i]
      button.onClick = function()
      AttackBotConfig.currentBotProfile = i
      profileChange()
    end
  end

    -- public functions
    AttackBot = {} -- global table

    AttackBot.flush = function()
      -- Solo disco. NO sync UI->memoria (en teardown la lista puede ir vacia).
      pcall(function() vBotConfigSave("atk") end)
    end

    AttackBot.isOn = function()
      return storage.attackBotEnabled == true
    end

    AttackBot.isOff = function()
      return storage.attackBotEnabled ~= true
    end

    AttackBot.setOff = function()
      syncAttackEnabled(false)
      vBotConfigSave("atk")
      if type(saveConfig) == "function" then pcall(saveConfig) end
    end

    AttackBot.setOn = function()
      syncAttackEnabled(true)
      vBotConfigSave("atk")
      if type(saveConfig) == "function" then pcall(saveConfig) end
    end

    AttackBot.getActiveProfile = function()
      return AttackBotConfig.currentBotProfile -- returns number 1-5
    end

    AttackBot.setActiveProfile = function(n)
      if not n or not tonumber(n) or n < 1 or n > 5 then
        return error("[AttackBot] wrong profile parameter! should be 1 to 5 is " .. n)
      else
        AttackBotConfig.currentBotProfile = n
        profileChange()
      end
    end

    AttackBot.show = function()
      mainWindow:show()
      mainWindow:raise()
      mainWindow:focus()
    end

-- otui covered, now support functions
function getPattern(category, pattern, safe)
  safe = safe and 2 or 1

  return spellPatterns[category][pattern][safe]
end

function getMonstersInArea(category, posOrCreature, pattern, minHp, maxHp, safePattern, monsterNamesTable)
  -- monsterNamesTable can be nil
  local monsters = 0
  local t = {}
  if monsterNamesTable == true or not monsterNamesTable then
    t = {}
  else
    t = monsterNamesTable
  end

  if safePattern then
    for i, spec in pairs(getSpectators(posOrCreature, safePattern)) do
      if spec ~= player and (spec:isPlayer() and not spec:isPartyMember()) then
        return 0
      end
    end
  end

  if category == 1 or category == 3 or category == 4 then
    if category == 1 or category == 3 then
      local name = getTarget() and getTarget():getName()
      if #t ~= 0 and not table.find(t, name, true) then
        return 0
      end
    end
    for i, spec in pairs(getSpectators()) do
      local specHp = spec:getHealthPercent()
      local name = spec:getName():lower()
      monsters = spec:isMonster() and specHp >= minHp and specHp <= maxHp and (#t == 0 or table.find(t, name, true)) and
                 (g_game.getClientVersion() < 960 or spec:getType() < 3) and monsters + 1 or monsters
    end
    return monsters
  end

  for i, spec in pairs(getSpectators(posOrCreature, pattern)) do
      if spec ~= player then
        local specHp = spec:getHealthPercent()
        local name = spec:getName():lower()
        monsters = spec:isMonster() and specHp >= minHp and specHp <= maxHp and (#t == 0 or table.find(t, name)) and
                   (g_game.getClientVersion() < 960 or spec:getType() < 3) and monsters + 1 or monsters
      end
  end

  return monsters
end

-- for area runes only
-- should return valid targets number (int) and position
function getBestTileByPattern(pattern, minHp, maxHp, safePattern, monsterNamesTable)
  local tiles = g_map.getTiles(posz())
  local targetTile = {amount=0,pos=false}

  for i, tile in pairs(tiles) do
    local tPos = tile:getPosition()
    local distance = distanceFromPlayer(tPos)
    if tile:canShoot() and tile:isWalkable() and distance < 4 then
      local amount = getMonstersInArea(2, tPos, pattern, minHp, maxHp, safePattern, monsterNamesTable)
      if amount > targetTile.amount then
        targetTile = {amount=amount,pos=tPos}
      end
    end
  end

  return targetTile.amount > 0 and targetTile or false
end

-- Per-entry CD (ms). 0 = default; cualquier valor > 0 se respeta (incluye CD 1 para pruebas).
local function resolveEntryCooldown(entry)
  local cd = tonumber(entry.cooldown) or 0
  if cd > 0 then
    return cd
  end
  if type(entry.spell) == "string" and entry.spell:len() > 0 then
    local data = getSpellData(entry.spell:lower())
    if data and data.exhaustion and data.exhaustion >= 100 then
      return data.exhaustion
    end
  end
  return 0
end

-- Runes (SD, GFB, etc.): sin cooldown artificial; el cliente limita cuando puede tirar.
local RuneCastTable = {}

local function resolveRuneCooldown(entry)
  return math.max(0, tonumber(entry.cooldown) or 0)
end

local function isRuneCooldownReady(itemId, cooldownMs)
  if not itemId or itemId <= 100 or not cooldownMs or cooldownMs <= 0 then
    return true
  end
  local rec = RuneCastTable[itemId]
  if not rec then
    return true
  end
  return now - rec.t > rec.d
end

-- Always enforced for AttackBot, even when global "Check spell cooldowns" is off.
local function isEntryCooldownReady(spell, cooldownMs)
  if not cooldownMs or cooldownMs <= 0 or type(spell) ~= "string" then
    return true
  end
  spell = spell:lower()
  if not SpellCastTable[spell] then
    return true
  end
  return now - SpellCastTable[spell].t > SpellCastTable[spell].d
end

-- SD/runas: ID exacto del drag. Como Xyro: useWith(id, target) = hotkey, sin ver BP.
local function useAttackRune(entry, target)
  if not target then return false end
  if type(vBot) == "table" and type(vBot.healFirst) == "function" and vBot.healFirst() then
    return false
  end
  local itemId = tonumber(entry.itemId) or 0
  if itemId <= 100 then return false end
  local cooldown = resolveRuneCooldown(entry)
  if not isRuneCooldownReady(itemId, cooldown) then
    return false
  end

  local ver = 860
  pcall(function() ver = g_game.getClientVersion() or 860 end)
  local st = ver >= 860 and 0 or 1

  -- Raw hotkey (BP cerrada OK). Sin remap de IDs.
  if type(vBot) == "table" and type(vBot.rawUseInventoryItemWith) == "function" then
    pcall(function() vBot.rawUseInventoryItemWith(itemId, target, st) end)
  else
    pcall(function() useWith(itemId, target, st) end)
  end

  if cooldown > 0 then
    RuneCastTable[itemId] = {t = now, d = cooldown}
  end
  -- Sin noteGroup("attack"): ese timer interno dejaba 1 SD y mudo.
  return true
end

function executeAttackBotAction(entry, idOrFormula)
  local cat = tonumber(entry.category) or entry.category
  local casted = false
  if cat == 4 or cat == 5 or cat == 1 then
    local cooldown = resolveEntryCooldown(entry)
    cast(idOrFormula, cooldown >= 100 and cooldown or nil)
    casted = true
  elseif cat == 3 then
    casted = useAttackRune(entry, target())
  end
  if casted and (g_game.getClientVersion() < 960 or not currentSettings.Cooldown) then
    delay(150, "attack")
  end
end

local function shouldYieldToHealing()
  return type(vBot) == "table" and type(vBot.healFirst) == "function" and vBot.healFirst()
end

local function tryAttackEntry(entry, bestSide)
  if not entry or not entry.enabled or manapercent() < (tonumber(entry.mana) or 0) then
    return false
  end

  local itemId = tonumber(entry.itemId) or 0
  local isRune = itemId > 100
  local attackData = isRune and itemId or entry.spell
  local entryCooldown = resolveEntryCooldown(entry)
  local runeCooldown = resolveRuneCooldown(entry)
  local spellReady = (not isRune) and type(attackData) == "string"
    and isEntryCooldownReady(entry.spell, entryCooldown)
    and canCast(entry.spell, not currentSettings.ignoreMana, not currentSettings.Cooldown)
  local runeReady = isRune and isRuneCooldownReady(itemId, runeCooldown)
    and (not currentSettings.Visible or (type(findItem) == "function" and findItem(itemId)))

  if not ((isRune and runeReady) or (not isRune and spellReady)) then
    return false
  end

  local cat = tonumber(entry.category) or entry.category
  local t = target()

  if currentSettings.pvpMode and t and t:getHealthPercent() >= entry.minHp and t:getHealthPercent() <= entry.maxHp and t:canShoot() then
    if cat == 2 then
      warn("[AttackBot] Area Runes cannot be used in PVP situation!")
    else
      executeAttackBotAction(entry, attackData)
      return true
    end
  elseif cat == 4 and not isBuffed() then
    local monsterAmount = getMonstersInArea(entry.category, nil, nil, entry.minHp, entry.maxHp, false, entry.monsters)
    local countOk = entry.orMore and monsterAmount >= entry.count or (not entry.orMore and monsterAmount == entry.count)
    if countOk then
      executeAttackBotAction(entry, attackData)
      return true
    end
  elseif cat == 3 then
    if t then
      local thp = t:getHealthPercent()
      local rangeOk = distanceFromPlayer(t:getPosition()) <= (tonumber(entry.pattern) or 8)
      local hpOk = thp >= (tonumber(entry.minHp) or 0) and thp <= (tonumber(entry.maxHp) or 100)
      if rangeOk and hpOk then
        executeAttackBotAction(entry, attackData)
        return true
      end
    end
  elseif cat == 1 then
    if t then
      local monsterAmount = getMonstersInArea(entry.category, nil, nil, entry.minHp, entry.maxHp, false, entry.monsters)
      local rangeOk = distanceFromPlayer(t:getPosition()) <= (tonumber(entry.pattern) or 8)
      local countOk = entry.orMore and monsterAmount >= entry.count or (not entry.orMore and monsterAmount == entry.count)
      if countOk and rangeOk then
        executeAttackBotAction(entry, attackData)
        return true
      end
    end
  elseif cat == 5 then
    local pCat = entry.patternCategory
    local pattern = entry.pattern
    local anchorParam = (pattern == 2 or pattern == 6 or pattern == 7 or pattern > 9) and player or pos()
    local safe = currentSettings.PvpSafe and spellPatterns[pCat][entry.pattern][2] or false
    local monsterAmount = pCat ~= 8 and getMonstersInArea(entry.category, anchorParam, spellPatterns[pCat][entry.pattern][1], entry.minHp, entry.maxHp, safe, entry.monsters)
    if (pattern ~= 8 and (entry.orMore and monsterAmount >= entry.count or not entry.orMore and monsterAmount == entry.count)) or (pattern == 8 and bestSide >= entry.count and (not currentSettings.PvpSafe or getPlayers(2) == 0)) then
      if (not currentSettings.BlackListSafe or not isBlackListedPlayerInRange(currentSettings.AntiRsRange)) and (not currentSettings.Kills or killsToRs() > currentSettings.KillsAmount) then
        executeAttackBotAction(entry, attackData)
        return true
      end
    end
  elseif cat == 2 then
    local pCat = entry.patternCategory
    local safe = currentSettings.PvpSafe and spellPatterns[pCat][entry.pattern][2] or false
    local data = getBestTileByPattern(spellPatterns[pCat][entry.pattern][1], entry.minHp, entry.maxHp, safe, entry.monsters)
    if data and data.amount and (entry.orMore and data.amount >= entry.count or not entry.orMore and data.amount == entry.count) then
      if (not currentSettings.BlackListSafe or not isBlackListedPlayerInRange(currentSettings.AntiRsRange)) and (not currentSettings.Kills or killsToRs() > currentSettings.KillsAmount) then
        useAttackRune(entry, g_map.getTile(data.pos):getTopUseThing())
        if g_game.getClientVersion() < 960 or not currentSettings.Cooldown then
          delay(150, "attack")
        end
        return true
      end
    end
  end

  return false
end

-- support function covered, now the main loop
macro(50, function()
  if storage.attackBotEnabled ~= true then return end
  setActiveProfile()
  if type(currentSettings) ~= "table" or not currentSettings.enabled then return end
  if shouldYieldToHealing() then return end
  if #currentSettings.attackTable == 0 or isInPz() then return end

  local attackList = currentSettings.attackTable
  if type(attackList) ~= "table" or #attackList == 0 then
    attackList = {}
    pcall(function()
      for _, child in ipairs(panel.entryList:getChildren()) do
        if type(child) == "table" and type(child.params) == "table" then
          attackList[#attackList + 1] = child.params
        end
      end
    end)
  end

  local monstersN = getCreaturesInArea(pos(), posN, 2)
  local monstersE = getCreaturesInArea(pos(), posE, 2)
  local monstersS = getCreaturesInArea(pos(), posS, 2)
  local monstersW = getCreaturesInArea(pos(), posW, 2)
  local posTable = {monstersE, monstersN, monstersS, monstersW}
  local bestSide = 0
  local bestDir
  for i, v in pairs(posTable) do
    if v > bestSide then
      bestSide = v
    end
  end
  if monstersN == bestSide then bestDir = 0
  elseif monstersE == bestSide then bestDir = 1
  elseif monstersS == bestSide then bestDir = 2
  elseif monstersW == bestSide then bestDir = 3
  end

  -- Area spells (exori, etc.) first: instant when monster count is met.
  for i, entry in ipairs(attackList) do
    local cat = tonumber(entry.category) or entry.category
    if cat == 4 or cat == 5 or cat == 2 then
      if tryAttackEntry(entry, bestSide) then return end
    end
  end

  local t = target()
  if not t then return end

  if currentSettings.Training and t:getName():lower():find("training") then return end

  if currentSettings.Rotate then
    if player:getDirection() ~= bestDir and bestSide > 0 then
      turn(bestDir)
      return
    end
  end

  for i, entry in ipairs(attackList) do
    local cat = tonumber(entry.category) or entry.category
    if cat ~= 4 and cat ~= 5 and cat ~= 2 then
      if tryAttackEntry(entry, bestSide) then return end
    end
  end
end)
