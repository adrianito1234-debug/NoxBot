TargetBot.Looting = {}
TargetBot.Looting.list = {} -- list of containers to loot

local ui
local items = {}
local containers = {}
local itemsById = {}
local containersById = {}
local dontSave = false
local corpseDelayWindow = nil

local _deusLoot = nil
local function deusLootBreath()
  if _deusLoot == nil then
    local wd = (g_resources and g_resources.getWriteDir and tostring(g_resources.getWriteDir()):lower()) or ""
    _deusLoot = (wd:find("deusot", 1, true) ~= nil or wd:find("deusold", 1, true) ~= nil)
  end
  if _deusLoot and g_resources and g_resources.writeFileContents then
    pcall(g_resources.writeFileContents, "nox_breath", "1")
  end
end

local function switchOn(id)
  local widget = ui and ui[id]
  return widget ~= nil and widget:isOn() == true
end

local function serverQuicklootOn()
  if switchOn("serverQuickloot") then return true end
  return storage.extras and storage.extras.serverQuickloot == true
end

local function setServerQuickloot(on)
  if ui and ui.serverQuickloot then
    ui.serverQuickloot:setOn(on == true)
  end
  storage.extras = storage.extras or {}
  storage.extras.serverQuickloot = on == true
end

TargetBot.Looting.setup = function()
  ui = UI.createWidget("TargetBotLootingPanel")
  UI.Container(TargetBot.Looting.onItemsUpdate, true, nil, ui.items)
  UI.Container(TargetBot.Looting.onContainersUpdate, true, nil, ui.containers)
  if ui.serverQuickloot then
    ui.serverQuickloot.onClick = function()
      setServerQuickloot(not ui.serverQuickloot:isOn())
      TargetBot.save()
    end
  end
  ui.everyItem.onClick = function()
    ui.everyItem:setOn(not ui.everyItem:isOn())
    TargetBot.save()
  end
  if ui.killAllFirst then
    ui.killAllFirst.onClick = function()
      ui.killAllFirst:setOn(not ui.killAllFirst:isOn())
      TargetBot.save()
    end
  end
  if ui.dragRow then
    ui.dragStackedCorpses = ui.dragRow.dragStackedCorpses
    ui.dragSettings = ui.dragRow.dragSettings
  end
  if ui.dragStackedCorpses then
    ui.dragStackedCorpses.onClick = function()
      ui.dragStackedCorpses:setOn(not ui.dragStackedCorpses:isOn())
      TargetBot.save()
    end
  end
  corpseDelayWindow = UI.createWindow("LootingCorpseDelayWindow")
  corpseDelayWindow:hide()
  corpseDelayWindow.corpseDelay.onClick = function(widget)
    widget:setOn(not widget:isOn())
    TargetBot.save()
  end
  corpseDelayWindow.seconds.onTextChange = function()
    if dontSave then return end
    TargetBot.save()
  end
  corpseDelayWindow.closeButton.onClick = function()
    corpseDelayWindow:hide()
  end
  if ui.dragSettings then
    ui.dragSettings.onClick = function()
      corpseDelayWindow:show()
      corpseDelayWindow:raise()
      corpseDelayWindow:focus()
    end
  end
  ui.maxDangerPanel.value.onTextChange = function()
    local value = tonumber(ui.maxDangerPanel.value:getText())
    if not value then
      ui.maxDangerPanel.value:setText(0)
    end
    if dontSave then return end
    TargetBot.save()
  end
  ui.minCapacityPanel.value.onTextChange = function()
    local value = tonumber(ui.minCapacityPanel.value:getText())
    if not value then
      ui.minCapacityPanel.value:setText(0)
    end
    if dontSave then return end
    TargetBot.save()
  end
end

TargetBot.Looting.onItemsUpdate = function()
  if dontSave then return end
  TargetBot.save()
  TargetBot.Looting.updateItemsAndContainers()
end

TargetBot.Looting.onContainersUpdate = function()
  if dontSave then return end
  TargetBot.save()
  TargetBot.Looting.updateItemsAndContainers()
end

TargetBot.Looting.update = function(data)
  dontSave = true
  TargetBot.Looting.list = {}
  ui.items:setItems(data['items'] or {})
  ui.containers:setItems(data['containers'] or {})
  ui.everyItem:setOn(data['everyItem'])
  do
    local ql = data['serverQuickloot']
    if ql == nil and storage.extras then
      ql = storage.extras.serverQuickloot
    end
    setServerQuickloot(ql == true)
  end
  if ui.killAllFirst then
    ui.killAllFirst:setOn(data['killAllFirst'] == true)
  end
  if ui.dragStackedCorpses then
    ui.dragStackedCorpses:setOn(data['dragStackedCorpses'] == true)
  end
  if corpseDelayWindow then
    corpseDelayWindow.corpseDelay:setOn(data['corpseDelay'] == true)
    corpseDelayWindow.seconds:setText(tostring(tonumber(data['corpseDelaySeconds']) or 10))
  end
  ui.maxDangerPanel.value:setText(data['maxDanger'] or 10)
  ui.minCapacityPanel.value:setText(data['minCapacity'] or 100)
  TargetBot.Looting.updateItemsAndContainers()
  dontSave = false
  --vBot
  vBot.lootConainers = {}
  vBot.lootItems = {}
  for i, item in ipairs(ui.containers:getItems()) do
    table.insert(vBot.lootConainers, item['id'])
  end
  for i, item in ipairs(ui.items:getItems()) do
    table.insert(vBot.lootItems, item['id'])
  end
end

TargetBot.Looting.save = function(data)
  data['items'] = ui.items:getItems()
  data['containers'] = ui.containers:getItems()
  data['maxDanger'] = tonumber(ui.maxDangerPanel.value:getText())
  data['minCapacity'] = tonumber(ui.minCapacityPanel.value:getText())
  data['everyItem'] = ui.everyItem:isOn()
  data['serverQuickloot'] = serverQuicklootOn()
  storage.extras = storage.extras or {}
  storage.extras.serverQuickloot = data['serverQuickloot']
  data['killAllFirst'] = switchOn("killAllFirst")
  data['dragStackedCorpses'] = switchOn("dragStackedCorpses")
  if corpseDelayWindow then
    data['corpseDelay'] = corpseDelayWindow.corpseDelay:isOn()
    data['corpseDelaySeconds'] = tonumber(corpseDelayWindow.seconds:getText()) or 10
  end
end

local function corpseDelayMs()
  if not corpseDelayWindow or not corpseDelayWindow.corpseDelay:isOn() then
    return 0
  end
  local seconds = tonumber(corpseDelayWindow.seconds:getText()) or 10
  if seconds < 0 then seconds = 0 end
  if seconds > 120 then seconds = 120 end
  return seconds * 1000
end

TargetBot.Looting.updateItemsAndContainers = function()
  items = ui.items:getItems()
  containers = ui.containers:getItems()
  itemsById = {}
  containersById = {}
  for i, item in ipairs(items) do
    itemsById[item.id] = 1
  end
  for i, container in ipairs(containers) do
    containersById[container.id] = 1
  end
end

TargetBot.Looting.killAllFirst = function()
  return switchOn("killAllFirst")
end

local waitTill = 0
local waitingForContainer = nil
local activeEntry = nil
local corpseWindow = nil
local lastOpenKey = nil
local lastOpenAt = 0
local openRetryDelay = 0
local status = ""
local lastFoodConsumption = 0
local lootingBusyUntil = 0
local MAX_QUICKLOOT_TRIES = 3
local QUICKLOOT_VERIFY_MS = 50

local function corpseStillThere(tile)
  if not tile then return false end
  local top = tile:getTopUseThing()
  return top ~= nil and top:isContainer()
end

local function corpseKey(pos)
  return pos.x .. "," .. pos.y .. "," .. pos.z
end

local function currentIndex()
  return storage.extras.lootLast and #TargetBot.Looting.list or 1
end

local function removeEntry(entry)
  local list = TargetBot.Looting.list
  for i = #list, 1, -1 do
    if list[i] == entry then
      table.remove(list, i)
      return
    end
  end
end

local function rotateEntry(entry)
  local list = TargetBot.Looting.list
  if #list < 2 then return end
  removeEntry(entry)
  if storage.extras.lootLast then
    table.insert(list, 1, entry)
  else
    list[#list + 1] = entry
  end
end

local function corpseCount(entry)
  return entry.count or 1
end

local function corpseDelayLeft(entry)
  local waitMs = corpseDelayMs()
  if waitMs <= 0 or not entry.lastDeathAt then
    return 0
  end
  return math.max(0, entry.lastDeathAt + waitMs - now)
end

local function finishCorpse(entry)
  if not entry then return end
  entry.count = corpseCount(entry) - 1
  if entry.count > 0 then
    entry.needsNext = true
    entry.lootedItem = entry.openedItem
    entry.openedItem = nil
    entry.tries = 0
    entry.openTries = 0
    entry.underTries = 0
    entry.dragTries = 0
    return
  end
  removeEntry(entry)
end

local function corpsesOnTile(tile)
  local corpses = {}
  for _, item in ipairs(tile:getItems()) do
    if item:isContainer() then
      corpses[#corpses + 1] = item
    end
  end
  return corpses
end

local function freeNeighbor(pos)
  local dirs = { {0, -1}, {1, 0}, {0, 1}, {-1, 0}, {1, -1}, {1, 1}, {-1, 1}, {-1, -1} }
  for _, d in ipairs(dirs) do
    local p = { x = pos.x + d[1], y = pos.y + d[2], z = pos.z }
    local tile = g_map.getTile(p)
    if tile and tile:isWalkable() and not tile:hasCreature() and #corpsesOnTile(tile) == 0 then
      return p
    end
  end
  return nil
end

TargetBot.Looting.getStatus = function()
  return status
end

TargetBot.Looting.isBusy = function()
  if TargetBot.Looting.list[1] then return true end
  if waitTill > now then return true end
  if lootingBusyUntil > now then return true end
  for _, container in pairs(g_game.getContainers()) do
    deusLootBreath()
    if container.lootContainer then return true end
  end
  return false
end

TargetBot.Looting.process = function(targets, dangerLevel)
  local quickloot = serverQuicklootOn()
  if not quickloot then
    if (not items[1] and not ui.everyItem:isOn()) or not containers[1] then
      status = ""
      return false
    end
  end
  if dangerLevel > tonumber(ui.maxDangerPanel.value:getText()) then
    status = "High danger"
    return false
  end
  if not quickloot and player:getFreeCapacity() < tonumber(ui.minCapacityPanel.value:getText()) then
    status = "No cap"
    TargetBot.Looting.list = {}
    for _, container in pairs(g_game.getContainers()) do
      deusLootBreath()
      if container.lootContainer then container.lootContainer = false end
    end
    return false
  end
  local killAllFirst = switchOn("killAllFirst")
  if killAllFirst and targets > 0 then
    local pending = #TargetBot.Looting.list
    status = pending > 0 and ("Loot after (" .. pending .. ")") or ""
    return false
  end
  if waitTill > now then
    return true
  end

  local containers = g_game.getContainers()
  local flaggedContainer = nil
  for index, container in pairs(containers) do
    deusLootBreath()
    if container.lootContainer then
      flaggedContainer = container
      break
    end
  end

  local loot = TargetBot.Looting.list[currentIndex()]
  if loot == nil and not flaggedContainer then
    status = ""
    return false
  end

  local lootContainers = TargetBot.Looting.getLootContainers(containers)

  if not quickloot and not lootContainers[1] then
    -- there's no space, don't loot
    status = "No space"
    return false
  end

  status = "Looting"

  if flaggedContainer then
    TargetBot.Looting.lootContainer(lootContainers, flaggedContainer)
    return true
  end

  local pos = player:getPosition()
  local dist = math.max(math.abs(pos.x-loot.pos.x), math.abs(pos.y-loot.pos.y))
  local maxRange = storage.extras.looting or 40
  local busyFighting = targets > 0
  local dragStacked = switchOn("dragStackedCorpses")

  if loot.pos.z ~= pos.z then
    removeEntry(loot)
    return true
  end
  if dist > maxRange then
    if not busyFighting then
      removeEntry(loot)
    end
    return true
  end
  if loot.tries > 30 then
    removeEntry(loot)
    return true
  end

  local tile = g_map.getTile(loot.pos)
  if not tile then
    removeEntry(loot)
    return true
  end

  local top = tile:getTopUseThing()
  if not top or not top:isContainer() then
    removeEntry(loot)
    return true
  end
  local container = top

  if serverQuicklootOn() then
    -- Quickloot: acercarse a 1 sqm (no ir a pisar el cuerpo).
    -- Si ya estás encima (dist 0) o al lado (dist 1): lotear y listo.
    local walkMax = killAllFirst and math.max(20, maxRange) or 20

    if dist > 1 then
      TargetBot.walkTo(loot.pos, walkMax, {
        ignoreNonPathable = true,
        precision = 1,
        marginMin = 1,
        marginMax = 1
      })
      return true
    end

    if loot.qlWait and now < loot.qlWait then
      status = "Looting"
      return true
    end

    if loot.qlWait and now >= loot.qlWait then
      loot.qlWait = nil
      tile = g_map.getTile(loot.pos)
      if not corpseStillThere(tile) then
        finishCorpse(loot)
        return true
      end
    end

    if (loot.qlTries or 0) >= MAX_QUICKLOOT_TRIES then
      removeEntry(loot)
      return true
    end

    loot.openedItem = container
    if type(g_game.quickLoot) == "function" then
      g_game.quickLoot(container:getPosition(), container:getId(), container:getStackPos())
    else
      g_game.use(container)
    end
    loot.qlTries = (loot.qlTries or 0) + 1
    loot.qlWait = now + QUICKLOOT_VERIFY_MS
    status = "Looting"
    return true
  end

  if loot.approach == nil then
    loot.approach = math.random(0, 2)
  end

  if loot.needsNext and dragStacked and corpseDelayLeft(loot) > 0 then
    local waitTile = g_map.getTile(loot.pos)
    local waitTop = waitTile and waitTile:getTopUseThing()
    if not waitTile or waitTop == loot.lootedItem then
      status = "Corpse delay"
      rotateEntry(loot)
      return true
    end
  end

  local reach = loot.approach
  if loot.needsNext and dragStacked then
    reach = math.min(reach, 1)
  end

  if dist > reach or not tile then
    if not busyFighting then
      if loot.lastDist and dist < loot.lastDist then
        loot.tries = 0
      else
        loot.tries = loot.tries + 1
      end
    end
    loot.lastDist = dist
    local precision = reach
    if loot.tries > 5 then
      loot.approach = 2
      precision = math.min(2, reach)
    end
    local walkMax = 20
    if killAllFirst then
      walkMax = math.max(20, maxRange)
    end
    TargetBot.walkTo(loot.pos, walkMax, { ignoreNonPathable = true, precision = precision })
    return true
  end

  if loot.needsNext then
    if top ~= loot.lootedItem then
      loot.needsNext = nil
      loot.lootedItem = nil
    else
      local below = nil
      for _, corpse in ipairs(corpsesOnTile(tile)) do
        if corpse ~= top then
          below = corpse
          break
        end
      end
      if not below then
        removeEntry(loot)
        return true
      end
      if dragStacked then
        loot.dragTries = (loot.dragTries or 0) + 1
        if loot.dragTries > 4 then
          removeEntry(loot)
          return true
        end
        local dest = freeNeighbor(loot.pos)
        if not dest then
          removeEntry(loot)
          return true
        end
        g_game.move(top, dest, 1)
        waitTill = now + math.random(500, 900)
        return true
      end
      container = below
    end
  end

  loot.openedItem = container

  local openKey = corpseKey(loot.pos)
  if lastOpenKey == openKey and now - lastOpenAt < openRetryDelay then
    return true
  end
  lastOpenKey = openKey
  lastOpenAt = now
  openRetryDelay = math.random(600, 1000)

  loot.openTries = (loot.openTries or 0) + 1
  if loot.openTries > 8 then
    removeEntry(loot)
    return true
  end
  if container ~= top then
    loot.underTries = (loot.underTries or 0) + 1
    if loot.underTries > 4 then
      removeEntry(loot)
      return true
    end
  end

  local reuse = nil
  if corpseWindow then
    for _, opened in pairs(containers) do
      if opened == corpseWindow then
        reuse = opened
        break
      end
    end
  end
  if reuse then
    g_game.open(container, reuse)
  else
    g_game.open(container)
  end
  waitTill = now + (storage.extras.lootDelay or 200) + math.random(50, 250)
  waitingForContainer = container:getId()
  activeEntry = loot

  return true
end

TargetBot.Looting.getLootContainers = function(containers)
  local lootContainers = {}
  local openedContainersById = {}
  local toOpen = nil
  for index, container in pairs(containers) do
    deusLootBreath()
    openedContainersById[container:getContainerItem():getId()] = 1
    if containersById[container:getContainerItem():getId()] and not container.lootContainer then
      if container:getItemsCount() < container:getCapacity() or container:hasPages() then
        table.insert(lootContainers, container)
      else -- it's full, open next container if possible
        for slot, item in ipairs(container:getItems()) do
          if item:isContainer() and containersById[item:getId()] then
            toOpen = {item, container}
            break
          end
        end
      end
    end
  end
  if not lootContainers[1] then
    if toOpen then
      g_game.open(toOpen[1], toOpen[2])
      waitTill = now + math.random(500, 800)
      return lootContainers
    end
    -- check containers one more time, maybe there's any loot container
    for index, container in pairs(containers) do
      deusLootBreath()
      if not containersById[container:getContainerItem():getId()] and not container.lootContainer then
        for slot, item in ipairs(container:getItems()) do
          if item:isContainer() and containersById[item:getId()] then
            g_game.open(item)
            waitTill = now + math.random(500, 800)
            return lootContainers
          end
        end
      end
    end
    -- can't find any lootContainer, let's check slots, maybe there's one
    for slot = InventorySlotFirst, InventorySlotLast do
      local item = getInventoryItem(slot)
      if item and item:isContainer() and not openedContainersById[item:getId()] then
        -- container which is not opened yet, let's open it
        g_game.open(item)
        waitTill = now + math.random(500, 800)
        return lootContainers
      end
    end
  end
  return lootContainers
end

TargetBot.Looting.lootContainer = function(lootContainers, container)
  -- loot items
  local nextContainer = nil
  for i, item in ipairs(container:getItems()) do
    deusLootBreath()
    if item:isContainer() and not itemsById[item:getId()] then
      nextContainer = item
    elseif itemsById[item:getId()] or (ui.everyItem:isOn() and not item:isContainer()) then
      item.lootTries = (item.lootTries or 0) + 1
      if item.lootTries < 5 then -- if can't be looted within 0.5s then skip it
        return TargetBot.Looting.lootItem(lootContainers, item)
      end
    elseif storage.foodItems and storage.foodItems[1] and lastFoodConsumption + 5000 < now then
      for _, food in ipairs(storage.foodItems) do
        if item:getId() == food.id then
          g_game.use(item)
          lastFoodConsumption = now
          return
        end
      end
    end
  end

  -- no more items to loot, open next container
  if nextContainer then
    nextContainer.lootTries = (nextContainer.lootTries or 0) + 1
    if nextContainer.lootTries < 2 then -- max 0.6s to open it
      g_game.open(nextContainer, container)
      waitTill = now + math.random(300, 500)
      waitingForContainer = nextContainer:getId()
      return
    end
  end

  -- looting finished, remove container from list
  container.lootContainer = false
  corpseWindow = container
  local entry = activeEntry or TargetBot.Looting.list[currentIndex()]
  activeEntry = nil
  finishCorpse(entry)
  if not TargetBot.Looting.list[1] then
    lootingBusyUntil = math.max(lootingBusyUntil, now + math.random(600, 1000))
  end
end

onTextMessage(function(mode, text)
  if TargetBot.isOff() then return end
  if #TargetBot.Looting.list == 0 then return end
  if string.find(text:lower(), "you are not the owner") then -- if we are not the owners of corpse then its a waste of time to try to loot it
    table.remove(TargetBot.Looting.list, currentIndex())
  end
end)

TargetBot.Looting.lootItem = function(lootContainers, item)
  if item:isStackable() then
    local count = item:getCount()
    for _, container in ipairs(lootContainers) do
      for slot, citem in ipairs(container:getItems()) do
        if item:getId() == citem:getId() and citem:getCount() < 100 then
          g_game.move(item, container:getSlotPosition(slot - 1), count)
          waitTill = now + math.random(250, 450)
          return
        end
      end
    end
  end

  local container = lootContainers[1]
  g_game.move(item, container:getSlotPosition(container:getItemsCount()), 1)
  waitTill = now + math.random(250, 450)
end

local markedItems = {}
local looted = {}
local labeledTiles = {}

local function unmarkCorpse(entry)
  if not entry then return end
  pcall(function()
    if entry.item then entry.item:setMarked('') end
    if entry.pos then
      local tile = g_map.getTile(entry.pos)
      if tile then
        local top = tile:getTopUseThing()
        if top then top:setMarked('') end
      end
    end
  end)
end

local function tileFromKey(key)
  local sx, sy, sz = key:match("(-?%d+),(-?%d+),(-?%d+)")
  if not sx then return nil end
  return g_map.getTile({ x = tonumber(sx), y = tonumber(sy), z = tonumber(sz) })
end

local function lootLabel(entry)
  local c = corpseCount(entry)
  if c <= 1 then
    return "Loot"
  end
  local text = "Loot x" .. c
  local left = math.ceil(corpseDelayLeft(entry) / 1000)
  if left > 0 then
    text = text .. " " .. left .. "s"
  end
  return text
end

local function setTileLabel(tile, text)
  if not tile or type(tile.setText) ~= "function" then return end
  pcall(function()
    if text == "" then
      tile:setText("")
    else
      tile:setText(text, "#FFCC33")
    end
  end)
end

onContainerOpen(function(container, previousContainer)
  if container:getContainerItem():getId() == waitingForContainer then
    container.lootContainer = true
    waitingForContainer = nil
  end
  local ci = container:getContainerItem()
  if ci then
    pcall(function()
      local p = ci:getPosition()
      if p then looted[corpseKey(p)] = true end
    end)
  end
end)

macro(150, function()
  if not TargetBot or not TargetBot.Looting then return end
  local pending = {}
  for _, loot in ipairs(TargetBot.Looting.list) do
    if loot.pos then
      pending[corpseKey(loot.pos)] = loot
    end
  end
  for key, entry in pairs(markedItems) do
    if not pending[key] then
      looted[key] = true
      unmarkCorpse(entry)
      markedItems[key] = nil
    end
  end
  for key in pairs(labeledTiles) do
    if not pending[key] then
      setTileLabel(tileFromKey(key), "")
      labeledTiles[key] = nil
    end
  end
  for key, loot in pairs(pending) do
    local tile = g_map.getTile(loot.pos)
    if tile then
      setTileLabel(tile, lootLabel(loot))
      labeledTiles[key] = true
    end
  end
end)

onCreatureDisappear(function(creature)
  if isInPz() then return end
  if not TargetBot.isOn() then return end
  if not creature:isMonster() then return end
  if storage.ignoreNotTargetingMe then
    local t = TargetBot._myTargets and TargetBot._myTargets[creature:getId()]
    if not t or now - t > 3000 then return end
    if TargetBot.isCorpseContested and TargetBot.isCorpseContested(creature:getPosition()) then return end
  end
  local config = TargetBot.Creature.calculateParams(creature, {}) -- return {craeture, config, danger, priority}
  if not config.config or config.config.dontLoot then
    return
  end
  local pos = player:getPosition()
  local mpos = creature:getPosition()
  local name = creature:getName()
  if pos.z ~= mpos.z or math.max(math.abs(pos.x-mpos.x), math.abs(pos.y-mpos.y)) > 6 then return end
  local lootDelay = __gb_deus_ot == true and 100 or 20
  schedule(lootDelay, function() -- check if there's container (dead body) on that tile
    if not containers[1] then return end
    local cap = switchOn("killAllFirst") and 50 or 20
    if TargetBot.Looting.list[cap] then return end -- too many items to loot
    local tile = g_map.getTile(mpos)
    if not tile then return end
    local container = tile:getTopUseThing()
    if not container or not container:isContainer() then return end
    if not findPath(player:getPosition(), mpos, 6, {ignoreNonPathable=true, ignoreCreatures=true, ignoreCost=true}) then return end
    local key = corpseKey(mpos)
    for _, entry in ipairs(TargetBot.Looting.list) do
      if entry.pos and corpseKey(entry.pos) == key then
        entry.count = corpseCount(entry) + 1
        entry.lastDeathAt = now
        return
      end
    end
    table.insert(TargetBot.Looting.list, {pos=mpos, creature=name, container=container:getId(), added=now, tries=0, count=1, lastDeathAt=now})

    for _, entry in ipairs(TargetBot.Looting.list) do
      local d = 999999
      if entry.pos then
        local ok, res = pcall(distanceFromPlayer, entry.pos)
        if ok and type(res) == "number" and res == res then d = res end
      end
      entry.dist = d
    end
    table.sort(TargetBot.Looting.list, function(a, b)
      return (a.dist or 999999) > (b.dist or 999999)
    end)
    if not looted[key] then
      container:setMarked('#000088')
      markedItems[key] = { item = container, pos = mpos }
    end
  end)
end)
