-- NoxBot Private Script: Paralize
noxCommunityScript(function(config)
  if type(config.enabled) ~= "boolean" then config.enabled = false end

local paral = "ki paralize"
local ex = 5 -- seconds

local paralMacro = macro(100, "Paralize", function()
    local target = g_game.getAttackingCreature()
    if not target then return end
    
    say(config.paral) 
    delay(config.ex * 1000)
end)

local ICON_ID = 13400 -- id ikony
addIcon("paral", {item={id = ICON_ID}, movable=true}, function(icon, isOn)
    paralMacro.setOn(isOn) 
end)

UI.Label("Paralyze Spell:")
UI.TextEdit(config.paral or "ki paralize", function(widget, text)
    config.paral = text
end)

UI.Label("Delay (seconds):")
UI.TextEdit(tostring(config.ex or 5), function(widget, text)
    config.ex = tonumber(text)
end)

UI.Separator()
end)