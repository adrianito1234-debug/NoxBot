setDefaultTab("HP")

local panelName = "manatrain"

local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    text-align: center
    width: 130
    !text: tr('Manatrain')

  Button
    id: edit
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 3
    height: 17
    text: Setup

]])
ui:setId(panelName)

if type(storage[panelName]) ~= "table" then
  storage[panelName] = {}
end

local config = storage[panelName]

if type(config.enabled) ~= "boolean" then
  config.enabled = false
end
if type(config.spell) ~= "string" then
  config.spell = storage.ManatrainText or "Utevo Mana"
end
if type(config.mana) ~= "number" then
  config.mana = 30
end
if type(config.autoAttack) ~= "boolean" then
  config.autoAttack = false
end
if type(config.trainer) ~= "string" then
  config.trainer = ""
end
if type(config.autoEat) ~= "boolean" then
  config.autoEat = false
end

local floorFoodIds = { 3725 }

ui.title:setOn(config.enabled)
ui.title.onClick = function(widget)
  config.enabled = not config.enabled
  widget:setOn(config.enabled)
end

local window = UI.createWindow("ManatrainWindow")
window:hide()

window.spell:setText(config.spell)
window.spell.onTextChange = function(widget, text)
  config.spell = text
end

window.mana:setValue(config.mana)
window.mana:setTooltip("Casts only while mana is above this percentage")
window.mana.onValueChange = function(widget, value)
  config.mana = value
end

window.autoAttack:setOn(config.autoAttack)
window.autoAttack.onClick = function(widget)
  config.autoAttack = not config.autoAttack
  widget:setOn(config.autoAttack)
end

window.trainer:setText(config.trainer)
window.trainer.onTextChange = function(widget, text)
  config.trainer = text
end

window.autoEat:setOn(config.autoEat)
window.autoEat:setTooltip("Eats food lying on the ground next to you")
window.autoEat.onClick = function(widget)
  config.autoEat = not config.autoEat
  widget:setOn(config.autoEat)
end

ui.edit.onClick = function()
  window:show()
  window:raise()
  window:focus()
end

local function distanceTo(creature)
  local playerPos = player:getPosition()
  local creaturePos = creature:getPosition()

  if not playerPos or not creaturePos or playerPos.z ~= creaturePos.z then
    return nil
  end

  return math.max(math.abs(playerPos.x - creaturePos.x), math.abs(playerPos.y - creaturePos.y))
end

local function findFloorFood()
  local playerPos = player:getPosition()
  if not playerPos then return nil end

  for offsetX = -1, 1 do
    for offsetY = -1, 1 do
      local tile = g_map.getTile({x = playerPos.x + offsetX, y = playerPos.y + offsetY, z = playerPos.z})

      if tile then
        for _, item in ipairs(tile:getItems()) do
          if table.find(floorFoodIds, item:getId()) then
            return item
          end
        end
      end
    end
  end

  return nil
end

local function findTrainer(name)
  local closest
  local closestDistance

  for _, spec in ipairs(getSpectators()) do
    if not spec:isLocalPlayer() and spec:getName():lower():find(name, 1, true) then
      local distance = distanceTo(spec)

      if distance and (not closestDistance or distance < closestDistance) then
        closest = spec
        closestDistance = distance
      end
    end
  end

  return closest
end

macro(200, function()
  if not config.enabled then return end
  if type(vBot) == "table" and type(vBot.healFirst) == "function" and vBot.healFirst() then return end
  if config.spell:len() == 0 then return end
  if manapercent() < config.mana then return end

  say(config.spell)
end)

macro(500, function()
  if not config.enabled then return end
  if not config.autoAttack then return end

  local name = config.trainer:trim():lower()
  if name:len() == 0 then return end

  local attacking = g_game.getAttackingCreature()
  if attacking and attacking:getName():lower():find(name, 1, true) then return end

  local trainer = findTrainer(name)
  if trainer then
    g_game.attack(trainer)
  end
end)

local lastEatAttempt = 0

macro(1000, function()
  if not config.enabled then return end
  if not config.autoEat then return end
  if player:getRegenerationTime() > 400 then return end
  if now - lastEatAttempt < 2000 then return end

  local food = findFloorFood()
  if food then
    lastEatAttempt = now
    g_game.use(food)
  end
end)
