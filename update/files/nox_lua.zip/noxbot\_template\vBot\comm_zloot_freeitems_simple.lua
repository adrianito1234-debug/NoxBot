-- NoxBot Private Script: Loot Freeitems Simple
noxCommunityScript(function(config)
  if type(config.enabled) ~= "boolean" then config.enabled = false end

macro(1500, "Loot Freeitems Simple", function()
  local itemids = CaveBot.GetLootItems()
  for _, tile in ipairs(g_map.getTiles(posz())) do
    if getDistanceBetween(pos(), tile:getPosition()) <= 7 and freecap() > 400 then
      local top = tile:getTopUseThing()
      if table.find(itemids,top:getId()) then
        return moveToSlot(top,slotBack)
      end
    end
  end
end)
end)