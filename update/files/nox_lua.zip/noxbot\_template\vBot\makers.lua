if type(setDefaultTab) ~= "function" then function setDefaultTab(name) end end
setDefaultTab("Tools")

UI.Separator()
UI.Label("Makers")
UI.Separator()

local function findIntruder(ignoreFriends)
  for _, spec in ipairs(getSpectators()) do
    if not spec:isLocalPlayer() and spec:isPlayer() then
      if not (ignoreFriends and (isFriend(spec) or spec:isPartyMember())) then
        local specPos = spec:getPosition()

        if math.max(math.abs(posx() - specPos.x), math.abs(posy() - specPos.y)) <= 8 then
          return spec
        end
      end
    end
  end
end

local logout, logoutWindow = addMaker("autoLogout", "Auto Logout", "AutoLogoutWindow")

if type(logout.playerDetected) ~= "boolean" then
  logout.playerDetected = false
end
if type(logout.withoutSoul) ~= "boolean" then
  logout.withoutSoul = false
end
if type(logout.ignoreFriends) ~= "boolean" then
  logout.ignoreFriends = true
end
if type(logout.reconnect) ~= "boolean" then
  logout.reconnect = false
end
if type(logout.reconnectDelay) ~= "number" then
  logout.reconnectDelay = 60
end

bindSwitch(logoutWindow.playerDetected, logout, "playerDetected")
bindSwitch(logoutWindow.withoutSoul, logout, "withoutSoul")
bindSwitch(logoutWindow.ignoreFriends, logout, "ignoreFriends")
bindSwitch(logoutWindow.reconnect, logout, "reconnect")

logoutWindow.reconnectValue:setValue(logout.reconnectDelay)
logoutWindow.reconnectValue.onValueChange = function(widget, value)
  logout.reconnectDelay = value
end

local function scheduleReconnect(seconds)
  local enterGame = modules.client_entergame
  if not enterGame then return end

  local scheduleClientEvent = enterGame.scheduleEvent
  local characterList = enterGame.CharacterList
  if not scheduleClientEvent or not characterList then return end

  scheduleClientEvent(function()
    if not g_game.isOnline() then
      characterList.doLogin()
    end
  end, seconds * 1000)
end

local lastLogoutAttempt = 0

local function runLogout(allowReconnect)
  if now - lastLogoutAttempt < 5000 then return end
  lastLogoutAttempt = now

  if allowReconnect and logout.reconnect then
    scheduleReconnect(logout.reconnectDelay)
  end

  modules.game_interface.tryLogout(false)
end

macro(500, function()
  if not logout.enabled then return end

  if logout.withoutSoul and soul() == 0 then
    return runLogout(false)
  end

  if logout.playerDetected and findIntruder(logout.ignoreFriends) then
    return runLogout(true)
  end
end)

local house, houseWindow = addMaker("autoEnterHouse", "Auto Enter House", "AutoEnterHouseWindow")

if type(house.insidePos) ~= "table" then
  house.insidePos = { x = 0, y = 0, z = 0 }
end
if type(house.outsidePos) ~= "table" then
  house.outsidePos = { x = 0, y = 0, z = 0 }
end
if type(house.playerDetected) ~= "boolean" then
  house.playerDetected = false
end
if type(house.withoutSoul) ~= "boolean" then
  house.withoutSoul = false
end
if type(house.ignoreFriends) ~= "boolean" then
  house.ignoreFriends = true
end
if type(house.goOut) ~= "boolean" then
  house.goOut = false
end
if type(house.goOutDelay) ~= "number" then
  house.goOutDelay = 60
end

bindCoords(house, "insidePos", {
  x = houseWindow.insideX,
  y = houseWindow.insideY,
  z = houseWindow.insideZ
}, houseWindow.insideCurrent)

bindCoords(house, "outsidePos", {
  x = houseWindow.outsideX,
  y = houseWindow.outsideY,
  z = houseWindow.outsideZ
}, houseWindow.outsideCurrent)

bindSwitch(houseWindow.housePlayerDetected, house, "playerDetected")
bindSwitch(houseWindow.houseWithoutSoul, house, "withoutSoul")
bindSwitch(houseWindow.houseIgnoreFriends, house, "ignoreFriends")
bindSwitch(houseWindow.goOut, house, "goOut")

houseWindow.goOutValue:setValue(house.goOutDelay)
houseWindow.goOutValue.onValueChange = function(widget, value)
  house.goOutDelay = value
end

local function isPositionSet(pos)
  return type(pos) == "table" and type(pos.x) == "number" and pos.x > 0
end

local function distanceToPosition(pos)
  local playerPos = player:getPosition()
  if not playerPos or playerPos.z ~= pos.z then return nil end

  return math.max(math.abs(playerPos.x - pos.x), math.abs(playerPos.y - pos.y))
end

local walkParams = { ignoreNonPathable = true, precision = 0 }
local lastReasonSeen = 0

macro(500, function()
  if not house.enabled then return end
  if not isPositionSet(house.insidePos) then return end
  if player:isWalking() then return end

  local mustHide = (house.playerDetected and findIntruder(house.ignoreFriends) ~= nil)
                   or (house.withoutSoul and soul() == 0)

  if mustHide then
    lastReasonSeen = now

    local distance = distanceToPosition(house.insidePos)
    if not distance or distance > 0 then
      autoWalk(house.insidePos, 20, walkParams)
    end

    return
  end

  if not house.goOut then return end
  if not isPositionSet(house.outsidePos) then return end
  if now - lastReasonSeen < house.goOutDelay * 1000 then return end

  local insideDistance = distanceToPosition(house.insidePos)
  if not insideDistance or insideDistance > 2 then return end

  autoWalk(house.outsidePos, 20, walkParams)
end)

local fishing = addToggle("autoFishing", "Auto Fishing")

local fishingRodId = 3483
local waterRangeX = 7
local waterRangeY = 5
local lastWaterKey = nil

local waterIds = {
  493, 494,
  602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616,
  617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629,
  4597, 4598, 4599, 4600, 4601, 4602, 4603, 4604, 4605, 4606,
  4607, 4608, 4609, 4610, 4611, 4612, 4613, 4614,
  4615, 4616, 4617, 4618, 4619, 4620, 4621, 4622, 4623, 4624, 4625,
  4820, 4821, 4822, 4823, 4824, 4825,
}

local waterIdLookup = {}
for _, id in ipairs(waterIds) do
  waterIdLookup[id] = true
end

local function isWaterId(id)
  return waterIdLookup[id] == true
end

local function tileHasWater(tile)
  if not tile then return false end

  local ground = tile:getGround()
  if ground and isWaterId(ground:getId()) then return true end

  for _, item in ipairs(tile:getItems()) do
    if isWaterId(item:getId()) then return true end
  end

  return false
end

local function fishingTargetOnTile(tile)
  if not tileHasWater(tile) then return nil end

  return tile:getTopUseThing() or tile:getGround()
end

local function findFishingTargets()
  local targets = {}
  local playerPos = player:getPosition()
  if not playerPos then return targets end

  for offsetX = -waterRangeX, waterRangeX do
    for offsetY = -waterRangeY, waterRangeY do
      local tile = g_map.getTile({x = playerPos.x + offsetX, y = playerPos.y + offsetY, z = playerPos.z})
      local target = fishingTargetOnTile(tile)

      if target then
        table.insert(targets, target)
      end
    end
  end

  return targets
end

macro(1000, function()
  if not fishing.enabled then return end

  local rod = findItem(fishingRodId)
  if not rod then return end

  local picks = findFishingTargets()
  if #picks == 0 then return end

  local choices = {}

  for _, pick in ipairs(picks) do
    local pickPos = pick:getPosition()

    if lastWaterKey ~= pickPos.x .. "," .. pickPos.y then
      table.insert(choices, pick)
    end
  end

  if #choices == 0 then
    choices = picks
  end

  local target = choices[math.random(#choices)]
  local targetPos = target:getPosition()
  lastWaterKey = targetPos.x .. "," .. targetPos.y

  useWith(rod, target)
end)

local dropHouse, dropHouseWindow = addMaker("dropInsideHouse", "Drop Inside House", "DropInsideHouseWindow")

if type(dropHouse.dropPos) ~= "table" then
  dropHouse.dropPos = { x = 0, y = 0, z = 0 }
end
if type(dropHouse.items) ~= "table" then
  dropHouse.items = {}
end

bindCoords(dropHouse, "dropPos", {
  x = dropHouseWindow.dropX,
  y = dropHouseWindow.dropY,
  z = dropHouseWindow.dropZ
}, dropHouseWindow.dropCurrent)

UI.Container(function(widget, items)
  dropHouse.items = items
end, true, nil, dropHouseWindow.dropItems)

dropHouseWindow.dropItems:setItems(dropHouse.items)

local function canDropAt(pos)
  if not isPositionSet(pos) then return false end

  local distance = distanceToPosition(pos)
  if not distance or distance > 7 then return false end

  local tile = g_map.getTile(pos)
  if not tile or #tile:getItems() > 9 then return false end

  return true
end

macro(500, function()
  if not dropHouse.enabled then return end
  if not dropHouse.items[1] then return end
  if not canDropAt(dropHouse.dropPos) then return end

  for _, container in pairs(getContainers()) do
    for _, item in ipairs(container:getItems()) do
      for _, entry in ipairs(dropHouse.items) do
        local entryId = type(entry) == "number" and entry or entry.id

        if item:getId() == entryId then
          return g_game.move(item, dropHouse.dropPos, item:getCount())
        end
      end
    end
  end
end)
