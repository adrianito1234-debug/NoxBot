function init() end
function terminate() end
function isCooldownIconActive(iconId) return false end
function isGroupCooldownIconActive(groupId) return false end
