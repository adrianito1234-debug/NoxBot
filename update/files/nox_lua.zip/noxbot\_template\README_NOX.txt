NoxBot — pack por defecto (scripts Nox adaptados)
=================================================

Esta carpeta es el SEMILLA anonimo. NO uses tu nombre de personaje aqui
si vas a subir/compartir el bot.

Donde va en el PC (arrastrar aqui):
  Escritorio\NoxBot 1.0\noxbot_data\noxbot\_template\

Contenido esperado:
  cavebot\
  targetbot\
  vBot\          (HealBot, hp, cavebot, extras…)
  cavebot_configs\     (vacío — el usuario crea sus .cfg)
  targetbot_configs\   (vacío — el usuario crea sus .json)
  vBot_configs\  (HealBot.json, etc.)
  storage\       (opcional)

Al pulsar Activar, NoxBot copia _template -> carpeta del personaje
del juego (el nombre lo pone el cliente, no _template).

Para tu uso personal (no para release):
  Escritorio\NoxBot 1.0\noxbot_data\noxbot\<NombrePersonaje>\

Si quieres un perfil extra en el dropdown SIN tu nombre, usa p.ej.:
  Escritorio\NoxBot 1.0\noxbot_data\noxbot\Default\

NO dejes carpetas llamadas Kmkz_Adrian / tu nick en el zip de release.
