-- NoxBot Private Script: Aura
noxCommunityScript(function(config)
  if type(config.enabled) ~= "boolean" then config.enabled = false end

local aura = 81

local getOutfits = function()
    local pOutfit = player:getOutfit()
    player:setOutfit({type = pOutfit.type, wings = 2, aura = config.aura})
end

singlehotkey("Ctrl+x", "Get Outfits", function() getOutfits() end)

UI.Label("Aura:")
UI.TextEdit(tostring(config.aura or 893), function(widget, text)
    config.aura = tonumber(text)
end)

UI.Separator()
end)