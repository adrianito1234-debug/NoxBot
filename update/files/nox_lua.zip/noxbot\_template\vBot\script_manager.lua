setDefaultTab("Main")

local toggleable = vBotToggleableScripts or {}
if type(storage.disabledScripts) ~= "table" then
  storage.disabledScripts = {}
end

local rootWidget = g_ui.getRootWidget()
if rootWidget then
  local window = UI.createWindow("ScriptManagerWindow", rootWidget)
  window:hide()

  local function rebuild()
    window.list:destroyChildren()
    for i = 1, #toggleable do
      local name = toggleable[i]
      local check = g_ui.createWidget("ScriptManagerCheck", window.list)
      check:setText(name)
      check:setChecked(not storage.disabledScripts[name])
      check.onClick = function(widget)
        if storage.disabledScripts[name] then
          storage.disabledScripts[name] = nil
          widget:setChecked(true)
        else
          storage.disabledScripts[name] = true
          widget:setChecked(false)
        end
      end
    end
  end

  window.enableAll.onClick = function()
    for i = 1, #toggleable do
      storage.disabledScripts[toggleable[i]] = nil
    end
    rebuild()
  end

  window.disableAll.onClick = function()
    for i = 1, #toggleable do
      storage.disabledScripts[toggleable[i]] = true
    end
    rebuild()
  end

  window.closeButton.onClick = function()
    window:hide()
  end

  UI.Button("Script Manager", function()
    if window:isVisible() then
      window:hide()
    else
      rebuild()
      window:show()
      window:raise()
      window:focus()
    end
  end)
end
