setDefaultTab("HP")

UI.Separator()
UI.Label("Healing spells")
UI.Separator()
UI.Label("Click the green/red % bar to enable each heal")

if type(storage.healing1) ~= "table" then
  storage.healing1 = {on=false, title="HP%", text="exura", min=51, max=90}
end
if type(storage.healing2) ~= "table" then
  storage.healing2 = {on=false, title="HP%", text="exura vita", min=0, max=50}
end

-- Clasico vBot: DualScroll.on controla macro.setOn. Local por slot (Lua 5.1).
for _, src in ipairs({storage.healing1, storage.healing2}) do
  local healingInfo = src
  local healingmacro = macro(20, function()
    local hp = player:getHealthPercent()
    if healingInfo.max >= hp and hp >= healingInfo.min then
      local words = tostring(healingInfo.text or "")
      if words == "" then return end
      -- sayHeal: cura configurada (no solo exura*); healFirst no la tumba.
      if type(vBot) == "table" and type(vBot.sayHeal) == "function" then
        vBot.sayHeal(words)
      else
        say(words)
      end
    end
  end)
  healingmacro.setOn(not not healingInfo.on)

  UI.DualScrollPanel(healingInfo, function()
    healingmacro.setOn(not not healingInfo.on)
  end)
end

UI.Separator()
UI.Label("Mana & health potions/runes")
UI.Separator()

local defaultUh = 3160
-- Placeholder si el slot esta vacio. El ID real lo pone el drag.

if type(storage.hpitem1) ~= "table" then
  storage.hpitem1 = {on=false, title="HP%", item=defaultUh, min=51, max=90}
end
if type(storage.hpitem2) ~= "table" then
  storage.hpitem2 = {on=false, title="HP%", item=defaultUh, min=0, max=50}
end
if type(storage.manaitem1) ~= "table" then
  storage.manaitem1 = {on=false, title="MP%", item=268, min=51, max=90}
end
if type(storage.manaitem2) ~= "table" then
  storage.manaitem2 = {on=false, title="MP%", item=237, min=0, max=50}
end

storage.hpitem1.title = "HP%"
storage.hpitem2.title = "HP%"
storage.manaitem1.title = "MP%"
storage.manaitem2.title = "MP%"

-- Plan B: misma ruta de tiro que Xyro (TargetBot.useItem / useInventoryItemWith).
-- Manas ceden a healFirst (prioridad cura Nox). ID = el del drag.
local function useHpTabItem(itemId, subType, isHeal)
  itemId = tonumber(itemId) or 0
  if itemId <= 100 then return end
  if not isHeal and type(vBot) == "table" and type(vBot.healFirst) == "function" and vBot.healFirst() then
    return
  end
  if type(TargetBot) == "table" and type(TargetBot.useItem) == "function" then
    pcall(function() TargetBot.useItem(itemId, subType, player) end)
    return
  end
  local thing = nil
  pcall(function() thing = g_things.getThingType(itemId) end)
  local st = g_game.getClientVersion() >= 860 and 0 or 1
  if thing and thing.isFluidContainer and thing:isFluidContainer() then
    st = subType
  end
  pcall(function() g_game.useInventoryItemWith(itemId, player, st) end)
end

local hpTabSlots = {
  { info = storage.hpitem1, isHp = true },
  { info = storage.hpitem2, isHp = true },
  { info = storage.manaitem1, isHp = false },
  { info = storage.manaitem2, isHp = false },
}

for _, slot in ipairs(hpTabSlots) do
  local healingInfo = slot.info
  local isHpItem = slot.isHp
  local healingmacro = macro(20, function()
    if not isHpItem and type(vBot) == "table" and type(vBot.healFirst) == "function" and vBot.healFirst() then
      return
    end
    local maxMana = 1
    pcall(function() maxMana = math.max(1, player:getMaxMana()) end)
    local pct = isHpItem and player:getHealthPercent()
      or math.min(100, math.floor(100 * (player:getMana() / maxMana)))
    if healingInfo.max >= pct and pct >= healingInfo.min then
      useHpTabItem(healingInfo.item, healingInfo.subType, isHpItem)
    end
  end)

  local function refreshMacro()
    healingmacro.setOn(healingInfo.on and (tonumber(healingInfo.item) or 0) > 100)
  end
  refreshMacro()

  UI.DualScrollItemPanel(healingInfo, function()
    refreshMacro()
  end)
end

if g_game.getClientVersion() < 780 then
  UI.Label("In old tibia potions & runes work only when you have backpack with them opened")
end
UI.Separator()
