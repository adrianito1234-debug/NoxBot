-- NoxBot Private Scripts (lazy load)
vBot = vBot or {}
-- Off/On del bot: no reutilizar loaded/manifest de una sesion anterior.
vBot.community = {
  catalog = {
    { id = "comm_hold_position", title = "Hold Position", kind = "toggle" },
    { id = "comm_anti_push", title = "Anti-Push", kind = "toggle" },
    { id = "comm_auto_jump", title = "Auto Exani hur", kind = "toggle" },
    { id = "comm_fight_back", title = "Fight Back", kind = "toggle" },
    { id = "comm_last_exiva", title = "Last Exiva", kind = "toggle" },
    { id = "comm_ssa_aol", title = "SSA / AOL", kind = "toggle" },
  },
}

local ROOT = "vBot/community/"
local loaded = {}
vBot.community.loaded = loaded
local currentId = nil

-- Logica inlined (no hay .lua de comunidad). Off/On no debe dofile ni loguear error.
local INLINE_IDS = {
  comm_hold_position = true,
  comm_anti_push = true,
  comm_auto_jump = true,
  comm_fight_back = true,
  comm_last_exiva = true,
  comm_ssa_aol = true,
}

local function commKey(id)
  return "community/" .. tostring(id)
end

local function isDisabled(id)
  if type(storage.disabledScripts) ~= "table" then return false end
  return storage.disabledScripts[commKey(id)] == true
end

function noxCommunityStorage(id)
  storage[id] = storage[id] or { enabled = false }
  if type(storage[id].enabled) ~= "boolean" then
    storage[id].enabled = false
  end
  return storage[id]
end

local function resolveCommFile(name)
  local cfg = tostring(_G.__noxbot_char_cfg or ""):gsub("%s+", "_")
  if cfg == "" then cfg = "_template" end
  local paths = {
    ROOT .. name,
    "vBot/" .. name,
    "/noxbot/" .. cfg .. "/vBot/community/" .. name,
    "/noxbot/" .. cfg .. "/vBot/" .. name,
    "/noxbot/_template/vBot/community/" .. name,
    "/noxbot/_template/vBot/" .. name,
  }
  for _, p in ipairs(paths) do
    local ok = false
    pcall(function()
      if g_resources and g_resources.fileExists and g_resources.fileExists(p) then ok = true end
    end)
    if ok then return p end
  end
  return ROOT .. name
end

local function botLoad(rel)
  if type(dofile) ~= "function" then return false, "no dofile" end
  local ok, err = pcall(function() dofile(rel) end)
  if ok then return true end
  return false, err
end

function noxCommunityManifest()
  if type(vBot.community.manifest) == "table" and #vBot.community.manifest > 0 then
    return vBot.community.manifest
  end
  -- Catalogo curado tiene prioridad (implementacion 1 a 1).
  local catalog = vBot.community.catalog or {}
  if type(catalog) == "table" and #catalog > 0 then
    vBot.community.manifest = catalog
    return catalog
  end
  local list = {}
  local ok, data = pcall(function() return dofile(resolveCommFile("_manifest.lua")) end)
  if ok and type(data) == "table" and #data > 0 then
    list = data
  end
  vBot.community.manifest = list
  return list
end

function noxCommunityLoad(id)
  if INLINE_IDS[id] then
    loaded[id] = true
    return true
  end
  if loaded[id] or isDisabled(id) then return loaded[id] == true end
  currentId = id
  local rel = resolveCommFile(id .. ".lua")
  local ok, err = botLoad(rel)
  currentId = nil
  if ok then
    loaded[id] = true
    return true
  end
  pcall(function()
    if type(info) == "function" then
      info("[NoxBot Private Scripts] no cargo " .. tostring(id) .. ": " .. tostring(err))
    elseif type(warn) == "function" then
      warn("[NoxBot Private Scripts] " .. tostring(id) .. ": " .. tostring(err))
    end
  end)
  return false
end

function noxCommunityScript(initFn)
  local id = currentId
  if not id or type(initFn) ~= "function" then return end
  local config = noxCommunityStorage(id)
  pcall(function() initFn(config) end)
end

local function hookLazyEnable(id, config, titleWidget)
  if not titleWidget then return end
  local baseClick = titleWidget.onClick
  titleWidget.onClick = function(w)
    if not config.enabled then noxCommunityLoad(id) end
    if type(baseClick) == "function" then
      baseClick(w)
    else
      config.enabled = not config.enabled
      w:setOn(config.enabled)
      if type(saveConfig) == "function" then saveConfig() end
    end
  end
end

local function findRow(id)
  local row = nil
  pcall(function()
    local root = g_ui.getRootWidget()
    if root and root.recursiveGetChildById then
      row = root:recursiveGetChildById(id)
    end
  end)
  return row
end

local function trackScript(id)
  vBotToggleableScripts = vBotToggleableScripts or {}
  vBotToggleableScripts[#vBotToggleableScripts + 1] = commKey(id)
end

local function markPrivateRow(ui)
  if not ui then return ui end
  if type(noxTrackPrivateScriptRow) == "function" then
    noxTrackPrivateScriptRow(ui)
  else
    pcall(function() ui.noxPsRow = true end)
  end
  return ui
end

local function registerHoldPosition(id, title)
  local config = noxCommunityStorage(id)
  local holdPos = nil
  local lastWalk = 0
  local walkOpts = {
    ignoreNonPathable = true,
    ignoreCreatures = true,
    precision = 0,
    allowUnseen = true,
    allowOnlyVisibleTiles = false,
  }

  local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    text-align: center
]])
  initToggle(id, title, ui)
  markPrivateRow(ui)
  config = storage[id] or config

  local function samePos(a, b)
    return a and b and a.x == b.x and a.y == b.y and a.z == b.z
  end

  local function caveOn()
    return CaveBot and type(CaveBot.isOn) == "function" and CaveBot.isOn()
  end

  local function goBack()
    if not holdPos then return end
    local p = pos()
    if not p or samePos(p, holdPos) then return end
    if p.z ~= holdPos.z then return end
    if player:isWalking() then return end
    if now - lastWalk < 250 then return end
    lastWalk = now
    if not autoWalk(holdPos, 40, walkOpts) then
      autoWalk(holdPos, 40, {
        ignoreNonPathable = true,
        ignoreCreatures = true,
        precision = 1,
        allowUnseen = true,
        allowOnlyVisibleTiles = false,
      })
    end
  end

  macro(200, function()
    if not config.enabled then
      holdPos = nil
      return
    end
    if caveOn() then return end
    local p = pos()
    if not p then return end
    if not holdPos then
      holdPos = { x = p.x, y = p.y, z = p.z }
      return
    end
    goBack()
  end)

  onPlayerPositionChange(function(newPos)
    if not config.enabled or not holdPos or caveOn() then return end
    if not samePos(newPos, holdPos) then
      goBack()
    end
  end)

  loaded[id] = true
  trackScript(id)
end

local function registerAntiPush(id, title)
  local config = noxCommunityStorage(id)
  -- Solo gold coin (NoxBot / OTC moderno). Sin slots.
  local GOLD_ID = 3031
  local lastDrop = 0

  local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    text-align: center
]])
  initToggle(id, title, ui)
  markPrivateRow(ui)
  config = storage[id] or config

  -- Busqueda manual: findItem a veces desincroniza y el 2º move tira la BP.
  local function findGold()
    local containers = g_game.getContainers()
    if not containers then return nil end
    for _, container in pairs(containers) do
      local okItems, items = pcall(function() return container:getItems() end)
      if okItems and type(items) == "table" then
        for _, item in ipairs(items) do
          local ok = false
          local itemId, count = 0, 0
          pcall(function()
            itemId = item:getId()
            count = tonumber(item:getCount()) or 0
            if itemId == GOLD_ID
              and count >= 1
              and item:isStackable()
              and not item:isContainer()
            then
              ok = true
            end
          end)
          if ok then return item, count end
        end
      end
    end
    return nil
  end

  -- Tira exactamente 2 gold (o 1 si solo queda 1). Cooldown evita doble-move → BP.
  local function tryDrop()
    if not config.enabled then return end
    if now - lastDrop < 120 then return end
    local p = player:getPosition()
    if not p then return end
    local tile = g_map.getTile(p)
    if not tile then return end
    local top = tile:getTopUseThing()
    if top then
      local topId, topCount = 0, 0
      pcall(function()
        topId = top:getId()
        topCount = tonumber(top:getCount()) or 0
      end)
      if topId == GOLD_ID and topCount >= 2 then return end
    end
    local it, have = findGold()
    if not it then return end
    -- Re-check justo antes del move (el container puede haber cambiado).
    local idNow, countNow = 0, 0
    local safe = false
    pcall(function()
      idNow = it:getId()
      countNow = tonumber(it:getCount()) or 0
      safe = idNow == GOLD_ID
        and countNow >= 1
        and it:isStackable()
        and not it:isContainer()
    end)
    if not safe then return end
    local n = countNow >= 2 and 2 or 1
    lastDrop = now
    g_game.move(it, p, n)
  end

  macro(50, function()
    tryDrop()
  end)

  onPlayerPositionChange(function()
    tryDrop()
  end)

  loaded[id] = true
  trackScript(id)
end

local function registerAutoJump(id, title)
  local config = noxCommunityStorage(id)

  local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    text-align: center
]])
  initToggle(id, title, ui)
  markPrivateRow(ui)
  config = storage[id] or config

  -- say() envuelve exhaust support ~2s y bloquea exani hur. Usar rawSay.
  local function rawSay(text)
    local fn = vBot and vBot.rawSay
    if type(fn) == "function" then
      return fn(text)
    end
    if type(g_game) == "table" and type(g_game.talk) == "function" then
      return g_game.talk(1, text) -- TalkNormal
    end
  end

  local function keyDown(k)
    local ok, v = pcall(function() return g_keyboard.isKeyPressed(k) end)
    return ok and v
  end

  local function heldDir()
    if keyDown("W") or keyDown("Up") then return 0 end
    if keyDown("D") or keyDown("Right") then return 1 end
    if keyDown("S") or keyDown("Down") then return 2 end
    if keyDown("A") or keyDown("Left") then return 3 end
    return nil
  end

  local function tryLevitate(dir)
    if dir == nil then return end
    local p = pos()
    if not p then return end
    local check = { x = p.x, y = p.y, z = p.z }
    if dir == 0 then check.y = check.y - 1
    elseif dir == 1 then check.x = check.x + 1
    elseif dir == 2 then check.y = check.y + 1
    else check.x = check.x - 1 end
    local tile = g_map.getTile(check)
    if not tile or tile:isWalkable() then return end
    if player:getDirection() ~= dir then
      turn(dir)
    end
    -- up+down: el server acepta el correcto; sin CD interno del bot.
    if tile:getGround() then
      rawSay('exani hur "up')
    else
      rawSay('exani hur "down')
    end
  end

  -- Al pulsar: inmediato (no esperar al macro).
  onKeyDown(function(keys)
    if not config.enabled then return end
    local dir = nil
    if keys == "W" or keys == "Up" then dir = 0
    elseif keys == "D" or keys == "Right" then dir = 1
    elseif keys == "S" or keys == "Down" then dir = 2
    elseif keys == "A" or keys == "Left" then dir = 3 end
    if dir ~= nil then tryLevitate(dir) end
  end)

  macro(50, function()
    if not config.enabled then return end
    tryLevitate(heldDir())
  end)

  loaded[id] = true
  trackScript(id)
end

local function registerFightBack(id, title)
  local config = noxCommunityStorage(id)
  -- Todo configurable en Setup. Defaults seguros.
  if type(config.pauseCave) ~= "boolean" then config.pauseCave = true end
  if type(config.pauseTarget) ~= "boolean" then config.pauseTarget = true end
  if type(config.ignoreFriends) ~= "boolean" then config.ignoreFriends = true end
  if type(config.ignoreParty) ~= "boolean" then config.ignoreParty = true end

  local targetName = nil
  local pausedCave = false
  local pausedTarget = false
  local savedChase = nil
  local chaseOn = false

  local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    text-align: center
    width: 130

  Button
    id: setup
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 3
    height: 17
    text: Setup
]])
  initToggle(id, title, ui)
  markPrivateRow(ui)
  config = storage[id] or config
  if type(config.pauseCave) ~= "boolean" then config.pauseCave = true end
  if type(config.pauseTarget) ~= "boolean" then config.pauseTarget = true end
  if type(config.ignoreFriends) ~= "boolean" then config.ignoreFriends = true end
  if type(config.ignoreParty) ~= "boolean" then config.ignoreParty = true end

  local edit = setupUI([[
Panel
  height: 80

  BotSwitch
    id: pauseCave
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    height: 17
    text-align: center
    text: Pause CaveBot

  BotSwitch
    id: pauseTarget
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 2
    height: 17
    text-align: center
    text: Pause TargetBot

  BotSwitch
    id: ignoreFriends
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 2
    height: 17
    text-align: center
    text: Ignore Friends

  BotSwitch
    id: ignoreParty
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 2
    height: 17
    text-align: center
    text: Ignore Party
]])
  edit:hide()

  local showEdit = false
  ui.setup.onClick = function()
    showEdit = not showEdit
    if showEdit then edit:show() else edit:hide() end
  end

  local function persist()
    if type(noxPersist) == "function" then
      noxPersist(false)
    elseif type(saveConfig) == "function" then
      saveConfig()
    end
  end

  local function bindOpt(widget, key)
    if not widget then return end
    widget:setOn(config[key] == true)
    widget.onClick = function(w)
      config[key] = not config[key]
      w:setOn(config[key])
      persist()
    end
  end
  bindOpt(edit.pauseCave, "pauseCave")
  bindOpt(edit.pauseTarget, "pauseTarget")
  bindOpt(edit.ignoreFriends, "ignoreFriends")
  bindOpt(edit.ignoreParty, "ignoreParty")

  local function isPartyMember(spec)
    local ok, v = pcall(function()
      if type(spec.isPartyMember) == "function" and spec:isPartyMember() then
        return true
      end
      local sh = tonumber(spec:getShield()) or 0
      return sh >= 3
    end)
    return ok and v
  end

  local function mustIgnore(spec)
    if not spec then return true end
    local okPlayer = false
    pcall(function()
      okPlayer = spec:isPlayer() and not spec:isLocalPlayer()
    end)
    if not okPlayer then return true end
    if config.ignoreFriends and type(isFriend) == "function" then
      local ok, fr = pcall(isFriend, spec)
      if ok and fr then return true end
    end
    if config.ignoreParty and isPartyMember(spec) then return true end
    return false
  end

  local function isAttackingMe(spec)
    local ok, v = pcall(function() return spec:isTimedSquareVisible() end)
    return ok and v
  end

  local function isDeadOrGone(spec)
    if not spec then return true end
    local dead = false
    pcall(function()
      if type(spec.isDead) == "function" and spec:isDead() then dead = true end
      if type(spec.getHealthPercent) == "function" and spec:getHealthPercent() <= 0 then dead = true end
    end)
    return dead
  end

  local function restoreChase()
    if not chaseOn then return end
    chaseOn = false
    local mode = tonumber(savedChase) or 0
    savedChase = nil
    pcall(function()
      if type(g_game.setChaseMode) == "function" then
        g_game.setChaseMode(mode)
      end
    end)
  end

  -- Fuerza Chase Follow cada tick: si algo lo apaga, se vuelve a encender.
  local function forceChaseOn()
    pcall(function()
      if type(g_game.getChaseMode) == "function" and savedChase == nil then
        savedChase = g_game.getChaseMode()
      end
      if type(g_game.setChaseMode) == "function" then
        g_game.setChaseMode(2)
        chaseOn = true
      end
    end)
  end

  local function restoreBots()
    if pausedTarget then
      pausedTarget = false
      pcall(function()
        if TargetBot and type(TargetBot.setOn) == "function" then TargetBot.setOn() end
      end)
    end
    if pausedCave then
      pausedCave = false
      pcall(function()
        if CaveBot and type(CaveBot.setOn) == "function" then CaveBot.setOn() end
      end)
    end
  end

  local function pauseBots()
    if config.pauseTarget then
      pcall(function()
        if TargetBot and type(TargetBot.isOn) == "function" and TargetBot.isOn() then
          pausedTarget = true
          TargetBot.setOff()
        end
      end)
    elseif pausedTarget then
      pausedTarget = false
      pcall(function()
        if TargetBot and type(TargetBot.setOn) == "function" then TargetBot.setOn() end
      end)
    end
    if config.pauseCave then
      pcall(function()
        if CaveBot and type(CaveBot.isOn) == "function" and CaveBot.isOn() then
          pausedCave = true
          CaveBot.setOff()
        end
      end)
    elseif pausedCave then
      pausedCave = false
      pcall(function()
        if CaveBot and type(CaveBot.setOn) == "function" then CaveBot.setOn() end
      end)
    end
  end

  local function clearFight()
    targetName = nil
    restoreChase()
    restoreBots()
  end

  local function findAttacker()
    local specs = getSpectators(false)
    if type(specs) ~= "table" then return nil end
    for _, spec in ipairs(specs) do
      if isAttackingMe(spec) and not mustIgnore(spec) then
        local name = nil
        pcall(function() name = spec:getName() end)
        if type(name) == "string" and name ~= "" then
          return name, spec
        end
      end
    end
    return nil
  end

  macro(50, function()
    if not config.enabled then
      if targetName then clearFight() end
      return
    end

    if not targetName then
      local name, spec = findAttacker()
      if not name then
        restoreChase()
        restoreBots()
        return
      end
      targetName = name
      pauseBots()
      forceChaseOn()
      g_game.attack(spec)
      return
    end

    local creature = nil
    pcall(function()
      if type(getPlayerByName) == "function" then
        creature = getPlayerByName(targetName)
      elseif type(getCreatureByName) == "function" then
        creature = getCreatureByName(targetName)
      end
    end)

    if not creature or isDeadOrGone(creature) or mustIgnore(creature) then
      clearFight()
      return
    end

    pauseBots()
    forceChaseOn()
    local atkName = nil
    pcall(function()
      local atk = g_game.getAttackingCreature()
      if atk then atkName = atk:getName() end
    end)
    if atkName ~= targetName then
      g_game.attack(creature)
    end
  end)

  onKeyDown(function(keys)
    if not config.enabled or not targetName then return end
    if keys == "Escape" then
      clearFight()
      pcall(function() g_game.cancelAttack() end)
    end
  end)

  loaded[id] = true
  trackScript(id)
end

local function rawSaySpell(text)
  local fn = vBot and vBot.rawSay
  if type(fn) == "function" then
    return fn(text)
  end
  if type(g_game) == "table" and type(g_game.talk) == "function" then
    return g_game.talk(1, text)
  end
end

local function registerLastExiva(id, title)
  local config = noxCommunityStorage(id)
  if type(config.hotkey) ~= "string" or config.hotkey == "" then
    config.hotkey = "Shift+F"
  end
  local lastName = ""

  local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    text-align: center
    width: 130

  Button
    id: setup
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 3
    height: 17
    text: Setup
]])
  initToggle(id, title, ui)
  markPrivateRow(ui)
  config = storage[id] or config
  if type(config.hotkey) ~= "string" or config.hotkey == "" then
    config.hotkey = "Shift+F"
  end

  local edit = setupUI([[
Panel
  height: 20

  BotTextEdit
    id: hotkey
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    height: 17
]])
  edit:hide()
  edit.hotkey:setText(config.hotkey)

  local showEdit = false
  ui.setup.onClick = function()
    showEdit = not showEdit
    if showEdit then edit:show() else edit:hide() end
  end
  edit.hotkey.onTextChange = function(w, text)
    config.hotkey = tostring(text or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if config.hotkey == "" then config.hotkey = "Shift+F" end
    if type(noxPersist) == "function" then noxPersist(false)
    elseif type(saveConfig) == "function" then saveConfig() end
  end

  -- Guarda el ultimo player al que atacas.
  macro(100, function()
    if not config.enabled then return end
    local atk = nil
    pcall(function() atk = g_game.getAttackingCreature() end)
    if not atk then return end
    local ok = false
    local name = ""
    pcall(function()
      if atk:isPlayer() and not atk:isLocalPlayer() then
        name = atk:getName() or ""
        ok = name ~= ""
      end
    end)
    if ok then lastName = name end
  end)

  local function doExiva()
    if not config.enabled then return end
    if type(lastName) ~= "string" or lastName == "" then return end
    rawSaySpell('exiva "' .. lastName)
  end

  onKeyDown(function(keys)
    if not config.enabled then return end
    local hk = tostring(config.hotkey or "Shift+F")
    if keys == hk then
      doExiva()
    end
  end)

  loaded[id] = true
  trackScript(id)
end

local function registerSsaAol(id, title)
  local config = noxCommunityStorage(id)
  local SSA_ID = 3081
  local AOL_ID = 3057
  if type(config.autoHp) ~= "boolean" then config.autoHp = true end
  if type(config.aolBelow) ~= "number" then config.aolBelow = 40 end
  if type(config.ssaAbove) ~= "number" then config.ssaAbove = 70 end
  if type(config.hotkeySsa) ~= "string" or config.hotkeySsa == "" then config.hotkeySsa = "F5" end
  if type(config.hotkeyAol) ~= "string" or config.hotkeyAol == "" then config.hotkeyAol = "F6" end

  local lastEquip = 0
  local neckSlot = SlotNeck or 2

  local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    text-align: center
    width: 130

  Button
    id: setup
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 3
    height: 17
    text: Setup
]])
  initToggle(id, title, ui)
  markPrivateRow(ui)
  config = storage[id] or config
  if type(config.autoHp) ~= "boolean" then config.autoHp = true end
  if type(config.aolBelow) ~= "number" then config.aolBelow = 40 end
  if type(config.ssaAbove) ~= "number" then config.ssaAbove = 70 end
  if type(config.hotkeySsa) ~= "string" or config.hotkeySsa == "" then config.hotkeySsa = "F5" end
  if type(config.hotkeyAol) ~= "string" or config.hotkeyAol == "" then config.hotkeyAol = "F6" end

  local edit = setupUI([[
Panel
  height: 118

  BotSwitch
    id: autoHp
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    height: 17
    text-align: center
    text: Auto by HP

  Label
    anchors.top: prev.bottom
    anchors.left: parent.left
    width: 70
    margin-top: 4
    height: 16
    text: AOL <

  BotTextEdit
    id: aolBelow
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    height: 17

  Label
    anchors.top: prev.bottom
    anchors.left: parent.left
    width: 70
    margin-top: 2
    height: 16
    text: SSA >

  BotTextEdit
    id: ssaAbove
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    height: 17

  Label
    anchors.top: prev.bottom
    anchors.left: parent.left
    width: 70
    margin-top: 2
    height: 16
    text: Key SSA

  BotTextEdit
    id: hotkeySsa
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    height: 17

  Label
    anchors.top: prev.bottom
    anchors.left: parent.left
    width: 70
    margin-top: 2
    height: 16
    text: Key AOL

  BotTextEdit
    id: hotkeyAol
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    height: 17
]])
  edit:hide()

  local showEdit = false
  ui.setup.onClick = function()
    showEdit = not showEdit
    if showEdit then edit:show() else edit:hide() end
  end

  local function persist()
    if type(noxPersist) == "function" then noxPersist(false)
    elseif type(saveConfig) == "function" then saveConfig() end
  end

  edit.autoHp:setOn(config.autoHp == true)
  edit.autoHp.onClick = function(w)
    config.autoHp = not config.autoHp
    w:setOn(config.autoHp)
    persist()
  end
  edit.aolBelow:setText(tostring(config.aolBelow))
  edit.ssaAbove:setText(tostring(config.ssaAbove))
  edit.hotkeySsa:setText(config.hotkeySsa)
  edit.hotkeyAol:setText(config.hotkeyAol)

  edit.aolBelow.onTextChange = function(_, text)
    config.aolBelow = math.max(1, math.min(100, tonumber(text) or 40))
    persist()
  end
  edit.ssaAbove.onTextChange = function(_, text)
    config.ssaAbove = math.max(1, math.min(100, tonumber(text) or 70))
    persist()
  end
  edit.hotkeySsa.onTextChange = function(_, text)
    config.hotkeySsa = tostring(text or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if config.hotkeySsa == "" then config.hotkeySsa = "F5" end
    persist()
  end
  edit.hotkeyAol.onTextChange = function(_, text)
    config.hotkeyAol = tostring(text or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if config.hotkeyAol == "" then config.hotkeyAol = "F6" end
    persist()
  end

  local function neckId()
    local id = 0
    pcall(function()
      local n = getNeck and getNeck()
      if n then id = n:getId() or 0 end
    end)
    return id
  end

  local function equipAmulet(itemId)
    if now - lastEquip < 200 then return end
    if neckId() == itemId then return end
    lastEquip = now
    pcall(function()
      if type(moveToSlot) == "function" then
        moveToSlot(itemId, neckSlot)
      else
        local it = findItem(itemId)
        if it then g_game.move(it, { x = 65535, y = neckSlot, z = 0 }, 1) end
      end
    end)
  end

  macro(150, function()
    if not config.enabled or not config.autoHp then return end
    local hp = 100
    pcall(function() hp = hppercent() end)
    if hp <= (tonumber(config.aolBelow) or 40) then
      equipAmulet(AOL_ID)
    elseif hp >= (tonumber(config.ssaAbove) or 70) then
      equipAmulet(SSA_ID)
    end
  end)

  onKeyDown(function(keys)
    if not config.enabled then return end
    if keys == tostring(config.hotkeySsa or "F5") then
      equipAmulet(SSA_ID)
    elseif keys == tostring(config.hotkeyAol or "F6") then
      equipAmulet(AOL_ID)
    end
  end)

  loaded[id] = true
  trackScript(id)
end

local function registerToggle(entry)
  local id = entry.id
  if not id or isDisabled(id) then return end
  if id == "comm_auto_follow" then return end
  local title = entry.title or id
  if id == "comm_hold_position" then
    registerHoldPosition(id, title)
    return
  end
  if id == "comm_anti_push" then
    registerAntiPush(id, title)
    return
  end
  if id == "comm_auto_jump" then
    registerAutoJump(id, title)
    return
  end
  if id == "comm_fight_back" then
    registerFightBack(id, title)
    return
  end
  if id == "comm_last_exiva" then
    registerLastExiva(id, title)
    return
  end
  if id == "comm_ssa_aol" then
    registerSsaAol(id, title)
    return
  end
  local config = noxCommunityStorage(id)

  local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    text-align: center

]])
  initToggle(id, title, ui)
  markPrivateRow(ui)
  config = storage[id] or config
  hookLazyEnable(id, config, ui.title)
  noxCommunityLoad(id)
  trackScript(id)
end

local function registerMaker(entry)
  local id = entry.id
  if not id or isDisabled(id) then return end
  local title = entry.title or id
  local windowStyle = entry.window or (id .. "Window")
  local buttonText = entry.button or "Setup"
  local config = noxCommunityStorage(id)
  if type(config.leader) ~= "string" then config.leader = "" end
  local cfg, window, ui = addMaker(id, title, windowStyle, buttonText)
  config = storage[id] or config or cfg
  if window and window.leader then
    window.leader:setText(config.leader or "")
    window.leader.onTextChange = function(widget, text)
      config.leader = text or ""
      if type(saveConfig) == "function" then saveConfig() end
    end
  end
  if ui and ui.title then
    hookLazyEnable(id, config, ui.title)
  end
  if ui and ui.setup and window then
    ui.setup.onClick = function()
      noxCommunityLoad(id)
      if window.leader then window.leader:setText(config.leader or "") end
      window:show()
      window:raise()
      window:focus()
    end
  end
  if config.enabled then
    pcall(function()
      if type(schedule) == "function" then
        schedule(200, function() noxCommunityLoad(id) end)
      else
        noxCommunityLoad(id)
      end
    end)
  end
  trackScript(id)
end

function noxCommunityBuildUI()
  -- Cada Off/On del bot: resetear lazy-load o los macros no se re-registran.
  loaded = {}
  vBot.community.loaded = loaded
  vBot.community.manifest = nil

  setDefaultTab("Main")
  for _, entry in ipairs(noxCommunityManifest()) do
    if type(entry) == "table" and entry.id then
      if entry.id == "comm_auto_follow" then
        -- movido a vBot/auto_follow.lua (carga directa)
      elseif entry.kind == "maker" then
        registerMaker(entry)
      else
        registerToggle(entry)
      end
    end
  end
end

function noxCommunityEnabledList()
  local out = {}
  for _, entry in ipairs(noxCommunityManifest()) do
    local id = entry and entry.id
    if id and not isDisabled(id) then
      local cfg = noxCommunityStorage(id)
      if cfg.enabled then out[#out + 1] = id end
    end
  end
  return out
end

function noxCommunityDeferredBootstrap(opts)
  opts = opts or {}
  local list = noxCommunityEnabledList()
  if #list == 0 then
    if type(opts.onDone) == "function" then opts.onDone() end
    return
  end

  local ms = tonumber(opts.msPerScript) or 60
  local stillValid = opts.stillValid or function() return true end
  local later = opts.later or function(_, fn) fn() end
  local onProgress = opts.onProgress or function() end
  local onDone = opts.onDone or function() end

  local idx = 1
  local function step()
    if not stillValid() then return end
    if idx > #list then
      onDone()
      return
    end
    local id = list[idx]
    noxCommunityLoad(id)
    onProgress(math.floor(idx * 100 / #list), id)
    idx = idx + 1
    if idx > #list then
      later(ms, function()
        if stillValid() then onDone() end
      end)
      return
    end
    later(ms, step)
  end
  later(40, step)
end
