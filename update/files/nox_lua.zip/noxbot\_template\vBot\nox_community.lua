-- NoxBot — scripts de comunidad (lazy load, sin lag al arrancar).
vBot = vBot or {}
vBot.community = vBot.community or {}

local ROOT = "vBot/community/"
local loaded = vBot.community.loaded or {}
vBot.community.loaded = loaded
local currentId = nil

local function botLoad(rel)
  if type(dofile) ~= "function" then return false, "no dofile" end
  local ok, err = pcall(function() dofile(rel) end)
  return ok, err
end

local function commKey(id)
  return "community/" .. tostring(id)
end

local function isDisabled(id)
  if type(storage.disabledScripts) ~= "table" then return false end
  return storage.disabledScripts[commKey(id)] == true
end

function noxCommunityStorage(id)
  storage[id] = storage[id] or { enabled = false }
  if type(storage[id].enabled) ~= "boolean" then
    storage[id].enabled = false
  end
  return storage[id]
end

function noxCommunityManifest()
  if type(vBot.community.manifest) == "table" then
    return vBot.community.manifest
  end
  local list = {}
  local ok, data = pcall(function()
    return dofile(ROOT .. "_manifest.lua")
  end)
  if ok and type(data) == "table" then list = data end
  vBot.community.manifest = list
  return list
end

function noxCommunityLoad(id)
  if loaded[id] or isDisabled(id) then return loaded[id] == true end
  currentId = id
  local ok, err = botLoad(ROOT .. id .. ".lua")
  currentId = nil
  if ok then
    loaded[id] = true
    return true
  end
  pcall(function()
    if type(warn) == "function" then
      warn("[NoxBot Scripts] " .. tostring(id) .. ": " .. tostring(err))
    end
  end)
  return false
end

-- Al final de cada script: noxCommunityScript(function(config) ... end)
function noxCommunityScript(initFn)
  local id = currentId
  if not id or type(initFn) ~= "function" then return end
  local config = noxCommunityStorage(id)
  pcall(function() initFn(config) end)
end

local function hookLazyEnable(id, config, titleWidget)
  if not titleWidget then return end
  local baseClick = titleWidget.onClick
  titleWidget.onClick = function(w)
    if not config.enabled then noxCommunityLoad(id) end
    if type(baseClick) == "function" then
      baseClick(w)
    else
      config.enabled = not config.enabled
      w:setOn(config.enabled)
      if type(saveConfig) == "function" then saveConfig() end
    end
  end
end

local function findRow(id)
  local row = nil
  pcall(function()
    local root = g_ui.getRootWidget()
    if root and root.recursiveGetChildById then
      row = root:recursiveGetChildById(id)
    end
  end)
  return row
end

local function trackScript(id)
  vBotToggleableScripts = vBotToggleableScripts or {}
  vBotToggleableScripts[#vBotToggleableScripts + 1] = commKey(id)
end

local function registerToggle(entry)
  local id = entry.id
  if not id or isDisabled(id) then return end
  local title = entry.title or id
  local config = noxCommunityStorage(id)

  local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    text-align: center

]])
  initToggle(id, title, ui)
  config = storage[id] or config
  hookLazyEnable(id, config, ui.title)
  trackScript(id)
end

local function registerMaker(entry)
  local id = entry.id
  if not id or isDisabled(id) then return end
  local title = entry.title or id
  local windowStyle = entry.window or (id .. "Window")
  local buttonText = entry.button or "Setup"
  local config = noxCommunityStorage(id)
  addMaker(id, title, windowStyle, buttonText)
  config = storage[id] or config
  local row = findRow(id)
  if row and row.title then
    hookLazyEnable(id, config, row.title)
  end
  trackScript(id)
end

function noxCommunityBuildUI()
  setDefaultTab("Main")
  for _, entry in ipairs(noxCommunityManifest()) do
    if type(entry) == "table" and entry.id then
      if entry.kind == "maker" then
        registerMaker(entry)
      else
        registerToggle(entry)
      end
    end
  end
end

function noxCommunityEnabledList()
  local out = {}
  for _, entry in ipairs(noxCommunityManifest()) do
    local id = entry and entry.id
    if id and not isDisabled(id) then
      local cfg = noxCommunityStorage(id)
      if cfg.enabled then out[#out + 1] = id end
    end
  end
  return out
end

function noxCommunityDeferredBootstrap(opts)
  opts = opts or {}
  local list = noxCommunityEnabledList()
  if #list == 0 then
    if type(opts.onDone) == "function" then opts.onDone() end
    return
  end

  local ms = tonumber(opts.msPerScript) or 60
  local stillValid = opts.stillValid or function() return true end
  local later = opts.later or function(_, fn) fn() end
  local onProgress = opts.onProgress or function() end
  local onDone = opts.onDone or function() end

  local idx = 1
  local function step()
    if not stillValid() then return end
    if idx > #list then
      onDone()
      return
    end
    local id = list[idx]
    noxCommunityLoad(id)
    onProgress(math.floor(idx * 100 / #list), id)
    idx = idx + 1
    if idx > #list then
      later(ms, function()
        if stillValid() then onDone() end
      end)
      return
    end
    later(ms, step)
  end
  later(40, step)
end
