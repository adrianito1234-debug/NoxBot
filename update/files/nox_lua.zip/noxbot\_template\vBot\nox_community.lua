-- NoxBot Private Scripts (lazy load)
vBot = vBot or {}
vBot.community = vBot.community or {}

local ROOT = "vBot/community/"
local loaded = vBot.community.loaded or {}
vBot.community.loaded = loaded
local currentId = nil

-- Catalogo curado: solo scripts que vamos activando 1 a 1.
-- Si catalog tiene entradas, NO carga los 135 del _manifest.lua.
vBot.community.catalog = {
  { id = "comm_zzholdposition", title = "Hold Position" },
}

local function commKey(id)
  return "community/" .. tostring(id)
end

local function isDisabled(id)
  if type(storage.disabledScripts) ~= "table" then return false end
  return storage.disabledScripts[commKey(id)] == true
end

function noxCommunityStorage(id)
  storage[id] = storage[id] or { enabled = false }
  if type(storage[id].enabled) ~= "boolean" then
    storage[id].enabled = false
  end
  return storage[id]
end

local function resolveCommFile(name)
  local cfg = tostring(_G.__noxbot_char_cfg or ""):gsub("%s+", "_")
  if cfg == "" then cfg = "_template" end
  local paths = {
    ROOT .. name,
    "vBot/" .. name,
    "/noxbot/" .. cfg .. "/vBot/community/" .. name,
    "/noxbot/" .. cfg .. "/vBot/" .. name,
    "/noxbot/_template/vBot/community/" .. name,
    "/noxbot/_template/vBot/" .. name,
  }
  for _, p in ipairs(paths) do
    local ok = false
    pcall(function()
      if g_resources and g_resources.fileExists and g_resources.fileExists(p) then ok = true end
    end)
    if ok then return p end
  end
  return ROOT .. name
end

local function botLoad(rel)
  if type(dofile) ~= "function" then return false, "no dofile" end
  local ok, err = pcall(function() dofile(rel) end)
  if ok then return true end
  return false, err
end

function noxCommunityManifest()
  if type(vBot.community.manifest) == "table" and #vBot.community.manifest > 0 then
    return vBot.community.manifest
  end
  -- Catalogo curado tiene prioridad (implementacion 1 a 1).
  local catalog = vBot.community.catalog or {}
  if type(catalog) == "table" and #catalog > 0 then
    vBot.community.manifest = catalog
    return catalog
  end
  local list = {}
  local ok, data = pcall(function() return dofile(resolveCommFile("_manifest.lua")) end)
  if ok and type(data) == "table" and #data > 0 then
    list = data
  end
  vBot.community.manifest = list
  return list
end

function noxCommunityLoad(id)
  if loaded[id] or isDisabled(id) then return loaded[id] == true end
  currentId = id
  local rel = resolveCommFile(id .. ".lua")
  local ok, err = botLoad(rel)
  currentId = nil
  if ok then
    loaded[id] = true
    return true
  end
  pcall(function()
    if type(warn) == "function" then
      warn("[NoxBot Private Scripts] " .. tostring(id) .. ": " .. tostring(err))
    end
  end)
  return false
end

function noxCommunityScript(initFn)
  local id = currentId
  if not id or type(initFn) ~= "function" then return end
  local config = noxCommunityStorage(id)
  pcall(function() initFn(config) end)
end

local function hookLazyEnable(id, config, titleWidget)
  if not titleWidget then return end
  local baseClick = titleWidget.onClick
  titleWidget.onClick = function(w)
    if not config.enabled then noxCommunityLoad(id) end
    if type(baseClick) == "function" then
      baseClick(w)
    else
      config.enabled = not config.enabled
      w:setOn(config.enabled)
      if type(saveConfig) == "function" then saveConfig() end
    end
  end
end

local function findRow(id)
  local row = nil
  pcall(function()
    local root = g_ui.getRootWidget()
    if root and root.recursiveGetChildById then
      row = root:recursiveGetChildById(id)
    end
  end)
  return row
end

local function trackScript(id)
  vBotToggleableScripts = vBotToggleableScripts or {}
  vBotToggleableScripts[#vBotToggleableScripts + 1] = commKey(id)
end

local function registerToggle(entry)
  local id = entry.id
  if not id or isDisabled(id) then return end
  if id == "comm_auto_follow" then return end
  local title = entry.title or id
  local config = noxCommunityStorage(id)

  local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    text-align: center

]])
  initToggle(id, title, ui)
  config = storage[id] or config
  hookLazyEnable(id, config, ui.title)
  -- Cargar siempre al registrar (no solo si enabled): evita toggle verde sin macro.
  pcall(function()
    if type(schedule) == "function" then
      schedule(100, function() noxCommunityLoad(id) end)
    else
      noxCommunityLoad(id)
    end
  end)
  trackScript(id)
end

local function registerMaker(entry)
  local id = entry.id
  if not id or isDisabled(id) then return end
  local title = entry.title or id
  local windowStyle = entry.window or (id .. "Window")
  local buttonText = entry.button or "Setup"
  local config = noxCommunityStorage(id)
  if type(config.leader) ~= "string" then config.leader = "" end
  local cfg, window, ui = addMaker(id, title, windowStyle, buttonText)
  config = storage[id] or config or cfg
  if window and window.leader then
    window.leader:setText(config.leader or "")
    window.leader.onTextChange = function(widget, text)
      config.leader = text or ""
      if type(saveConfig) == "function" then saveConfig() end
    end
  end
  if ui and ui.title then
    hookLazyEnable(id, config, ui.title)
  end
  if ui and ui.setup and window then
    ui.setup.onClick = function()
      noxCommunityLoad(id)
      if window.leader then window.leader:setText(config.leader or "") end
      window:show()
      window:raise()
      window:focus()
    end
  end
  if config.enabled then
    pcall(function()
      if type(schedule) == "function" then
        schedule(200, function() noxCommunityLoad(id) end)
      else
        noxCommunityLoad(id)
      end
    end)
  end
  trackScript(id)
end

function noxCommunityBuildUI()
  -- Cada Off/On del bot: resetear lazy-load o los macros no se re-registran.
  loaded = {}
  vBot.community.loaded = loaded
  vBot.community.manifest = nil

  setDefaultTab("Main")
  for _, entry in ipairs(noxCommunityManifest()) do
    if type(entry) == "table" and entry.id then
      if entry.id == "comm_auto_follow" then
        -- movido a vBot/auto_follow.lua (carga directa)
      elseif entry.kind == "maker" then
        registerMaker(entry)
      else
        registerToggle(entry)
      end
    end
  end
end

function noxCommunityEnabledList()
  local out = {}
  for _, entry in ipairs(noxCommunityManifest()) do
    local id = entry and entry.id
    if id and not isDisabled(id) then
      local cfg = noxCommunityStorage(id)
      if cfg.enabled then out[#out + 1] = id end
    end
  end
  return out
end

function noxCommunityDeferredBootstrap(opts)
  opts = opts or {}
  local list = noxCommunityEnabledList()
  if #list == 0 then
    if type(opts.onDone) == "function" then opts.onDone() end
    return
  end

  local ms = tonumber(opts.msPerScript) or 60
  local stillValid = opts.stillValid or function() return true end
  local later = opts.later or function(_, fn) fn() end
  local onProgress = opts.onProgress or function() end
  local onDone = opts.onDone or function() end

  local idx = 1
  local function step()
    if not stillValid() then return end
    if idx > #list then
      onDone()
      return
    end
    local id = list[idx]
    noxCommunityLoad(id)
    onProgress(math.floor(idx * 100 / #list), id)
    idx = idx + 1
    if idx > #list then
      later(ms, function()
        if stillValid() then onDone() end
      end)
      return
    end
    later(ms, step)
  end
  later(40, step)
end
