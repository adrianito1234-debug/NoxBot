-- NoxBot Private Script: Autoloot Add
noxCommunityScript(function(config)
  if type(config.enabled) ~= "boolean" then config.enabled = false end

local doAutoLootLook = macro(5000, "Autoloot Add", function() end)
onTextMessage(function(mode, text)
    if mode == 20 and text:find("You see") and doAutoLootLook:isOn() then
        local regex = [[(?:an|a)([a-z A-Z]*).]]
        local data = regexMatch(text, regex)[1]
        if data and data[2] then
            say('!autoloot add, ' ..data[2]:trim())
        end
    end
end)


local doAutoLootLook = macro(5000, "Autoloot Add", function() end)
onTextMessage(function(mode, text)
    if mode == 20 and text:find("You see") and doAutoLootLook:isOn() then
        local regex = [[(?:an|a)([a-z A-Z]*).]]
        local data = regexMatch(text, regex)[1]
        if data and data[2] then
            say('!autoloot remove, ' ..data[2]:trim())
        end
    end
end)
end)