-- Seccion comunidad NoxBot (scripts toggle debajo de este header).
setDefaultTab("Main")

UI.Separator()
UI.Label("NoxBot Scripts")
UI.Separator()
