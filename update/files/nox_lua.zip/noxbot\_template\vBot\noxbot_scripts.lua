-- Private Scripts: label normal + click abre/cierra solo las filas marcadas.
setDefaultTab("Main")

UI.Separator()

if type(storage.__noxPsOpen) ~= "boolean" then
  storage.__noxPsOpen = true
end

local rows = {}

local function trackRow(w)
  if not w then return nil end
  pcall(function() w.noxPsRow = true end)
  rows[#rows + 1] = w
  return w
end

-- Lo usa nox_community.lua al crear cada fila.
function noxTrackPrivateScriptRow(w)
  return trackRow(w)
end

local header = setupUI([[
Panel
  height: 16
  focusable: true
  phantom: false

  Label
    id: title
    anchors.fill: parent
    text-align: center
    text: Private Scripts
    color: #dfdfdf
    phantom: false
]])

local function applyOpen(open)
  storage.__noxPsOpen = open and true or false
  for _, w in ipairs(rows) do
    pcall(function()
      if storage.__noxPsOpen then
        w:show()
      else
        w:hide()
      end
    end)
  end
  if header and header.title then
    pcall(function()
      header.title:setColor(storage.__noxPsOpen and "#dfdfdf" or "#8a8a8a")
    end)
  end
end

local function onHeaderClick()
  applyOpen(not storage.__noxPsOpen)
  if type(noxPersist) == "function" then
    noxPersist(false)
  elseif type(saveConfig) == "function" then
    saveConfig()
  end
end

if header then
  header.onMouseRelease = function(widget, mousePos, mouseButton)
    if mouseButton ~= MouseLeftButton then return false end
    onHeaderClick()
    return true
  end
  if header.title then
    header.title.onMouseRelease = function(widget, mousePos, mouseButton)
      if mouseButton ~= MouseLeftButton then return false end
      onHeaderClick()
      return true
    end
  end
end

pcall(function()
  if type(noxBuildPushMaxUI) == "function" then
    trackRow(noxBuildPushMaxUI())
  end
end)
pcall(function()
  if type(noxBuildComboUI) == "function" then
    trackRow(noxBuildComboUI())
  end
end)

pcall(function()
  dofile("vBot/nox_community.lua")
  if type(noxCommunityBuildUI) == "function" then
    noxCommunityBuildUI()
  end
end)

applyOpen(storage.__noxPsOpen)

UI.Separator()
