-- Seccion NoxBot Scripts + registro UI (carga lazy vía nox_community.lua).
setDefaultTab("Main")

UI.Separator()
UI.Label("NoxBot Scripts")
UI.Separator()

pcall(function()
  if type(noxCommunityBuildUI) ~= "function" then
    dofile("vBot/nox_community.lua")
  end
  if type(noxCommunityBuildUI) == "function" then
    noxCommunityBuildUI()
  end
end)
