-- NoxBot Private Script: Conjurecheckamount
noxCommunityScript(function(config)
  if type(config.enabled) ~= "boolean" then config.enabled = false end

local diamondArrowId = 25757
local arrowSpell = 'Exevo Gran Con Hur'
local arrowCheck = 200

macro(3600, "Conjurecheckamount", function()
  local arrows = itemAmount(diamondArrowId)

  if arrows < arrowCheck then
    return say(arrowSpell)
  end

end)
end)