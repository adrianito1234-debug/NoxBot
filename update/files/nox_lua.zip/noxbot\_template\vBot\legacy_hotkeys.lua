setDefaultTab("Main")

local panelName = "legacyHotkeys"
local config, window = addMaker(panelName, "Legacy Hotkeys", "LegacyHotkeysWindow", "Setup")
if not window then return end

if type(config.bindings) ~= "table" then
  config.bindings = {}
end

local keyCapture = nil
local lastTrigger = {}

local function defaultBinding()
  return {
    hotkey = "",
    itemId = 0,
    subType = 0,
    text = "",
    useMode = "self"
  }
end

-- Igual Xyro / manas: en Nostalrius (<860) runas van con subtype 1.
local function resolveSubType(itemId, subType)
  local thing = nil
  pcall(function() thing = g_things.getThingType(itemId) end)
  if thing and thing.isFluidContainer and thing:isFluidContainer() then
    return tonumber(subType) or 0
  end
  local ver = 860
  pcall(function() ver = g_game.getClientVersion() or 860 end)
  return ver >= 860 and 0 or 1
end

-- HEAL_RUNES solo clasifica prioridad (forzar Self). El ID es siempre el del drag.

local HEAL_RUNES = {
  [2273] = true, [3160] = true, [2265] = true, [3152] = true
}

local function isHealRune(itemId)
  return HEAL_RUNES[tonumber(itemId) or 0] == true
end

local function hasBindingItem(binding)
  local itemId = binding.itemId or 0
  if itemId <= 0 then
    return false
  end
  if itemId > 100 then
    return true
  end
  local thing = nil
  pcall(function() thing = g_things.getThingType(itemId) end)
  if thing and thing.isFluidContainer and thing:isFluidContainer() then
    return (binding.subType or 0) > 0
  end
  return true
end

local function sanitizeBinding(entry)
  if type(entry) ~= "table" then
    entry = defaultBinding()
  end
  if type(entry.hotkey) ~= "string" then
    entry.hotkey = ""
  end
  if type(entry.itemId) ~= "number" then
    entry.itemId = tonumber(entry.itemId) or 0
  end
  if type(entry.subType) ~= "number" then
    entry.subType = tonumber(entry.subType) or 0
  end
  if type(entry.text) ~= "string" then
    entry.text = ""
  end
  if entry.useMode ~= "self" and entry.useMode ~= "target" and entry.useMode ~= "cross" then
    entry.useMode = "self"
  end
  -- UH/IH siempre Self (nunca Target como en la UI rota).
  if isHealRune(entry.itemId) then
    entry.useMode = "self"
  end
  if entry.itemId <= 0 then
    entry.subType = 0
  end
  return entry
end

local function normalizeBindings()
  if type(noxAsList) == "function" then
    config.bindings = noxAsList(config.bindings)
  end
  if type(config.bindings) ~= "table" or #config.bindings == 0 then
    config.bindings = { defaultBinding() }
    return
  end
  for i, entry in ipairs(config.bindings) do
    config.bindings[i] = sanitizeBinding(entry)
  end
end

normalizeBindings()

local function hotkeyLabel(binding)
  if binding.hotkey and binding.hotkey:len() > 0 then
    return binding.hotkey
  end
  return "-"
end

local function setRowItemWidget(widget, binding)
  local itemId = binding.itemId or 0
  if itemId > 0 then
    widget:setItem(Item.create(itemId, binding.subType or 0))
  else
    widget:setItemId(0)
  end
end

local function setUseMode(row, binding, mode)
  if isHealRune(binding.itemId) then
    mode = "self"
  end
  binding.useMode = mode
  row.modeStrip.modeSelf:setOn(mode == "self")
  row.modeStrip.modeTarget:setOn(mode == "target")
  row.modeStrip.modeCross:setOn(mode == "cross")
end

local function updateRowModeVisibility(row, binding)
  if hasBindingItem(binding) then
    row.spell:hide()
    row.removeSpell:hide()
    row.modeStrip:show()
    setUseMode(row, binding, binding.useMode or "self")
  else
    row.spell:show()
    row.removeSpell:show()
    row.modeStrip:hide()
    row.spell:setText(binding.text or "")
  end
end

local function startKeyCapture(binding, field)
  keyCapture = {
    binding = binding,
    field = field,
    previous = binding.hotkey or ""
  }
  field:setText("...")
end

local rebuildList

local function bindRow(row, index, binding)
  row.slotLabel:setText(tostring(index))
  row.hotkey:setText(hotkeyLabel(binding))
  setRowItemWidget(row.item, binding)
  row.spell:setText(binding.text or "")
  updateRowModeVisibility(row, binding)

  row.hotkey.onClick = function(widget)
    if not window:isVisible() then
      return
    end
    startKeyCapture(binding, widget)
  end

  row.item.onItemChange = function(widget)
    binding.itemId = widget:getItemId()
    binding.subType = widget:getItemSubType()
    if binding.itemId <= 0 then
      binding.subType = 0
    elseif isHealRune(binding.itemId) then
      binding.useMode = "self"
    end
    updateRowModeVisibility(row, binding)
  end

  row.spell.onTextChange = function(widget, text)
    binding.text = text
  end

  row.modeStrip.modeSelf.onClick = function(widget)
    setUseMode(row, binding, "self")
  end

  row.modeStrip.modeTarget.onClick = function(widget)
    setUseMode(row, binding, "target")
  end

  row.modeStrip.modeCross.onClick = function(widget)
    setUseMode(row, binding, "cross")
  end

  local function removeBinding()
    for i, entry in ipairs(config.bindings) do
      if entry == binding then
        table.remove(config.bindings, i)
        break
      end
    end
    rebuildList()
  end

  row.removeSpell.onClick = removeBinding
  row.modeStrip.removeMode.onClick = removeBinding
end

rebuildList = function()
  window.list:destroyChildren()
  if #config.bindings == 0 then
    table.insert(config.bindings, defaultBinding())
  end
  for i, binding in ipairs(config.bindings) do
    local row = UI.createWidget("LegacyHotkeyRow", window.list)
    bindRow(row, i, binding)
  end
end

local addBindingRow = function(data)
  table.insert(config.bindings, sanitizeBinding(data or defaultBinding()))
  rebuildList()
end

rebuildList()

window.addRow.onClick = function()
  addBindingRow()
end

local function applyCapturedKey(keyDesc)
  if not keyCapture or not keyDesc or keyDesc:len() == 0 then
    return false
  end
  if keyDesc == "Escape" then
    keyCapture.field:setText(hotkeyLabel(keyCapture.binding))
    keyCapture = nil
    return true
  end
  keyCapture.binding.hotkey = keyDesc
  keyCapture.field:setText(keyDesc)
  keyCapture = nil
  return true
end

window.onKeyDown = function(widget, keyCode, keyboardModifiers)
  if not keyCapture then
    return false
  end
  if type(determineKeyComboDesc) == "function" then
    return applyCapturedKey(determineKeyComboDesc(keyCode, keyboardModifiers))
  end
  return false
end

window.onHide = function()
  if keyCapture then
    keyCapture.field:setText(hotkeyLabel(keyCapture.binding))
    keyCapture = nil
  end
end

-- Plan B: misma ruta que Xyro Legacy (TargetBot.useItem). ID del drag.
-- SD/ataque ceden a healFirst; UH self no.
local function useItemOn(itemId, subType, targetCreature)
  itemId = tonumber(itemId) or 0
  if itemId <= 0 or not targetCreature then
    return false
  end

  if type(TargetBot) == "table" and type(TargetBot.useItem) == "function" then
    pcall(function() TargetBot.useItem(itemId, subType, targetCreature, 0) end)
    return true
  end

  local st = resolveSubType(itemId, subType)
  local item = nil
  pcall(function()
    if type(findItem) == "function" then item = findItem(itemId) end
  end)
  if not item then
    pcall(function()
      if g_game.findPlayerItem then item = g_game.findPlayerItem(itemId, st) end
    end)
  end
  if item then
    pcall(function() g_game.useWith(item, targetCreature, st) end)
    return true
  end
  if g_game.useInventoryItemWith then
    pcall(function() g_game.useInventoryItemWith(itemId, targetCreature, st) end)
    return true
  end
  return false
end

local function useItemCrosshair(itemId, subType)
  if itemId <= 0 then
    return false
  end
  -- Crosshair necesita el thing en cliente; si no hay, no se puede apuntar.
  local st = resolveSubType(itemId, subType)
  local item = nil
  pcall(function()
    if type(findItem) == "function" then item = findItem(itemId) end
  end)
  if not item then
    pcall(function()
      if g_game.findPlayerItem then item = g_game.findPlayerItem(itemId, st) end
    end)
  end
  if not item then
    return false
  end
  if modules.game_interface and modules.game_interface.startUseWith then
    modules.game_interface.startUseWith(item)
    return true
  end
  return false
end

local function executeBinding(binding)
  local itemId = binding.itemId or 0
  local subType = binding.subType or 0

  if hasBindingItem(binding) then
    local mode = binding.useMode or "self"
    if isHealRune(itemId) then
      mode = "self"
    end

    -- SD/ataque ceden si toca curar; UH/IH nunca se bloquean.
    if not isHealRune(itemId) and mode ~= "self" then
      if type(vBot) == "table" and type(vBot.healFirst) == "function" and vBot.healFirst() then
        return false
      end
    end

    if mode == "self" then
      return useItemOn(itemId, subType, player)
    end

    if mode == "target" then
      local creature = nil
      pcall(function() creature = g_game.getAttackingCreature() end)
      if not creature and type(target) == "function" then
        pcall(function() creature = target() end)
      end
      if creature then
        return useItemOn(itemId, subType, creature)
      end
      return false
    end

    if mode == "cross" then
      return useItemCrosshair(itemId, subType)
    end
  end

  local text = binding.text or ""
  if text:len() == 0 then
    return false
  end

  if type(vBot) == "table" and type(vBot.healFirst) == "function" and vBot.healFirst() then
    local isHp = type(vBot.isHpHealSpell) == "function" and vBot.isHpHealSpell(text)
    if not isHp then
      return false
    end
  end

  if TargetBot and TargetBot.saySpell then
    TargetBot.saySpell(text)
  else
    say(text)
  end
  return true
end

onKeyDown(function(keys)
  if keyCapture then
    if applyCapturedKey(keys) then
      return
    end
    return
  end

  if not config.enabled then
    return
  end

  if lastTrigger[keys] and now - lastTrigger[keys] < 250 then
    return
  end

  for _, binding in ipairs(config.bindings) do
    if binding.hotkey == keys and binding.hotkey:len() > 0 then
      if executeBinding(binding) then
        lastTrigger[keys] = now
      end
      return
    end
  end
end)
