-- Descifrado NXL1 (scripts comerciales). Clave = licencia + pepper (pepper real en bridge C++).
nox_crypto = nox_crypto or {}

local function bxor(a, b)
  if bit32 and bit32.bxor then return bit32.bxor(a, b) end
  if bit and bit.bxor then return bit.bxor(a, b) end
  local r, m = 0, 1
  while a > 0 or b > 0 do
    if a % 2 ~= b % 2 then r = r + m end
    a, b, m = math.floor(a / 2), math.floor(b / 2), m * 2
  end
  return r
end

local function sha256_bytes(data)
  if g_crypt and g_crypt.sha256 then
    local ok, h = pcall(function() return g_crypt.sha256(data) end)
    if ok and type(h) == "string" and #h == 32 then return h end
  end
  if g_crypt and g_crypt.sha256Encrypt then
    local ok, hex = pcall(function() return g_crypt.sha256Encrypt(data) end)
    if ok and type(hex) == "string" and #hex == 64 then
      local out = {}
      for i = 1, 64, 2 do
        out[#out + 1] = tonumber(hex:sub(i, i + 1), 16) or 0
      end
      return string.char(unpack(out))
    end
  end
  return nil
end

function nox_crypto.pepper()
  return _G.__nox_lua_pepper or "nox-kmkz-lua-v1-change-me"
end

function nox_crypto.license()
  -- Commercial NXL blobs use fixed unlock (KeyAuth gates the launcher).
  return "dev-local"
end

function nox_crypto.keyMaterial()
  return nox_crypto.license() .. "|lua|" .. nox_crypto.pepper()
end

function nox_crypto.isNxl(data)
  return type(data) == "string" and #data >= 24 and data:sub(1, 4) == "NXL1"
end

function nox_crypto.decrypt(data)
  if type(data) ~= "string" or #data < 24 then return data end
  if data:sub(1, 4) ~= "NXL1" then return data end
  local salt = data:sub(5, 20)
  local body = { data:byte(21, #data) }
  local key = sha256_bytes(nox_crypto.keyMaterial() .. salt)
  if not key or #key < 32 then return nil end
  for i = 1, #body do
    body[i] = bxor(body[i], key:byte(((i - 1) % 32) + 1))
  end
  return string.char(unpack(body))
end

function nox_crypto.readScript(path)
  path = tostring(path or "")
  local nxlPath = path:gsub("%.lua$", ".nxl")
  local raw = nil
  pcall(function()
    if g_resources.fileExists(nxlPath) then
      raw = g_resources.readFileContents(nxlPath)
    elseif g_resources.fileExists(path) then
      raw = g_resources.readFileContents(path)
    end
  end)
  if not raw or raw == "" then return nil end
  if nox_crypto.isNxl(raw) then
    return nox_crypto.decrypt(raw)
  end
  return raw
end
