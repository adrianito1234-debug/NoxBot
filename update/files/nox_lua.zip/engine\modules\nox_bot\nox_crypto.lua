-- Helpers de carga de scripts (texto o bytecode LuaJIT). Sin NXL.
nox_crypto = nox_crypto or {}

function nox_crypto.isBytecode(data)
  return type(data) == "string" and #data >= 4
    and data:byte(1) == 0x1b and data:sub(2, 3) == "LJ"
end

function nox_crypto.readScript(path)
  path = tostring(path or "")
  if path == "" then return nil end
  local raw = nil
  pcall(function()
    if g_resources.fileExists(path) then
      raw = g_resources.readFileContents(path)
    end
  end)
  if type(raw) == "string" and raw ~= "" then return raw end
  return nil
end
