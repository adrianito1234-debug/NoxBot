CaveBot.MinimapWaypoints = {}

local window = UI.createWindow("CaveBotMinimapWindow")
window:hide()
local map = window.map
local dots = {}
local lastCount = -1
local addMode = false
local removeMode = false

pcall(function() map:disableAutoWalk() end)
pcall(function() map:setDraggable(true) end)

local function changeFloor(delta)
  local ok = pcall(function()
    if delta < 0 then
      map:floorUp(1)
    else
      map:floorDown(1)
    end
  end)
  if not ok then
    local cam
    pcall(function() cam = map:getCameraPosition() end)
    if cam then
      local z = cam.z + delta
      if z >= 0 and z <= 15 then
        pcall(function() map:setCameraPosition({x = cam.x, y = cam.y, z = z}) end)
      end
    end
  end
end

local function changeZoom(delta)
  local ok = pcall(function()
    if delta > 0 then
      map:zoomIn()
    else
      map:zoomOut()
    end
  end)
  return ok
end

local nativeButtons = map:getChildById("floorUpWidget")
if nativeButtons then
  map.wpFloorUp:hide()
  map.wpFloorDown:hide()
  map.wpZoomIn:hide()
  map.wpZoomOut:hide()
else
  map.wpFloorUp.onClick = function() changeFloor(-1) end
  map.wpFloorDown.onClick = function() changeFloor(1) end
  map.wpZoomIn.onClick = function() changeZoom(1) end
  map.wpZoomOut.onClick = function() changeZoom(-1) end
end

local COLORS = {
  ["goto"] = "#00ff00cc",
  ["reach"] = "#00e5e5cc",
}

if storage.minimapWaypointType ~= "Reach" then
  storage.minimapWaypointType = "Go to"
end

window.waypointType:addOption("Go to")
window.waypointType:addOption("Reach")
window.waypointType:setCurrentOption(storage.minimapWaypointType)
window.waypointType.onOptionChange = function(widget, text)
  storage.minimapWaypointType = text
end

local function hasActiveConfig()
  local cfgs = storage._configs and storage._configs.cavebot_configs
  if cfgs and cfgs.selected then
    return true
  end
  return false
end

local HINT_TEXT = "Drag = move, scroll = zoom. Add/Remove on: click the map to place or delete waypoints. Green = Go to, Blue = Reach."
local WARNING_TEXT = "No CaveBot config selected! Create or select one in the Cave tab, otherwise your waypoints won't be saved."

local function updateHint()
  if hasActiveConfig() then
    window.mapHint:setText(HINT_TEXT)
    window.mapHint:setColor("#dfdfdf")
  else
    window.mapHint:setText(WARNING_TEXT)
    window.mapHint:setColor("#ff8844")
  end
end

window.addMode.onClick = function(widget)
  addMode = not addMode
  widget:setOn(addMode)
  if addMode and removeMode then
    removeMode = false
    window.removeMode:setOn(false)
  end
  if addMode and not hasActiveConfig() then
    warn("Minimap Waypoints: no CaveBot config selected, waypoints won't be saved")
  end
  updateHint()
end

window.removeMode.onClick = function(widget)
  removeMode = not removeMode
  widget:setOn(removeMode)
  if removeMode and addMode then
    addMode = false
    window.addMode:setOn(false)
  end
  if removeMode and not hasActiveConfig() then
    warn("Minimap Waypoints: no CaveBot config selected, changes won't be saved")
  end
  updateHint()
end

local function dotVisibility(dot, cam)
  if cam and dot.pos.z ~= cam.z then
    dot:hide()
  else
    dot:show()
    pcall(function() map:centerInPosition(dot, dot.pos) end)
  end
end

local function repositionDots()
  local cam
  pcall(function() cam = map:getCameraPosition() end)
  for _, dot in ipairs(dots) do
    dotVisibility(dot, cam)
  end
end

local function addDot(x, y, z, color)
  local dot = g_ui.createWidget("UIWidget", map)
  dot:setSize({width = 7, height = 7})
  dot:setBackgroundColor(color)
  dot.pos = {x = x, y = y, z = z}
  dots[#dots + 1] = dot
  local cam
  pcall(function() cam = map:getCameraPosition() end)
  dotVisibility(dot, cam)
end

local function clearDots()
  for _, dot in ipairs(dots) do
    dot:destroy()
  end
  dots = {}
end

local function parseWaypoint(entry)
  if not COLORS[entry.action] or type(entry.value) ~= "string" then
    return nil
  end
  local parts = entry.value:split(",")
  local x = tonumber(parts[1])
  local y = tonumber(parts[2])
  local z = tonumber(parts[3])
  if not x or not y or not z then
    return nil
  end
  return x, y, z
end

local function loadDots()
  clearDots()
  if not CaveBot.actionList then
    return
  end
  for _, entry in ipairs(CaveBot.actionList:getChildren()) do
    local x, y, z = parseWaypoint(entry)
    if x then
      addDot(x, y, z, COLORS[entry.action])
    end
  end
  lastCount = CaveBot.actionList:getChildCount()
end

local function addWaypoint(tilePos)
  local action = storage.minimapWaypointType == "Reach" and "reach" or "goto"
  CaveBot.addAction(action, tilePos.x .. "," .. tilePos.y .. "," .. tilePos.z, true)
  CaveBot.save()
  addDot(tilePos.x, tilePos.y, tilePos.z, COLORS[action])
  lastCount = CaveBot.actionList:getChildCount()
end

local function removeWaypoint(tilePos)
  if not CaveBot.actionList then
    return
  end
  local best, bestDist
  for _, entry in ipairs(CaveBot.actionList:getChildren()) do
    local x, y, z = parseWaypoint(entry)
    if x and z == tilePos.z then
      local d = math.max(math.abs(x - tilePos.x), math.abs(y - tilePos.y))
      if d <= 1 and (not best or d < bestDist) then
        best = entry
        bestDist = d
      end
    end
  end
  if best then
    best:destroy()
    CaveBot.save()
    loadDots()
  end
end

local function centerMap()
  local p = player:getPosition()
  if not p then
    return
  end
  pcall(function()
    map:setCameraPosition(p)
    map:setCrossPosition(p)
  end)
end

map.onDragEnter = function(self, pos)
  self.dragReference = pos
  self.dragCameraReference = self:getCameraPosition()
  return true
end

map.onDragMove = function(self, pos, moved)
  if not self.dragReference or not self.dragCameraReference then
    return false
  end
  local scale = self:getScale()
  if scale <= 0 then
    scale = 1
  end
  self:setCameraPosition({
    x = self.dragCameraReference.x + (self.dragReference.x - pos.x) / scale,
    y = self.dragCameraReference.y + (self.dragReference.y - pos.y) / scale,
    z = self.dragCameraReference.z,
  })
  return true
end

map.onMouseRelease = function(self, pos, button)
  if not self.allowNextRelease then
    return true
  end
  self.allowNextRelease = false
  if button ~= 1 then
    return false
  end
  if not addMode and not removeMode then
    return false
  end
  local tilePos = self:getTilePosition(pos)
  if not tilePos then
    return true
  end
  if addMode then
    addWaypoint(tilePos)
  else
    removeWaypoint(tilePos)
  end
  return true
end

map.onCameraPositionChange = function(self, camPos)
  if self.cross then
    pcall(function() self:setCrossPosition(self.cross.pos) end)
  end
  repositionDots()
end

map.onZoomChange = function(self, zoom)
  repositionDots()
end

window.recenter.onClick = function()
  centerMap()
  repositionDots()
end

CaveBot.MinimapWaypoints.show = function()
  window:show()
  window:raise()
  window:focus()
  centerMap()
  loadDots()
  updateHint()
end

CaveBot.MinimapWaypoints.toggle = function()
  if window:isVisible() then
    window:hide()
  else
    CaveBot.MinimapWaypoints.show()
  end
end

macro(1000, function()
  if not window:isVisible() then
    return
  end
  updateHint()
  if CaveBot.actionList and CaveBot.actionList:getChildCount() ~= lastCount then
    loadDots()
  end
end)
