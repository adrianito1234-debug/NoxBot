-- Auto Follow (carga directa) — estilo Kondra/OTLand: escaleras, agujeros, distancia larga
setDefaultTab("Main")

if type(storage.autoFollow) ~= "table" then
  storage.autoFollow = {}
end
local config = storage.autoFollow
if type(config.target) ~= "string" then config.target = "" end
if type(config.enabled) ~= "boolean" then config.enabled = false end

pcall(function()
  local old = storage.comm_auto_follow
  if type(old) == "table" then
    if (config.target == nil or config.target == "") and type(old.leader) == "string" then
      config.target = old.leader
    end
    if old.enabled then
      config.enabled = true
    end
  end
end)

local ui = setupUI([[
Panel
  id: autoFollowPanel
  height: 48

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    text-align: center
    height: 19

  BotTextEdit
    id: targetEdit
    anchors.top: title.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 22
    font: verdana-11px-rounded
    focusable: true
    !placeholder: tr('Nombre exacto, ej: Kmkz Adrian')
]])
initToggle("autoFollow", "Auto Follow", ui)
ui.targetEdit:setText(config.target or "")
ui.targetEdit.onTextChange = function(widget, text)
  config.target = text or ""
  pcall(function()
    if type(saveConfig) == "function" then saveConfig() end
  end)
end
UI.Separator()

local toFollowPos = {}
local WALK_DIST = 127
local walkOpts = {
  ignoreNonPathable = true,
  precision = 1,
  ignoreCreatures = true,
}

local function targetName()
  return tostring(config.target or "")
end

local function nameEq(a, b)
  return tostring(a or ""):lower() == tostring(b or ""):lower()
end

local function findTarget()
  local name = targetName()
  if name == "" then return nil end
  if type(getCreatureByName) == "function" then
    local c = getCreatureByName(name, true)
    if c then return c end
  end
  for _, spec in ipairs(g_map.getSpectators(pos(), true)) do
    if nameEq(spec:getName(), name) then return spec end
  end
  return nil
end

local function useAround()
  for i = -1, 1 do
    for j = -1, 1 do
      local tile = g_map.getTile({ x = posx() + i, y = posy() + j, z = posz() })
      if tile then
        local top = tile:getTopUseThing()
        if top then g_game.use(top) end
      end
    end
  end
end

local function walkToPos(dest)
  if not dest or dest.z ~= posz() then return false end
  if getDistanceBetween(pos(), dest) <= 1 then return true end
  if autoWalk(dest, WALK_DIST, walkOpts) then
    if type(delay) == "function" then delay(100) end
    return true
  end
  return false
end

macro(20, function()
  if not config.enabled then return end

  local name = targetName()
  if name == "" then return end

  -- g_game.follow limita a ~8 sqm; solo autoWalk
  if g_game.isFollowing and g_game.isFollowing() and g_game.cancelFollow then
    g_game.cancelFollow()
  end

  local target = findTarget()
  if target then
    local tpos = target:getPosition()
    if tpos then toFollowPos[tpos.z] = tpos end
  end

  if player:isWalking() then return end

  local dest = toFollowPos[posz()]
  if not dest then return end
  if getDistanceBetween(pos(), dest) <= 1 then return end

  walkToPos(dest)
end)

onCreaturePositionChange(function(creature, newPos, oldPos)
  if not config.enabled then return end
  local name = targetName()
  if name == "" then return end

  -- bajar agujero / escalera: subimos sin ver al lider
  if newPos and oldPos and nameEq(creature:getName(), player:getName())
      and not findTarget() and newPos.z > oldPos.z then
    say("exani tera")
    useAround()
  end

  if not nameEq(creature:getName(), name) then return end

  if not newPos then
    if oldPos then
      toFollowPos[oldPos.z] = oldPos
      schedule(200, function()
        if config.enabled then walkToPos(oldPos) end
      end)
      schedule(1000, function()
        if config.enabled then useAround() end
      end)
    end
    return
  end

  toFollowPos[newPos.z] = newPos

  if not oldPos then return end

  if oldPos.z == newPos.z then
    schedule(300, function()
      if not config.enabled then return end
      local tile = g_map.getTile({ x = oldPos.x, y = oldPos.y, z = oldPos.z })
      if tile and not tile:isWalkable() then
        local top = tile:getTopThing()
        if top and type(use) == "function" then use(top) end
      end
    end)
    walkToPos({ x = oldPos.x, y = oldPos.y, z = oldPos.z })
  else
    toFollowPos[oldPos.z] = oldPos
    walkToPos(oldPos)
    for i = 1, 8 do
      schedule(i * 200, function()
        if not config.enabled then return end
        walkToPos(oldPos)
        if getDistanceBetween(pos(), oldPos) == 0 and posz() > newPos.z and not findTarget() then
          say("exani tera")
        end
      end)
    end
    local stairTile = g_map.getTile({ x = newPos.x, y = newPos.y, z = oldPos.z })
      or g_map.getTile({ x = oldPos.x, y = oldPos.y, z = oldPos.z })
    if stairTile then
      local top = stairTile:getTopUseThing()
      if top then g_game.use(top) end
    end
  end
end)
