-- Auto Follow — Kondra + allowUnseen + escaleras click
setDefaultTab("Main")

if type(storage.autoFollow) ~= "table" then
  storage.autoFollow = {}
end
local config = storage.autoFollow
if type(config.target) ~= "string" then config.target = "" end
if type(config.enabled) ~= "boolean" then config.enabled = false end

pcall(function()
  local old = storage.comm_auto_follow
  if type(old) == "table" then
    if (config.target == nil or config.target == "") and type(old.leader) == "string" then
      config.target = old.leader
    end
    if old.enabled then config.enabled = true end
  end
end)

local ui = setupUI([[
Panel
  id: autoFollowPanel
  height: 48

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    text-align: center
    height: 19

  BotTextEdit
    id: targetEdit
    anchors.top: title.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 22
    font: verdana-11px-rounded
    focusable: true
    !placeholder: tr('Nombre exacto, ej: Kmkz Adrian')
]])
initToggle("autoFollow", "Auto Follow", ui)
ui.targetEdit:setText(config.target or "")
ui.targetEdit.onTextChange = function(widget, text)
  config.target = text or ""
  pcall(function()
    if type(saveConfig) == "function" then saveConfig() end
  end)
end
UI.Separator()

local toFollowPos = {}
local lastWalkDest = nil
local WALK_DIST = 127
local walkOpts = {
  ignoreNonPathable = true,
  precision = 1,
  ignoreCreatures = true,
  allowUnseen = true,
}

local function targetName()
  return tostring(config.target or "")
end

local function nameEq(a, b)
  return tostring(a or ""):lower() == tostring(b or ""):lower()
end

local function samePos(a, b)
  return a and b and a.x == b.x and a.y == b.y and a.z == b.z
end

local function findTarget()
  local name = targetName()
  if name == "" then return nil end
  if type(getCreatureByName) == "function" then
    local c = getCreatureByName(name, true)
    if c then return c end
  end
  for _, spec in ipairs(g_map.getSpectators(pos(), true)) do
    if nameEq(spec:getName(), name) then return spec end
  end
  return nil
end

local function useTileAt(p)
  if not p then return end
  local tile = g_map.getTile(p)
  if not tile then return end
  local useThing = tile:getTopUseThing()
  if useThing then g_game.use(useThing) end
  if not tile:isWalkable(false) then
    local top = tile:getTopThing()
    if top and type(use) == "function" then use(top) end
  end
end

local function useAround()
  for i = -1, 1 do
    for j = -1, 1 do
      useTileAt({ x = posx() + i, y = posy() + j, z = posz() })
    end
  end
end

local function chasePos(dest)
  if not dest or dest.z ~= posz() then return false end
  if getDistanceBetween(pos(), dest) <= 0 then return true end
  if type(CaveBot) == "table" and type(CaveBot.walkTo) == "function" then
    if CaveBot.walkTo(dest, WALK_DIST, walkOpts) then return true end
  end
  return autoWalk(dest, WALK_DIST, walkOpts)
end

local function resolveDest(target)
  if target then
    local tpos = target:getPosition()
    if tpos then
      toFollowPos[tpos.z] = tpos
      if tpos.z == posz() then
        return { x = tpos.x, y = tpos.y, z = tpos.z }
      end
    end
  end
  return toFollowPos[posz()]
end

local function followFloorChange(oldPos, newPos)
  if not oldPos then return end
  toFollowPos[oldPos.z] = oldPos
  lastWalkDest = nil

  local function step()
    if not config.enabled then return end
    chasePos(oldPos)
    useTileAt(oldPos)
    for _, d in ipairs({ {0,-1}, {0,1}, {-1,0}, {1,0} }) do
      useTileAt({ x = oldPos.x + d[1], y = oldPos.y + d[2], z = oldPos.z })
    end
    if newPos and newPos.z < oldPos.z and getDistanceBetween(pos(), oldPos) == 0 then
      useAround()
    end
    if newPos and newPos.z > oldPos.z and getDistanceBetween(pos(), oldPos) == 0
        and posz() > newPos.z and not findTarget() then
      say("exani tera")
    end
  end

  step()
  for i = 1, 15 do
    schedule(i * 80, step)
  end
end

macro(50, function()
  if not config.enabled then return end

  local name = targetName()
  if name == "" then return end

  if g_game.isFollowing and g_game.isFollowing() and g_game.cancelFollow then
    g_game.cancelFollow()
  end

  local target = findTarget()
  local dest = resolveDest(target)
  if not dest then return end

  if target then
    local tpos = target:getPosition()
    if tpos and tpos.z == posz() and getDistanceBetween(pos(), tpos) <= 1 then
      lastWalkDest = nil
      return
    end
  elseif getDistanceBetween(pos(), dest) <= 1 then
    return
  end

  if player:isWalking() and samePos(lastWalkDest, dest) then return end

  if chasePos(dest) then
    lastWalkDest = { x = dest.x, y = dest.y, z = dest.z }
  end
end)

onCreaturePositionChange(function(creature, newPos, oldPos)
  if not config.enabled then return end
  local name = targetName()
  if name == "" then return end

  if newPos and oldPos and nameEq(creature:getName(), player:getName())
      and not findTarget() and newPos.z > oldPos.z then
    say("exani tera")
    useAround()
  end

  if not nameEq(creature:getName(), name) then return end

  if not newPos then
    if oldPos then
      toFollowPos[oldPos.z] = oldPos
      lastWalkDest = nil
      schedule(50, function() if config.enabled then chasePos(oldPos) end end)
      schedule(300, function() if config.enabled then useAround() end end)
    end
    return
  end

  toFollowPos[newPos.z] = newPos
  lastWalkDest = nil

  if not oldPos then return end

  if oldPos.z == newPos.z then
    schedule(100, function()
      if config.enabled then useTileAt(oldPos) end
    end)
    chasePos({ x = oldPos.x, y = oldPos.y, z = oldPos.z })
  else
    followFloorChange(oldPos, newPos)
  end
end)
