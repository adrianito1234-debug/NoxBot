-- Auto Follow (siempre cargado; no lazy load)
setDefaultTab("Main")

if type(storage.autoFollow) ~= "table" then
  storage.autoFollow = {}
end
local config = storage.autoFollow
if type(config.target) ~= "string" then config.target = "" end
if type(config.enabled) ~= "boolean" then config.enabled = false end

pcall(function()
  local old = storage.comm_auto_follow
  if type(old) == "table" then
    if (config.target == nil or config.target == "") and type(old.leader) == "string" then
      config.target = old.leader
    end
    if old.enabled then
      config.enabled = true
    end
  end
end)

local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    text-align: center
]])
initToggle("autoFollow", "Auto Follow", ui)

UI.Label("Follow target (any player):")
UI.TextEdit(config.target or "", function(widget, text)
  config.target = text or ""
  pcall(function()
    if type(saveConfig) == "function" then saveConfig() end
  end)
end)
UI.Separator()

local toFollowPos = {}

local function targetName()
  return tostring(config.target or "")
end

local function nameEq(a, b)
  return tostring(a or ""):lower() == tostring(b or ""):lower()
end

local function findTarget()
  local name = targetName()
  if name == "" then return nil end
  if type(getCreatureByName) == "function" then
    local c = getCreatureByName(name)
    if c then return c end
  end
  for _, spec in ipairs(g_map.getSpectators(pos(), true)) do
    if nameEq(spec:getName(), name) then return spec end
  end
  return nil
end

local function walkToPos(dest)
  if not dest then return false end
  if getDistanceBetween(pos(), dest) <= 1 then return true end
  if type(CaveBot) == "table" and type(CaveBot.walkTo) == "function" then
    return CaveBot.walkTo(dest, 40, {
      ignoreNonPathable = true,
      precision = 1,
      ignoreCreatures = true,
      ignoreStairs = false,
    })
  end
  return autoWalk(dest, 40, { ignoreNonPathable = true, precision = 1 })
end

macro(50, function()
  if not config.enabled then
    if g_game.isFollowing and g_game.isFollowing() and g_game.cancelFollow then
      g_game.cancelFollow()
    end
    return
  end

  local name = targetName()
  if name == "" then return end

  local target = findTarget()
  if target then
    local tpos = target:getPosition()
    if tpos then toFollowPos[tpos.z] = tpos end
    if g_game.follow then
      local fc = g_game.getFollowingCreature and g_game.getFollowingCreature()
      if not fc or not nameEq(fc:getName(), name) then
        g_game.follow(target)
      end
    end
  end

  if player:isWalking() then return end
  local dest = toFollowPos[posz()]
  if not dest then return end
  if getDistanceBetween(pos(), dest) <= 1 then return end
  walkToPos(dest)
end)

onCreaturePositionChange(function(creature, newPos, oldPos)
  if not config.enabled then return end
  local name = targetName()
  if name == "" then return end
  if not nameEq(creature:getName(), name) then return end

  if newPos then
    toFollowPos[newPos.z] = newPos
  elseif oldPos then
    toFollowPos[oldPos.z] = oldPos
    schedule(150, function()
      if config.enabled then walkToPos(oldPos) end
    end)
    return
  end

  if not newPos or not oldPos then return end

  if oldPos.z == newPos.z then
    walkToPos({ x = oldPos.x, y = oldPos.y, z = oldPos.z })
  else
    toFollowPos[oldPos.z] = oldPos
    walkToPos(oldPos)
  end
end)
