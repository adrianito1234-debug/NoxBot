function noxAsList(t)
  if type(t) ~= "table" then return {} end
  if t[1] ~= nil then
    local out = {}
    for i, v in ipairs(t) do out[i] = v end
    if #out > 0 then return out end
  end
  local n = tonumber(t._n) or 0
  local tmp = {}
  for k, v in pairs(t) do
    local i = tonumber(k)
    if i then
      tmp[i] = v
      if i > n then n = i end
    end
  end
  local out = {}
  for i = 1, n do
    if tmp[i] ~= nil then out[#out + 1] = tmp[i] end
  end
  return out
end

function noxItemId(entry)
  if type(entry) == "number" then return entry end
  if type(entry) == "table" and entry.id then return entry.id end
  return nil
end

function noxItemIds(t)
  local r = {}
  if type(t) ~= "table" then return r end
  for _, entry in pairs(t) do
    local id = noxItemId(entry)
    if id then r[#r + 1] = id end
  end
  return r
end

function noxPersist(which)
  pcall(function()
    if type(noxSnapshotHeal) == "function" then noxSnapshotHeal() end
  end)
  pcall(function()
    if type(noxWriteHpOnOff) == "function" then noxWriteHpOnOff() end
  end)
  pcall(function()
    if type(saveConfig) == "function" then saveConfig() end
  end)
  if which == false then return end
  pcall(function()
    if type(vBotConfigSave) == "function" then
      vBotConfigSave(which or "heal")
    end
  end)
end

function initToggle(panelName, title, ui)
  if not ui then
    if type(storage[panelName]) ~= "table" then
      storage[panelName] = { enabled = false }
    end
    return storage[panelName]
  end
  ui:setId(panelName)
  ui.title:setText(title)

  if type(storage[panelName]) ~= "table" then
    storage[panelName] = {}
  end

  local config = storage[panelName]

  if type(config.enabled) ~= "boolean" then
    config.enabled = false
  end

  ui.title:setOn(config.enabled)
  ui.title.onClick = function(widget)
    config.enabled = not config.enabled
    widget:setOn(config.enabled)
    if type(noxPersist) == "function" then noxPersist(false) else
      if type(saveConfig) == "function" then saveConfig() end
    end
  end

  return config
end

function addMaker(panelName, title, windowStyle, buttonText)
  local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    text-align: center
    width: 130

  Button
    id: setup
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 3
    height: 17
    text: Setup

]])

  local config = initToggle(panelName, title, ui)
  if not ui then return config end

  local window = UI.createWindow(windowStyle)
  window:hide()

  ui.setup.onClick = function()
    window:show()
    window:raise()
    window:focus()
  end
  pcall(function()
    if ui.setup.setText then ui.setup:setText(buttonText or "Setup") end
    if ui.setup.setFont then ui.setup:setFont("verdana-11px-rounded") end
  end)

  return config, window, ui
end

function addToggle(panelName, title)
  local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    text-align: center

]])

  return initToggle(panelName, title, ui)
end

function bindSwitch(widget, config, key)
  widget:setOn(config[key])
  widget.onClick = function(switch)
    config[key] = not config[key]
    switch:setOn(config[key])
    if type(saveConfig) == "function" then saveConfig() end
  end
end

function bindCoords(config, key, fields, button)
  local function refresh()
    for axis, field in pairs(fields) do
      field:setText(tostring(config[key][axis] or 0))
    end
  end

  for axis, field in pairs(fields) do
    field.onTextChange = function(widget, text)
      config[key][axis] = tonumber(text) or 0
      if type(saveConfig) == "function" then saveConfig() end
    end
  end

  refresh()

  button.onClick = function()
    local playerPos = player:getPosition()
    if not playerPos then return end

    config[key] = { x = playerPos.x, y = playerPos.y, z = playerPos.z }
    refresh()
    if type(saveConfig) == "function" then saveConfig() end
  end
end
