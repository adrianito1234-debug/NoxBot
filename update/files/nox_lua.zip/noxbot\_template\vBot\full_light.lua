local function isDeusClient()
  if g_resources and type(g_resources.getWriteDir) == "function" then
    local ok, wd = pcall(g_resources.getWriteDir)
    if ok and type(wd) == "string" then
      wd = wd:lower()
      if wd:find("deusot", 1, true) or wd:find("deusold", 1, true) then
        return true
      end
    end
  end
  local opts = modules and modules.client_options
  if not (opts and type(opts.getOption) == "function") then return false end
  local ok, v = pcall(opts.getOption, "showLightEffects")
  return ok and v ~= nil
end

if isDeusClient() then return end

if type(setDefaultTab) ~= "function" then function setDefaultTab(name) end end
setDefaultTab("Tools")

local saved = nil

local function mapPanel()
  local gi = modules and modules.game_interface
  if not gi then
    return nil
  end
  if gi.gameMapPanel then
    return gi.gameMapPanel
  end
  if type(gi.getMapPanel) == "function" then
    local ok, panel = pcall(gi.getMapPanel)
    if ok then
      return panel
    end
  end
  return nil
end

local function applyLight()
  local opts = modules and modules.client_options
  if not saved and opts and type(opts.getOption) == "function" then
    saved = {
      enableLights = opts.getOption("enableLights"),
      ambientLight = opts.getOption("ambientLight"),
    }
  end
  if opts and type(opts.setOption) == "function" then
    pcall(opts.setOption, "enableLights", false, true)
    pcall(opts.setOption, "ambientLight", 100, true)
  end
  local panel = mapPanel()
  if not panel then
    return
  end
  pcall(function()
    panel:setDrawLights(false)
  end)
  pcall(function()
    panel:setMinimumAmbientLight(1.0)
  end)
end

local function restoreLight()
  local ambient = 0
  if saved and type(saved.ambientLight) == "number" then
    ambient = saved.ambientLight
  end
  local opts = modules and modules.client_options
  if opts and type(opts.setOption) == "function" then
    pcall(opts.setOption, "ambientLight", ambient, true)
    pcall(opts.setOption, "enableLights", true, true)
  end
  local panel = mapPanel()
  if panel then
    pcall(function()
      panel:setDrawLights(true)
    end)
    pcall(function()
      panel:setMinimumAmbientLight(ambient / 100)
    end)
  end
  saved = nil
end

local lightMacro = macro(100, "Light", function()
  applyLight()
end)

local setOn = lightMacro.setOn
local setOff = lightMacro.setOff
lightMacro.setOn = function(val)
  if val == false then
    return lightMacro.setOff()
  end
  applyLight()
  setOn()
end
lightMacro.setOff = function(val)
  if val == false then
    return lightMacro.setOn()
  end
  setOff()
  restoreLight()
end
