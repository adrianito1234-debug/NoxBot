-- NoxBot Private Script: Atk Anti Reflect
noxCommunityScript(function(config)
  if type(config.enabled) ~= "boolean" then config.enabled = false end

local tg

local tm = macro(10000000, "Atk Anti Reflect",function() end)

-- save outfits
onAttackingCreatureChange(function(new, old)
  if tm:isOff() then return end
  tg = (new and new:isPlayer()) and new:getName() or nil
end)

onTalk(function(n,l,m,t)
  if tm:isOff() then return end
  if t:lower():find("reflect") and tg == n then
    g_game.cancelAttackAndFollow()
  end
end)
end)