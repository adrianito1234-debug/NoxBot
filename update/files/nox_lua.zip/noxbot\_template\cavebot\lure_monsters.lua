CaveBot.Extensions.LureMonsters = {}
CaveBot.LureMonsters = {}

local ui
local window

local config = {
  enabled = false,
  startAt = 1,
  holdAt = 8,
  resumeAt = 0,
  radius = 5,
  pause = 200,
  onlyTargets = false,
}

local state = "normal"
local belowSince = nil
local lowStreak = 0
local lastStepPos = nil
local dontSave = false

local function resetState()
  state = "normal"
  belowSince = nil
  lowStreak = 0
  lastStepPos = nil
end

local function samePos(a, b)
  return a and b and a.x == b.x and a.y == b.y and a.z == b.z
end

local function resumeThreshold()
  if config.resumeAt > 0 then
    return config.resumeAt
  end
  return math.max(0, config.startAt - 1)
end

local function countMonsters()
  local p = player:getPosition()
  if not p then
    return 0
  end
  local r = config.radius
  local count = 0
  for _, spec in ipairs(g_map.getSpectatorsInRange(p, false, r, r)) do
    if spec:isMonster() then
      local hppc = spec:getHealthPercent()
      if hppc and hppc > 0 then
        if not config.onlyTargets
            or (TargetBot.Creature and #TargetBot.Creature.getConfigs(spec) > 0) then
          count = count + 1
        end
      end
    end
  end
  return count
end

CaveBot.LureMonsters.blocksTargeting = function()
  return config.enabled and state == "luring" and CaveBot.isOn()
end

CaveBot.LureMonsters.blocksCaveBot = function()
  return config.enabled and state == "hold" and CaveBot.isOn()
end

macro(100, function()
  if not config.enabled or not g_game.isOnline() or not CaveBot.isOn() then
    if state ~= "normal" then
      resetState()
    end
    return
  end
  local count = countMonsters()
  if config.holdAt > 0 and count >= config.holdAt then
    if state ~= "hold" then
      state = "hold"
      belowSince = nil
      CaveBot.resetWalking()
    end
  elseif state == "hold" then
    if count <= resumeThreshold() then
      if not belowSince then
        belowSince = now
      end
      if now - belowSince >= 200 then
        state = count >= config.startAt and "luring" or "normal"
        belowSince = nil
        lowStreak = 0
      end
    else
      belowSince = nil
    end
  elseif count >= config.startAt then
    state = "luring"
    lowStreak = 0
  elseif state == "luring" then
    lowStreak = lowStreak + 1
    if lowStreak >= 8 then
      state = "normal"
    end
  end
  if state == "luring" then
    TargetBot.allowCaveBot(300)
    if config.pause > 0 then
      local pos = player:getPosition()
      if pos and not samePos(pos, lastStepPos) then
        if lastStepPos then
          CaveBot.delay(config.pause)
        end
        lastStepPos = pos
      end
    end
  else
    lastStepPos = nil
  end
end)

CaveBot.Extensions.LureMonsters.setup = function()
  ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    text-align: center
    width: 130
    !text: tr('Lure Monsters')

  Button
    id: settings
    anchors.top: prev.top
    anchors.left: prev.right
    margin-left: 3
    width: 48
    height: 17
]])
  ui:setId("lureMonsters")
  pcall(function() ui.settings:setText("Setup") end)

  window = UI.createWindow("LureMonstersWindow")
  window:hide()

  ui.title:setOn(config.enabled)
  ui.title.onClick = function(widget)
    config.enabled = not config.enabled
    widget:setOn(config.enabled)
    resetState()
    CaveBot.save()
  end

  ui.settings.onClick = function()
    window:show()
    window:raise()
    window:focus()
  end


  local function bindNumber(id, minv, maxv, default)
    local w = window[id]
    dontSave = true
    w:setText(tostring(config[id]))
    dontSave = false
    w.onTextChange = function()
      if dontSave then return end
      local num = tonumber(w:getText())
      if num == nil then
        return
      end
      if num > maxv then
        num = maxv
        dontSave = true
        w:setText(tostring(num))
        dontSave = false
      end
      config[id] = math.max(minv, math.min(maxv, num))
      CaveBot.save()
    end
    w.onFocusChange = function(widget, focused)
      if focused then return end
      local num = tonumber(w:getText())
      if num == nil or num < minv then
        num = default
      end
      num = math.max(minv, math.min(maxv, num))
      dontSave = true
      w:setText(tostring(num))
      dontSave = false
      config[id] = num
      CaveBot.save()
    end
  end
  bindNumber("startAt", 1, 30, 1)
  bindNumber("holdAt", 0, 50, 8)
  bindNumber("resumeAt", 0, 50, 0)
  bindNumber("radius", 1, 15, 5)
  bindNumber("pause", 0, 2000, 200)

  window.onlyTargets:setOn(config.onlyTargets)
  window.onlyTargets.onClick = function(widget)
    config.onlyTargets = not config.onlyTargets
    widget:setOn(config.onlyTargets)
    CaveBot.save()
  end
end

CaveBot.Extensions.LureMonsters.onConfigChange = function(name, enabled, data)
  if type(data) ~= "table" then
    return
  end
  config.enabled = data.enabled == true
  config.startAt = tonumber(data.startAt) or 1
  config.holdAt = tonumber(data.holdAt) or 8
  config.resumeAt = tonumber(data.resumeAt) or 0
  config.radius = tonumber(data.radius) or 5
  config.pause = tonumber(data.pause) or 200
  config.onlyTargets = data.onlyTargets == true
  resetState()
  if not ui then
    return
  end
  ui.title:setOn(config.enabled)
  if window then
    dontSave = true
    window.startAt:setText(tostring(config.startAt))
    window.holdAt:setText(tostring(config.holdAt))
    window.resumeAt:setText(tostring(config.resumeAt))
    window.radius:setText(tostring(config.radius))
    window.pause:setText(tostring(config.pause))
    dontSave = false
    window.onlyTargets:setOn(config.onlyTargets)
  end
end

CaveBot.Extensions.LureMonsters.onSave = function()
  return {
    enabled = config.enabled,
    startAt = config.startAt,
    holdAt = config.holdAt,
    resumeAt = config.resumeAt,
    radius = config.radius,
    pause = config.pause,
    onlyTargets = config.onlyTargets,
  }
end
