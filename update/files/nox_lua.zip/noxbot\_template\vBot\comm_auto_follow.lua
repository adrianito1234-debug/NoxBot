-- NoxBot Private Script: Auto Follow
noxCommunityScript(function(config)
  storage.comm_auto_follow = storage.comm_auto_follow or config or {}
  config = storage.comm_auto_follow
  if type(config.leader) ~= "string" then config.leader = "" end
  if type(config.enabled) ~= "boolean" then config.enabled = false end

  setDefaultTab("Main")
  UI.Label("Follow target (any player):")
  UI.TextEdit(config.leader or "", function(widget, text)
    config.leader = text or ""
    if type(saveConfig) == "function" then saveConfig() end
  end)
  UI.Separator()

  local toFollowPos = {}

  local function targetName()
    return config.leader or ""
  end

  local function nameEq(a, b)
    return tostring(a or ""):lower() == tostring(b or ""):lower()
  end

  local function findTarget()
    local name = targetName()
    if name == "" then return nil end
    for _, spec in ipairs(g_map.getSpectators(pos(), true)) do
      if nameEq(spec:getName(), name) then return spec end
    end
    return nil
  end

  local function walkToPos(pos)
    if not pos then return false end
    if getDistanceBetween(pos(), pos) <= 1 then return true end
    if type(CaveBot) == "table" and type(CaveBot.walkTo) == "function" then
      return CaveBot.walkTo(pos, 40, {
        ignoreNonPathable = true,
        precision = 1,
        ignoreCreatures = true,
        ignoreStairs = false,
      })
    end
    return autoWalk(pos, 40, { ignoreNonPathable = true, precision = 1 })
  end

  -- Sin nombre: el macro arranca ON (los nombrados arrancan OFF y nunca corrían).
  macro(50, function()
    if not config.enabled then
      if g_game.isFollowing and g_game.isFollowing() and g_game.cancelFollow then
        g_game.cancelFollow()
      end
      return
    end

    local name = targetName()
    if name == "" then return end

    local target = findTarget()
    if target then
      local tpos = target:getPosition()
      if tpos then toFollowPos[tpos.z] = tpos end
      if g_game.follow then
        local fc = g_game.getFollowingCreature and g_game.getFollowingCreature()
        if not fc or not nameEq(fc:getName(), name) then
          g_game.follow(target)
        end
      end
    end

    if player:isWalking() then return end
    local dest = toFollowPos[posz()]
    if not dest then return end
    if getDistanceBetween(pos(), dest) <= 1 then return end

    if walkToPos(dest) and type(delay) == "function" then
      delay(80)
    end
  end)

  onCreaturePositionChange(function(creature, newPos, oldPos)
    if not config.enabled then return end
    local name = targetName()
    if name == "" then return end

    if newPos and oldPos and creature:getName() == player:getName()
        and not findTarget() and newPos.z > oldPos.z then
      say("exani tera")
      for i = -1, 1 do
        for j = -1, 1 do
          local tile = g_map.getTile({ x = posx() + i, y = posy() + j, z = posz() })
          if tile then
            local top = tile:getTopUseThing()
            if top then g_game.use(top) end
          end
        end
      end
    end

    if not nameEq(creature:getName(), name) then return end

    if newPos then
      toFollowPos[newPos.z] = newPos
    elseif oldPos then
      toFollowPos[oldPos.z] = oldPos
      schedule(150, function() if config.enabled then walkToPos(oldPos) end end)
      return
    end

    if not newPos or not oldPos then return end

    if oldPos.z == newPos.z then
      walkToPos({ x = oldPos.x, y = oldPos.y, z = oldPos.z })
    else
      toFollowPos[oldPos.z] = oldPos
      walkToPos(oldPos)
      for i = 1, 8 do
        schedule(i * 180, function()
          if not config.enabled then return end
          walkToPos(oldPos)
          if getDistanceBetween(pos(), oldPos) == 0 and posz() > newPos.z and not findTarget() then
            say("exani tera")
          end
        end)
      end
    end
  end)
end)
