-- NoxBot Private Script: Auto Follow
noxCommunityScript(function(config)
  if type(config.leader) ~= "string" then config.leader = "" end

  local toFollowPos = {}

  local function leaderName()
    return (config.leader or ""):match("^%s*(.-)%s*$") or ""
  end

  local function findLeader()
    local name = leaderName()
    if name == "" then return nil end
    return getCreatureByName(name)
  end

  macro(100, "Nox Auto Follow", function()
    if not config.enabled then return end
    local name = leaderName()
    if name == "" then return end

    local target = findLeader()
    if target then
      local tpos = target:getPosition()
      if tpos then toFollowPos[tpos.z] = tpos end
    end

    if player:isWalking() then return end

    local dest = toFollowPos[posz()]
    if not dest then return end

    if getDistanceBetween(pos(), dest) <= 1 then return end

    autoWalk(dest, 40, { ignoreNonPathable = true, precision = 1 })
  end)

  onCreaturePositionChange(function(creature, newPos, oldPos)
    if not config.enabled then return end
    local name = leaderName()
    if name == "" then return end

    if newPos and oldPos and creature:getName() == player:getName()
        and not findLeader() and newPos.z > oldPos.z then
      say("exani tera")
      for i = -1, 1 do
        for j = -1, 1 do
          local tile = g_map.getTile({ x = posx() + i, y = posy() + j, z = posz() })
          if tile then
            local top = tile:getTopUseThing()
            if top then g_game.use(top) end
          end
        end
      end
    end

    if creature:getName() ~= name then return end

    if newPos then
      toFollowPos[newPos.z] = newPos
    elseif oldPos then
      toFollowPos[oldPos.z] = oldPos
      schedule(150, function()
        if config.enabled then autoWalk(oldPos, 40, { ignoreNonPathable = true, precision = 1 }) end
      end)
      return
    end

    if not oldPos then return end

    if oldPos.z == newPos.z then
      schedule(200, function()
        if not config.enabled then return end
        local tile = g_map.getTile({ x = oldPos.x, y = oldPos.y, z = oldPos.z })
        if tile and not tile:isWalkable() then
          local topThing = tile:getTopThing()
          if topThing then use(topThing) end
        end
      end)
      autoWalk({ x = oldPos.x, y = oldPos.y, z = oldPos.z }, 40, { ignoreNonPathable = true, precision = 1 })
    else
      toFollowPos[oldPos.z] = oldPos
      autoWalk(oldPos, 40, { ignoreNonPathable = true, precision = 0 })
      for i = 1, 8 do
        schedule(i * 180, function()
          if not config.enabled then return end
          autoWalk(oldPos, 40, { ignoreNonPathable = true, precision = 0 })
          if getDistanceBetween(pos(), oldPos) == 0 and posz() > newPos.z and not findLeader() then
            say("exani tera")
          end
        end)
      end
      local tile = g_map.getTile({ x = newPos.x, y = newPos.y - 1, z = oldPos.z })
      if tile then
        local top = tile:getTopUseThing()
        if top then g_game.use(top) end
      end
    end
  end)
end)
