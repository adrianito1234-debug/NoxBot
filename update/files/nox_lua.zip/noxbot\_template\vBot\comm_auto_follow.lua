-- NoxBot Private Script: Auto Follow
noxCommunityScript(function(config)
  storage.comm_auto_follow = storage.comm_auto_follow or config or {}
  config = storage.comm_auto_follow
  if type(config.leader) ~= "string" then config.leader = "" end
  if type(config.enabled) ~= "boolean" then config.enabled = false end

  local toFollowPos = {}

  local function leaderName()
    return (config.leader or ""):match("^%s*(.-)%s*$") or ""
  end

  local function findLeader()
    local name = leaderName()
    if name == "" then return nil end
    if type(getPlayerByName) == "function" then
      local p = getPlayerByName(name, true)
      if p then return p end
    end
    return getCreatureByName(name, true)
  end

  local function walkToPos(pos)
    if not pos then return false end
    if getDistanceBetween(pos(), pos) <= 1 then return true end
    if type(CaveBot) == "table" and type(CaveBot.walkTo) == "function" then
      return CaveBot.walkTo(pos, 40, { ignoreNonPathable = true, precision = 1, ignoreCreatures = true })
    end
    return autoWalk(pos, 40, { ignoreNonPathable = true, precision = 1 })
  end

  local function syncFollow()
    if not config.enabled then
      if g_game.isFollowing and g_game.isFollowing() and g_game.cancelFollow then
        g_game.cancelFollow()
      end
      return
    end

    local name = leaderName()
    if name == "" then return end

    local target = findLeader()
    if target then
      local tpos = target:getPosition()
      if tpos then toFollowPos[tpos.z] = tpos end
      if g_game.follow and (not g_game.isFollowing or not g_game.isFollowing()) then
        g_game.follow(target)
      elseif g_game.getFollowingCreature then
        local fc = g_game.getFollowingCreature()
        if not fc or fc:getName():lower() ~= name:lower() then
          g_game.follow(target)
        end
      end
      return
    end

    if player:isWalking() then return end
    local dest = toFollowPos[posz()]
    if dest then walkToPos(dest) end
  end

  macro(100, "Nox Auto Follow", syncFollow)

  onCreaturePositionChange(function(creature, newPos, oldPos)
    if not config.enabled then return end
    local name = leaderName()
    if name == "" then return end

    if newPos and oldPos and creature:getName() == player:getName()
        and not findLeader() and newPos.z > oldPos.z then
      say("exani tera")
      for i = -1, 1 do
        for j = -1, 1 do
          local tile = g_map.getTile({ x = posx() + i, y = posy() + j, z = posz() })
          if tile then
            local top = tile:getTopUseThing()
            if top then g_game.use(top) end
          end
        end
      end
    end

    if creature:getName():lower() ~= name:lower() then return end

    if newPos then
      toFollowPos[newPos.z] = newPos
    elseif oldPos then
      toFollowPos[oldPos.z] = oldPos
      schedule(150, function() if config.enabled then walkToPos(oldPos) end end)
      return
    end

    if not newPos or not oldPos then return end

    if oldPos.z == newPos.z then
      schedule(200, function()
        if not config.enabled then return end
        local tile = g_map.getTile({ x = oldPos.x, y = oldPos.y, z = oldPos.z })
        if tile and not tile:isWalkable() then
          local topThing = tile:getTopThing()
          if topThing then use(topThing) end
        end
      end)
      walkToPos({ x = oldPos.x, y = oldPos.y, z = oldPos.z })
    else
      toFollowPos[oldPos.z] = oldPos
      walkToPos(oldPos)
      for i = 1, 8 do
        schedule(i * 180, function()
          if not config.enabled then return end
          walkToPos(oldPos)
          if getDistanceBetween(pos(), oldPos) == 0 and posz() > newPos.z and not findLeader() then
            say("exani tera")
          end
        end)
      end
    end
  end)

  syncFollow()
end)
