-- NoxBot Private Script: Auto Follow
noxCommunityScript(function(config)
  if type(config.leader) ~= "string" then config.leader = "" end

  local followMacro = macro(500, "Auto Follow", function()
    if not config.enabled then return end
  end)

  onCreaturePositionChange(function(creature, newPos, oldPos)
    if not config.enabled or followMacro:isOff() then return end
    local leader = config.leader or ""
    if leader == "" then return end

    if newPos and oldPos and creature:getName() == player:getName()
        and getCreatureByName(leader) == nil and newPos.z > oldPos.z then
      say("exani tera")
      for i = -1, 1 do
        for j = -1, 1 do
          local useTile = g_map.getTile({ x = posx() + i, y = posy() + j, z = posz() })
          if useTile then
            local top = useTile:getTopUseThing()
            if top then g_game.use(top) end
          end
        end
      end
    end

    if creature:getName() ~= leader then return end
    if not newPos then
      if oldPos then
        schedule(200, function()
          if config.enabled then autoWalk(oldPos) end
        end)
        schedule(1000, function()
          if not config.enabled then return end
          for i = -1, 1 do
            for j = -1, 1 do
              local useTile = g_map.getTile({ x = posx() + i, y = posy() + j, z = posz() })
              if useTile then
                local top = useTile:getTopUseThing()
                if top then g_game.use(top) end
              end
            end
          end
        end)
      end
      return
    end
    if not oldPos then return end

    if oldPos.z == newPos.z then
      schedule(300, function()
        if not config.enabled then return end
        local useTile = g_map.getTile({ x = oldPos.x, y = oldPos.y, z = oldPos.z })
        if useTile and not useTile:isWalkable() then
          local topThing = useTile:getTopThing()
          if topThing then use(topThing) end
        end
      end)
      autoWalk({ x = oldPos.x, y = oldPos.y, z = oldPos.z })
    else
      autoWalk(oldPos)
      for i = 1, 6 do
        schedule(i * 200, function()
          if not config.enabled then return end
          autoWalk(oldPos)
          if getDistanceBetween(pos(), oldPos) == 0 and posz() > newPos.z and getCreatureByName(leader) == nil then
            say("exani tera")
          end
        end)
      end
      local useTile = g_map.getTile({ x = newPos.x, y = newPos.y - 1, z = oldPos.z })
      if useTile then
        local top = useTile:getTopUseThing()
        if top then g_game.use(top) end
      end
    end
  end)
end)
