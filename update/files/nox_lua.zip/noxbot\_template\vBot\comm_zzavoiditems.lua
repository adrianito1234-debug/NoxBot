-- NoxBot Private Script: Avoiditems
noxCommunityScript(function(config)
  if type(config.enabled) ~= "boolean" then config.enabled = false end

local replace_id = 2110
local mark_color = "red"
if not config.avoid_items or type(config.avoid_items) ~= "table" then
  config.avoid_items = {2147,2145,2148,2146}
end

local avoidMacro = macro(10*60*1000,"Avoid Traps",function()
end)

local function parseItems(items)
  local parse = {}
  for e, entry in pairs(items) do
    local id = type(entry) == 'table' and entry.id or entry
    table.insert(parse,id)
  end
  return parse
end

local avoidContainer = UI.Container(function(widget, items)
  config.avoid_items = parseItems(items)
end, true)
avoidContainer:setHeight(35)
avoidContainer:setItems(parseItems(config.avoid_items))

local i = addIcon("qq",{text="Avoid\nTraps"}, avoidMacro)
i.text:setFont("verdana-11px-rounded")

onAddThing(function(tile, thing)
  if not avoidMacro:isOn() then return end
  if thing:isItem() then
    if not isOnTile(replace_id,tile) then
      local oldId = thing:getId()
      if table.find(config.avoid_items,oldId) then
        local item = thing
        if thing:isGround() then
          local create = Item.create()
          tile:addThing(create,1)
          item = create
        end
        item:setId(replace_id)
        item:setMarked(mark_color)
      end
    end
  end
end)
end)