setDefaultTab("Jitter")

UI.Separator()
UI.Label("Timing")
UI.Separator()

local panelName = "jitter"
local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    text-align: center
    width: 130
    !text: tr('Jitter')

  Button
    id: edit
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 3
    height: 17
    text: Setup
]])
ui:setId(panelName)

if type(storage[panelName]) ~= "table" then
  storage[panelName] = {}
end
local jitterCfg = storage[panelName]

if type(jitterCfg.enabled) ~= "boolean" then
  jitterCfg.enabled = false
end
if type(jitterCfg.humanizerEnabled) ~= "boolean" then
  jitterCfg.humanizerEnabled = false
end
if type(jitterCfg.healPriorityPct) ~= "number" then
  jitterCfg.healPriorityPct = 50
end
if type(jitterCfg.categories) ~= "table" then
  jitterCfg.categories = {}
end
if type(jitterCfg.inputSim) ~= "table" then
  jitterCfg.inputSim = {}
end

local jitterWindow = UI.createWindow("JitterWindow")
jitterWindow:hide()

local function ensureInputSimCfg()
  if context.jitter then
    context.jitter.getInputSim()
    if context.storage.jitter and context.storage.jitter.inputSim then
      jitterCfg.inputSim = context.storage.jitter.inputSim
    end
  end
  local sim = jitterCfg.inputSim
  if type(sim.keyHold) ~= "table" then
    sim.keyHold = { min = 45, max = 130 }
  end
  if type(sim.keyReleaseGap) ~= "table" then
    sim.keyReleaseGap = { min = 20, max = 80 }
  end
  if type(sim.mouse) ~= "table" then
    sim.mouse = {}
  end
  if type(sim.idleMicro) ~= "table" then
    sim.idleMicro = {}
  end
  if type(sim.longPause) ~= "table" then
    sim.longPause = {}
  end
  return sim
end

function syncJitterStorage()
  if not context.jitter then return end
  context.storage.jitter = context.storage.jitter or {}
  context.storage.jitter.humanizerEnabled = jitterCfg.humanizerEnabled
  context.storage.jitter.healPriorityPct = jitterCfg.healPriorityPct
  context.storage.jitter.categories = jitterCfg.categories
  if type(jitterCfg.inputSim) == "table" then
    context.storage.jitter.inputSim = jitterCfg.inputSim
  end
  context.jitter.getInputSim()
end

function saveJitterConfig()
  syncJitterStorage()
  if saveConfig then
    saveConfig()
  end
end

ui.title:setOn(jitterCfg.humanizerEnabled)
ui.title.onClick = function(widget)
  jitterCfg.humanizerEnabled = not jitterCfg.humanizerEnabled
  widget:setOn(jitterCfg.humanizerEnabled)
  saveJitterConfig()
  if context.jitter then
    if jitterCfg.humanizerEnabled then
      context.jitter._scheduleNextIdle()
      context.jitter._scheduleNextLongPauseWindow()
    else
      context.jitter.isLongPauseActive = false
      context.jitter._longPauseUntil = 0
    end
  end
end

ui.edit.onClick = function()
  jitterWindow:show()
  jitterWindow:raise()
  jitterWindow:focus()
end

local function addSection(title)
  local label = g_ui.createWidget("JitterSectionLabel", jitterWindow.content)
  label:setText(title)
  return label
end

local function bindMinMaxRow(row, cfg, onSave)
  row.minVal:setValue(cfg.min)
  row.maxVal:setValue(cfg.max)
  row.minVal.onValueChange = function(widget, value)
    cfg.min = value
    if cfg.max < cfg.min then
      cfg.max = cfg.min
      row.maxVal:setValue(cfg.max, true)
    end
    if onSave then onSave() end
    saveJitterConfig()
  end
  row.maxVal.onValueChange = function(widget, value)
    cfg.max = value
    if cfg.max < cfg.min then
      cfg.min = cfg.max
      row.minVal:setValue(cfg.min, true)
    end
    if onSave then onSave() end
    saveJitterConfig()
  end
end

local sim = ensureInputSimCfg()

addSection("Keyboard simulation (ms)")

local keyHoldRow = g_ui.createWidget("JitterSimRangeRow", jitterWindow.content)
keyHoldRow.name:setText("Key hold")
bindMinMaxRow(keyHoldRow, sim.keyHold)

local keyGapRow = g_ui.createWidget("JitterSimRangeRow", jitterWindow.content)
keyGapRow.name:setText("Gap key up / release")
bindMinMaxRow(keyGapRow, sim.keyReleaseGap)

addSection("Mouse simulation")

local mouseNoiseRow = g_ui.createWidget("JitterSimRangeRow", jitterWindow.content)
mouseNoiseRow.name:setText("Path noise (px)")
if not sim.mouse then sim.mouse = {} end
local mouseNoiseCfg = {
  min = sim.mouse.noiseMin or 1,
  max = sim.mouse.noiseMax or 3,
}
bindMinMaxRow(mouseNoiseRow, mouseNoiseCfg, function()
  sim.mouse.noiseMin = mouseNoiseRow.minVal:getValue()
  sim.mouse.noiseMax = mouseNoiseRow.maxVal:getValue()
end)

local bezierPanel = setupUI([[
Panel
  height: 22
  margin-top: 2
  BotSwitch
    id: bezier
    anchors.fill: parent
    text-align: center
    !text: tr('Mouse paths: Bezier curves')
]], jitterWindow.content)
bezierPanel.bezier:setOn(sim.mouse.useBezier ~= false)
bezierPanel.bezier.onClick = function(widget)
  sim.mouse.useBezier = widget:isOn()
  saveJitterConfig()
end

addSection("Idle and distraction")

local gaussianPanel = setupUI([[
Panel
  height: 22
  margin-top: 2
  BotSwitch
    id: gaussian
    anchors.fill: parent
    text-align: center
    !text: tr('Gaussian distribution (pre-action)')
]], jitterWindow.content)
gaussianPanel.gaussian:setOn(sim.useGaussian ~= false)
gaussianPanel.gaussian.onClick = function(widget)
  sim.useGaussian = widget:isOn()
  saveJitterConfig()
end

if not sim.idleMicro then sim.idleMicro = {} end
local idleRow = g_ui.createWidget("JitterSimRangeRow", jitterWindow.content)
idleRow.name:setText("Micro-move interval (sec)")
bindMinMaxRow(idleRow, {
  min = sim.idleMicro.intervalMinSec or 15,
  max = sim.idleMicro.intervalMaxSec or 45,
}, function()
  sim.idleMicro.intervalMinSec = idleRow.minVal:getValue()
  sim.idleMicro.intervalMaxSec = idleRow.maxVal:getValue()
end)

local idleEnable = setupUI([[
Panel
  height: 22
  margin-top: 2
  BotSwitch
    id: idle
    anchors.fill: parent
    text-align: center
    !text: tr('Idle micro mouse movements')
]], jitterWindow.content)
idleEnable.idle:setOn(sim.idleMicro.enabled ~= false)
idleEnable.idle.onClick = function(widget)
  sim.idleMicro.enabled = widget:isOn()
  saveJitterConfig()
end

if not sim.longPause then sim.longPause = {} end
local pauseDurRow = g_ui.createWidget("JitterSimRangeRow", jitterWindow.content)
pauseDurRow.name:setText("Long pause duration (sec)")
bindMinMaxRow(pauseDurRow, {
  min = sim.longPause.durationMinSec or 2,
  max = sim.longPause.durationMaxSec or 8,
}, function()
  sim.longPause.durationMinSec = pauseDurRow.minVal:getValue()
  sim.longPause.durationMaxSec = pauseDurRow.maxVal:getValue()
end)

local pauseEveryRow = g_ui.createWidget("JitterSimRangeRow", jitterWindow.content)
pauseEveryRow.name:setText("Long pause every (min)")
bindMinMaxRow(pauseEveryRow, {
  min = sim.longPause.everyMinMin or 3,
  max = sim.longPause.everyMaxMin or 7,
}, function()
  sim.longPause.everyMinMin = pauseEveryRow.minVal:getValue()
  sim.longPause.everyMaxMin = pauseEveryRow.maxVal:getValue()
end)

local pauseEnable = setupUI([[
Panel
  height: 22
  margin-top: 2
  BotSwitch
    id: pause
    anchors.fill: parent
    text-align: center
    !text: tr('Random long pauses (distraction)')
]], jitterWindow.content)
pauseEnable.pause:setOn(sim.longPause.enabled ~= false)
pauseEnable.pause.onClick = function(widget)
  sim.longPause.enabled = widget:isOn()
  saveJitterConfig()
end

jitterWindow.healPriorityPct:setValue(jitterCfg.healPriorityPct)
jitterWindow.healPriorityPct.onValueChange = function(widget, value)
  jitterCfg.healPriorityPct = value
  saveJitterConfig()
end

jitterWindow.closeButton.onClick = function()
  jitterWindow:hide()
end

syncJitterStorage()

if context.jitter then
  context.jitter._scheduleNextIdle()
  context.jitter._scheduleNextLongPauseWindow()
  if context.jitter.installDeferred then
    context.jitter.installDeferred()
  end
end

macro(500, function()
  if context.jitter and context.jitter.installDeferred then
    context.jitter.installDeferred()
  end
  if context.jitter and context.jitter.tickBackground then
    context.jitter.tickBackground()
  end
end)

Jitter = context.jitter

function jitterDelay(category, opts)
  if not context.jitter then
    return opts and opts.baseMs or 0
  end
  return context.jitter.sample(category or "actions", opts)
end

function buildInputPlan(category, opts)
  if not context.jitter then return nil end
  return context.jitter.buildInputPlan(category, opts)
end
