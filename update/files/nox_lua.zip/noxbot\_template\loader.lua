-- NoxBot loader (Xyro-order, nox_bot paths) — UNA sola carga por script
-- El sandbox del bot no tiene _G real; usamos el entorno del script.
if __NOXBOT_LOADER_DONE then return end
__NOXBOT_LOADER_DONE = true

-- NO stubear setupUI para que retorne nil (eso rompe todo el UI).
if type(setDefaultTab) ~= "function" then
  function setDefaultTab(name) end
end

pcall(function()
  local cls = UISpinBox
  if cls == nil or cls.__noxSpinPatched then return end
  cls.__noxSpinPatched = true
  local function install(name, field)
    local orig = cls[name]
    cls[name] = function(self, v)
      v = tonumber(v)
      if not self or v == nil then return end
      if type(orig) == 'function' then
        pcall(orig, self, v)
      end
      pcall(function() self[field] = v end)
    end
  end
  install('setMaximum', 'maximum')
  install('setMinimum', 'minimum')
end)

local function safe(fn)
  local ok, err = pcall(fn)
  if not ok then
    pcall(function()
      local e = tostring(err)
      if type(warn) == "function" then warn(e) end
      if type(message) == "function" then message("error", e) end
    end)
  end
end

CaveBot = CaveBot or {}
CaveBot.Extensions = CaveBot.Extensions or {}
if type(CaveBot.delay) ~= "function" then
  CaveBot.delay = function(value)
    value = tonumber(value) or 50
    if type(delay) == "function" then return delay(value) end
  end
end
if type(CaveBot.isOn) ~= "function" then CaveBot.isOn = function() return false end end
if type(CaveBot.isOff) ~= "function" then CaveBot.isOff = function() return true end end
TargetBot = TargetBot or {}
if type(TargetBot.isOn) ~= "function" then TargetBot.isOn = function() return false end end
if type(TargetBot.isOff) ~= "function" then TargetBot.isOff = function() return true end end
if type(CaveBotList) ~= "function" then
  CaveBotList = function()
    if CaveBot and type(CaveBot.actionList) == "table" then return CaveBot.actionList end
    return {}
  end
end
storage = storage or {}
storage.extras = storage.extras or {}
-- Stub YA: hp/macros pueden tickear antes de que cargue vlib.lua
vBot = vBot or {}
-- Todos los scripts cargan. No apagar nada desde el loader.
storage.disabledScripts = {}
storage.__noxSlimV1 = nil

-- Perfil activo: lo fija bot.lua segun el dropdown (antes de cargar loader).
if type(__noxbot_char_cfg) ~= "string" or __noxbot_char_cfg == "" then
  __noxbot_char_cfg = tostring(g_game.getCharacterName() or ""):gsub("%s+", "_")
  if __noxbot_char_cfg == "" then __noxbot_char_cfg = "_template" end
end
if type(saveConfig) == "function" then
  noxSave = saveConfig
end
local function noxCharCfg()
  if type(__noxbot_char_cfg) == "string" and __noxbot_char_cfg ~= "" then
    return __noxbot_char_cfg
  end
  local n = tostring(g_game.getCharacterName() or ""):gsub("%s+", "_")
  if n ~= "" then __noxbot_char_cfg = n end
  return __noxbot_char_cfg or "_template"
end

-- Char nuevo / perfil a medias: copia scripts que falten desde _template (sin pisar configs).
safe(function()
  local cfg = noxCharCfg()
  if cfg == "" or cfg == "_template" then return end
  if type(g_resources.readFileContents) ~= "function" or type(g_resources.writeFileContents) ~= "function" then
    return
  end
  local function ensureDir(path)
    local acc = ""
    for part in tostring(path):gmatch("[^/]+") do
      acc = acc .. "/" .. part
      pcall(function() g_resources.makeDir(acc) end)
    end
  end
  local function copyIfMissing(src, dst)
    if g_resources.fileExists and g_resources.fileExists(dst) then return end
    if g_resources.fileExists and not g_resources.fileExists(src) then return end
    local ok, data = pcall(function() return g_resources.readFileContents(src) end)
    if not ok or type(data) ~= "string" or data == "" then return end
    pcall(function()
      local parent = tostring(dst):match("^(.*)/[^/]+$")
      if parent then ensureDir(parent) end
      g_resources.writeFileContents(dst, data)
    end)
  end
  local function syncTree(subdir)
    local srcDir = "/noxbot/_template/" .. subdir
    local dstDir = "/noxbot/" .. cfg .. "/" .. subdir
    ensureDir(dstDir)
    local files = {}
    pcall(function()
      files = g_resources.listDirectoryFiles(srcDir, false, false) or {}
    end)
    for _, file in ipairs(files) do
      local name = tostring(file):match("([^/\\]+)$") or tostring(file)
      local ext = name:match("%.([%w]+)$")
      if ext then
        local el = ext:lower()
        if el == "lua" or el == "otui" or el == "png" then
          copyIfMissing(srcDir .. "/" .. name, dstDir .. "/" .. name)
        end
      end
    end
  end
  copyIfMissing("/noxbot/_template/loader.lua", "/noxbot/" .. cfg .. "/loader.lua")
  syncTree("vBot")
  syncTree("cavebot")
  syncTree("targetbot")
  -- Private Scripts: siempre desde _template (autoupdate no pisaba community/)
  pcall(function()
    local function copyOverwrite(src, dst)
      if not g_resources.fileExists or not g_resources.fileExists(src) then return end
      local ok, data = pcall(function() return g_resources.readFileContents(src) end)
      if ok and type(data) == "string" and data ~= "" then
        local parent = tostring(dst):match("^(.*)/[^/]+$")
        if parent then ensureDir(parent) end
        pcall(function() g_resources.writeFileContents(dst, data) end)
      end
    end
    local commSrc = "/noxbot/_template/vBot/community"
    local commDst = "/noxbot/" .. cfg .. "/vBot/community"
    ensureDir(commDst)
    local files = g_resources.listDirectoryFiles(commSrc, false, false) or {}
    for _, file in ipairs(files) do
      local name = tostring(file):match("([^/\\]+)$") or tostring(file)
      if name:match("%.(%w+)$") then
        copyOverwrite(commSrc .. "/" .. name, commDst .. "/" .. name)
      end
    end
  end)
end)

-- Asegura carpetas escribibles (si no, HealBot/Combo/Supplies no guardan)
safe(function()
  local cfg = noxCharCfg()
  if cfg == "" then return end
  local function ensureDir(path)
    local acc = ""
    for part in tostring(path):gmatch("[^/]+") do
      acc = acc .. "/" .. part
      pcall(function() g_resources.makeDir(acc) end)
    end
  end
  ensureDir("/noxbot/" .. cfg)
  ensureDir("/noxbot/" .. cfg .. "/vBot_configs")
  ensureDir("/noxbot/" .. cfg .. "/storage")
  ensureDir("/noxbot/" .. cfg .. "/cavebot_configs")
  ensureDir("/noxbot/" .. cfg .. "/targetbot_configs")
  for i = 0, 10 do
    ensureDir("/noxbot/" .. cfg .. "/vBot_configs/profile_" .. i)
  end
end)

safe(function()
  local cfg = noxCharCfg()
  local seen = {}
  local function importPath(path)
    path = tostring(path or ""):gsub("\\", "/")
    if path == "" or seen[path] then return end
    seen[path] = true
    if not g_resources or not g_resources.fileExists or not g_resources.fileExists(path) then return end
    local ok = pcall(function() g_ui.importStyle(path) end)
    if not ok and g_ui.importStyleFromString then
      pcall(function()
        local code = g_resources.readFileContents(path)
        if type(code) == "string" and code ~= "" then g_ui.importStyleFromString(code) end
      end)
    end
  end
  local bases = {
    "/noxbot/" .. cfg .. "/vBot",
    "/noxbot/_template/vBot",
    "/noxbot/" .. cfg .. "/cavebot",
    "/noxbot/_template/cavebot",
    "/noxbot/" .. cfg .. "/targetbot",
    "/noxbot/_template/targetbot",
  }
  local otuiNames = {
    "use_item_messages.otui", "legacy_hotkeys.otui", "HealBot.otui", "supplies.otui",
    "AttackBot.otui", "extras.otui", "energy_equip.otui", "new_healer.otui",
    "analyzer.otui", "stop_cavebot_if.otui", "siolist.otui", "equipper.otui",
    "script_manager.otui", "pushmax.otui", "eat_food.otui", "player_training.otui",
    "Dropper.otui", "playerlist.otui", "depositer_config.otui", "Conditions.otui",
    "manatrain.otui", "combo.otui", "makers.otui", "BotServer.otui", "Jitter.otui", "alarms.otui",
  }
  local caveOtui = {
    "cavebot.otui", "config.otui", "editor.otui", "minimap_waypoints.otui", "lure_monsters.otui",
  }
  for _, base in ipairs({ "/noxbot/" .. cfg, "/noxbot/_template" }) do
    for _, name in ipairs(otuiNames) do
      importPath(base .. "/vBot/" .. name)
    end
    pcall(function()
      if g_resources.listDirectoryFiles then
        local comm = base .. "/vBot/community"
        for _, name in ipairs(g_resources.listDirectoryFiles(comm) or {}) do
          if type(name) == "string" and name:match("%.otui$") then
            importPath(comm .. "/" .. name)
          end
        end
      end
    end)
    for _, name in ipairs(caveOtui) do
      importPath(base .. "/cavebot/" .. name)
    end
    importPath(base .. "/targetbot/looting.otui")
    importPath(base .. "/targetbot/target.otui")
    importPath(base .. "/targetbot/creature_editor.otui")
  end
end)

-- Solo path relativo. Nunca /vBot/ + vBot/ (eso duplicaba UI/macros/hotkeys).
local loadedScripts = __noxbot_loaded_scripts or {}
__noxbot_loaded_scripts = loadedScripts
-- Capturar dofile del sandbox YA (si luego algo lo pisa, seguimos bien)
local botDofile = dofile
if type(context) == "table" and type(context.dofile) == "function" then
  botDofile = context.dofile
end
local function loadScript(name)
  if loadedScripts[name] then return end
  loadedScripts[name] = true
  local rel = "vBot/" .. name .. ".lua"
  local cfg = noxCharCfg()
  local full = "/noxbot/" .. cfg .. "/" .. rel
  if type(g_resources.fileExists) == "function" and not g_resources.fileExists(full) then
    -- Ultimo intento: copiar ese archivo suelto desde _template
    pcall(function()
      local src = "/noxbot/_template/" .. rel
      if g_resources.fileExists(src) then
        g_resources.writeFileContents(full, g_resources.readFileContents(src))
      end
    end)
    if type(g_resources.fileExists) == "function" and not g_resources.fileExists(full) then
      return -- no spamear error rojo; el resto del bot sigue
    end
  end
  safe(function()
    if type(botDofile) == "function" then botDofile(rel) end
  end)
end

-- MISMO orden que _Loader de referencia _Loader.lua
local luaFiles = {
  -- vlib ANTES de hp/manatrain (si no: vBot nil → spam Macro execution error)
  "main", "items", "vlib", "hp", "manatrain", "new_cavebot_lib",
  "configs", "panel_widgets", "script_manager", "extras", "cavebot",
  "playerlist", "BotServer", "alarms", "Conditions", "Equipper",
  "pushmax", "combo", "HealBot", "new_healer", "AttackBot",
  "legacy_hotkeys", "use_item_messages", "noxbot_scripts", "ingame_editor", "Dropper", "Containers",
  "quiver_manager", "quiver_label", "tools", "antiRs",
  "depot_withdraw", "eat_food", "equip", "exeta", "spy_level",
  "spell_timers", "supplies", "stop_cavebot_if", "depositer_config",
  "npc_talk", "xeno_menu", "hold_target", "full_light", "makers",
  "player_training", "auto_trap", "cavebot_control_panel", "hud"
}

local essentialScripts = {
  main=true, items=true, hp=true, vlib=true, new_cavebot_lib=true,
  configs=true, panel_widgets=true, script_manager=true, cavebot=true,
  hud=true, noxbot_scripts=true,
}

local toggleableScripts = {}
for _, name in ipairs(luaFiles) do
  if not essentialScripts[name] then
    toggleableScripts[#toggleableScripts + 1] = name
  end
end
vBotToggleableScripts = toggleableScripts

-- Cura/base un poco mas rapido; el resto deja respirar al cliente.
local coreScripts = {
  main=true, items=true, hp=true, manatrain=true, vlib=true, new_cavebot_lib=true,
  configs=true, panel_widgets=true, script_manager=true, extras=true, cavebot=true,
  HealBot=true, Conditions=true, eat_food=true, equip=true, hud=true,
}

local queue = {}
for _, file in ipairs(luaFiles) do
  if essentialScripts[file] or not storage.disabledScripts[file] then
    queue[#queue + 1] = file
  end
end

local overlay = nil
local function destroyOverlay()
  if not overlay then return end
  local w = overlay
  overlay = nil
  pcall(function() w:destroy() end)
end

-- Generacion: al Off/On o refresh, clear() sube modules.nox_bot.__noxLoadId
-- y las scheduleEvent viejas se ignoran (si no: 0-100% y luego vuelve al 6%).
-- NO usar rawget: el sandbox del bot no lo tiene.
local function bumpLoadId()
  local id = 1
  pcall(function()
    local m = modules.nox_bot
    if m then
      id = (tonumber(m.__noxLoadId) or 0) + 1
      m.__noxLoadId = id
    end
  end)
  return id
end
local function currentLoadId()
  local id = 0
  pcall(function()
    local m = modules.nox_bot
    if m then id = tonumber(m.__noxLoadId) or 0 end
  end)
  return id
end
local loadId = bumpLoadId()
local function stillValid()
  return currentLoadId() == loadId
end

-- Overlay inline: no depende de /vBot/loading.otui (esa ruta no existe en OTC).
local function showOverlay()
  pcall(function()
    destroyOverlay()
    -- Quita restos de una carga anterior
    pcall(function()
      local root = g_ui.getRootWidget()
      if not root then return end
      for _, ch in pairs(root:getChildren()) do
        if ch and (ch:getId() == "noxLoadOverlay" or ch.noxLoadOverlay) then
          pcall(function() ch:destroy() end)
        end
      end
    end)
    if type(setupUI) ~= "function" then return end
    local w = setupUI([[
Panel
  id: noxLoadOverlay
  anchors.fill: parent
  background-color: #00000099
  focusable: false
  phantom: false

  Panel
    id: card
    size: 360 168
    anchors.horizontalCenter: parent.horizontalCenter
    anchors.verticalCenter: parent.verticalCenter
    background-color: #140a0aee
    border-width: 1
    border-color: #8a1c1c
    padding: 14

    Label
      id: title
      anchors.top: parent.top
      anchors.left: parent.left
      anchors.right: parent.right
      text-align: center
      font: verdana-11px-rounded
      color: #e8c56a
      text: NoxBot

    Label
      id: subtitle
      anchors.top: title.bottom
      anchors.left: parent.left
      anchors.right: parent.right
      margin-top: 4
      text-align: center
      font: verdana-11px-rounded
      color: #cfcfcf
      text: Preparando el bot

    Panel
      id: track
      height: 18
      anchors.left: parent.left
      anchors.right: parent.right
      anchors.top: subtitle.bottom
      margin-top: 16
      background-color: #1a0c0c
      border-width: 1
      border-color: #5a1414

      Panel
        id: fill
        anchors.left: parent.left
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        width: 2
        background-color: #c41e1e

    Label
      id: percent
      anchors.top: track.bottom
      anchors.left: parent.left
      anchors.right: parent.right
      margin-top: 10
      text-align: center
      font: verdana-11px-rounded
      color: #ffd27a
      text: 0%

    Label
      id: step
      anchors.top: percent.bottom
      anchors.left: parent.left
      anchors.right: parent.right
      margin-top: 2
      text-align: center
      font: verdana-11px-rounded
      color: #9a9a9a
      text:
]], g_ui.getRootWidget())
    if w then
      pcall(function()
        w.botWidget = true
        w.noxLoadOverlay = true
        w:raise()
      end)
      overlay = w
    end
  end)
end

local function setProgress(pct, name)
  if not stillValid() then return end
  pct = math.max(0, math.min(100, tonumber(pct) or 0))
  pcall(function()
    if not overlay then return end
    local card = overlay.card or overlay
    if card.percent then card.percent:setText(tostring(pct) .. "%") end
    if card.step and name then card.step:setText("Cargando " .. tostring(name)) end
    local track = card.track
    local fill = track and track.fill
    if fill and track and track.getWidth then
      local w = tonumber(track:getWidth()) or 0
      if w > 4 then fill:setWidth(math.max(2, math.floor((w - 2) * pct / 100))) end
    end
  end)
end

-- OTC scheduleEvent (hilo del juego). Fallback: schedule del bot. Ultimo: sync.
local function later(ms, fn)
  ms = tonumber(ms) or 30
  if type(scheduleEvent) == "function" then
    scheduleEvent(fn, ms)
    return
  end
  if type(schedule) == "function" then
    schedule(ms, fn)
    return
  end
  fn()
end

local finished = false
local function finishLoad()
  if finished or not stillValid() then return end
  finished = true
  if type(CaveBot.delay) ~= "function" then
    CaveBot.delay = function(value)
      if type(delay) == "function" then return delay(tonumber(value) or 50) end
    end
  end
  safe(function()
    if type(setDefaultTab) == "function" then setDefaultTab("Main") end
  end)
  setProgress(100, "listo")
  later(250, function()
    if not stillValid() then return end
    pcall(function()
      local m = modules.nox_bot
      if m and type(m.noxFixAllSetupButtons) == "function" then
        m.noxFixAllSetupButtons()
      end
      if m and type(m.noxApplyMainTabLogo) == "function" and m.__noxMainLogoPanel then
        local char = ""
        pcall(function()
          char = sanitizeChar and sanitizeChar(g_game.getCharacterName()) or ""
        end)
        m.noxApplyMainTabLogo(m.__noxMainLogoPanel, char)
      end
    end)
  end)
  later(200, function()
    if stillValid() then destroyOverlay() end
  end)
end

local function beginCommunityPhase()
  if type(noxCommunityDeferredBootstrap) ~= "function" then
    finishLoad()
    return
  end
  local list = noxCommunityEnabledList and noxCommunityEnabledList() or {}
  if #list == 0 then
    finishLoad()
    return
  end
  setProgress(72, "scripts comunidad")
  noxCommunityDeferredBootstrap({
    msPerScript = 65,
    stillValid = stillValid,
    later = later,
    onProgress = function(pct, name)
      local p = 72 + math.floor((tonumber(pct) or 0) * 28 / 100)
      setProgress(p, "comunidad: " .. tostring(name))
    end,
    onDone = finishLoad,
  })
end

showOverlay()
setProgress(1, "NoxBot")

if #queue == 0 then
  beginCommunityPhase()
else
  local idx = 1
  local function step()
    if not stillValid() then
      destroyOverlay()
      return
    end
    if finished then return end
    if idx > #queue then
      beginCommunityPhase()
      return
    end
    local file = queue[idx]
    idx = idx + 1
    pcall(function() loadScript(file) end)
    if not stillValid() then
      destroyOverlay()
      return
    end
    setProgress(math.floor((idx - 1) * 72 / #queue), file)
    if idx > #queue then
      beginCommunityPhase()
      return
    end
    local wait = coreScripts[file] and 18 or 35
    later(wait, step)
  end
  later(50, step)
end
