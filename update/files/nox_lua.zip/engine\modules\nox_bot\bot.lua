botWindow = nil
botButton = nil
contentsPanel = nil
editWindow = nil

local checkEvent = nil

local botStorage = {}
local botStorageFile = nil
local botWebSockets = {}
local botMessages = nil
local botTabs = nil
local botExecutor = nil

local configList = nil
local enableButton = nil
local executeEvent = nil
local statusLabel = nil
local __noxHudTick = nil

local configManagerUrl = "http://otclient.ovh/configs.php"

local function noxB64Lib()
  if type(base64) == "table" and type(base64.encode) == "function" then return base64 end
  if type(context) == "table" and type(context.base64) == "table" then return context.base64 end
  return nil
end

local function noxDevRoot()
  local home = os.getenv and (os.getenv("USERPROFILE") or os.getenv("HOME"))
  if home and home ~= "" then
    return home .. "/Desktop/Proyecto Nox/NoxBot-Dev/"
  end
  return nil
end

local function noxDecodeLogoB64File(virtPath)
  local b64lib = noxB64Lib()
  if not b64lib or not b64lib.decode then return nil end
  local ok, chunk = pcall(g_resources.readFileContents, virtPath)
  if not ok or type(chunk) ~= "string" or #chunk < 50 then return nil end
  local embedded = chunk:match("return%s+%[%[([%s%S]-)%]%]")
  if not embedded then return nil end
  embedded = embedded:gsub("%s+", "")
  local okDec, raw = pcall(b64lib.decode, embedded)
  if okDec and type(raw) == "string" and #raw > 100 then return raw end
  return nil
end

local function noxLogoBytes()
  for _, p in ipairs({
    "/noxbot/pack/nox_bot/nox_logo_b64.lua",
    "/modules/nox_bot/nox_logo_b64.lua",
    "/noxbot/_template/vBot/nox_logo_b64.lua",
  }) do
    local raw = noxDecodeLogoB64File(p)
    if raw then return raw end
  end
  for _, p in ipairs({
    "/noxbot/pack/nox_bot/nox_mini_b64.lua",
    "/modules/nox_bot/nox_mini_b64.lua",
    "/noxbot/_template/vBot/nox_mini_b64.lua",
  }) do
    local raw = noxDecodeLogoB64File(p)
    if raw then return raw end
  end
  for _, path in ipairs({
    "/modules/nox_bot/noxbot_logo_top.png",
    "/noxbot/pack/nox_bot/noxbot_logo_top.png",
    "/modules/nox_bot/noxbot_mini.png",
    "/noxbot/pack/nox_bot/noxbot_mini.png",
    "/modules/nox_bot/noxbot_icon.png",
    "/noxbot/pack/nox_bot/noxbot_icon.png",
    "noxbot_logo_top.png",
    "noxbot_mini.png",
  }) do
    local okRead, data = pcall(g_resources.readFileContents, path)
    if okRead and type(data) == "string" and #data > 100 then return data end
  end
  local devRoot = noxDevRoot()
  if devRoot then
    for _, name in ipairs({ "noxbot_logo_top.png", "noxbot_mini.png", "noxbot_icon.png" }) do
      local ok, data = pcall(function()
        local f = io.open(devRoot .. name, "rb")
        if not f then return nil end
        local raw = f:read("*a")
        f:close()
        return raw
      end)
      if ok and type(data) == "string" and #data > 100 then return data end
    end
  end
  return nil
end

function noxDeployLogoAssets(charCfg)
  charCfg = tostring(charCfg or "")
  if charCfg == "" then charCfg = "_template" end
  local top = noxDecodeLogoB64File("/noxbot/pack/nox_bot/nox_logo_b64.lua")
    or noxDecodeLogoB64File("/modules/nox_bot/nox_logo_b64.lua")
    or noxDecodeLogoB64File("/noxbot/_template/vBot/nox_logo_b64.lua")
  local mini = noxDecodeLogoB64File("/noxbot/pack/nox_bot/nox_mini_b64.lua")
    or noxDecodeLogoB64File("/modules/nox_bot/nox_mini_b64.lua")
    or noxDecodeLogoB64File("/noxbot/_template/vBot/nox_mini_b64.lua")
  if not top then
    local ok, data = pcall(g_resources.readFileContents, "/noxbot/pack/nox_bot/noxbot_logo_top.png")
    if ok and type(data) == "string" and #data > 100 then top = data end
  end
  if not mini then
    local ok, data = pcall(g_resources.readFileContents, "/noxbot/pack/nox_bot/noxbot_mini.png")
    if ok and type(data) == "string" and #data > 100 then mini = data end
  end
  if not top then top = mini end
  if not mini then mini = top end
  if not top and not mini then return end
  local function writeLogo(path, data)
    if type(data) ~= "string" or #data < 100 then return end
    pcall(function() g_resources.writeFileContents(path, data) end)
  end
  local vBot = "/noxbot/" .. charCfg .. "/vBot"
  writeLogo(vBot .. "/noxbot_logo_top.png", top)
  writeLogo(vBot .. "/noxbot_mini.png", mini)
  writeLogo(vBot .. "/noxbot_icon.png", mini or top)
  writeLogo("/noxbot/pack/nox_bot/noxbot_logo_top.png", top)
  writeLogo("/noxbot/pack/nox_bot/noxbot_mini.png", mini)
  writeLogo("/noxbot/pack/nox_bot/noxbot_icon.png", mini or top)
  writeLogo("/modules/nox_bot/noxbot_logo_top.png", top)
  writeLogo("/modules/nox_bot/noxbot_mini.png", mini)
  writeLogo("/modules/nox_bot/noxbot_icon.png", mini or top)
  pcall(function() if top then g_resources.writeFileContents("noxbot_logo_top.png", top) end end)
  pcall(function() if mini then g_resources.writeFileContents("noxbot_mini.png", mini) end end)
end

function noxApplyLogoImage(img, charCfg)
  if not img then return false end
  charCfg = tostring(charCfg or "")
  if charCfg == "" then charCfg = "_template" end
  noxDeployLogoAssets(charCfg)
  local paths = {
    "/noxbot/" .. charCfg .. "/vBot/noxbot_logo_top.png",
    "/noxbot/" .. charCfg .. "/vBot/noxbot_mini.png",
    "/modules/nox_bot/noxbot_logo_top.png",
    "/modules/nox_bot/noxbot_mini.png",
    "/noxbot/pack/nox_bot/noxbot_logo_top.png",
    "/noxbot/pack/nox_bot/noxbot_mini.png",
    "noxbot_logo_top.png",
    "noxbot_mini.png",
  }
  for _, path in ipairs(paths) do
    if type(img.setImageSource) == "function" then
      local ok = pcall(function() img:setImageSource(path) end)
      if ok then
        pcall(function() img:show() end)
        return true
      end
    end
    local okRead, data = pcall(g_resources.readFileContents, path)
    if okRead and type(data) == "string" and #data > 100 then
      local b64lib = noxB64Lib()
      if b64lib and type(img.setImageSourceBase64) == "function" then
        if pcall(function() img:setImageSourceBase64(b64lib.encode(data)) end) then
          pcall(function() img:show() end)
          return true
        end
      end
    end
  end
  local raw = noxLogoBytes()
  if raw then
    local b64lib = noxB64Lib()
    pcall(function() g_resources.writeFileContents("noxbot_logo_top.png", raw) end)
    if b64lib and type(img.setImageSourceBase64) == "function" then
      if pcall(function() img:setImageSourceBase64(b64lib.encode(raw)) end) then
        pcall(function() img:show() end)
        return true
      end
    end
    if type(img.setImageSource) == "function" and pcall(function() img:setImageSource("noxbot_logo_top.png") end) then
      pcall(function() img:show() end)
      return true
    end
  end
  return false
end

function noxApplyMainTabLogo(panel, charCfg)
  if not panel then return false end
  local img = panel.img
  if not img and panel.recursiveGetChildById then
    pcall(function() img = panel:recursiveGetChildById("img") end)
  end
  if not img then return false end
  return noxApplyLogoImage(img, charCfg)
end

local function noxTitleBarParent()
  if not botWindow then return nil end
  for _, id in ipairs({"miniwindowTopBar", "topBar", "titleBar"}) do
    local w = nil
    pcall(function()
      if botWindow.recursiveGetChildById then
        w = botWindow:recursiveGetChildById(id)
      end
      if not w and botWindow.getChildById then
        w = botWindow:getChildById(id)
      end
    end)
    if w then return w end
  end
  return botWindow
end

local function noxPaintTitleImage(img)
  if not img then return false end
  local charCfg = _G.__noxbot_char_cfg or ""
  return noxApplyLogoImage(img, charCfg)
end

function noxMountTitleHeader(version)
  if not botWindow then return false end
  version = tostring(version or "1.0.12")

  pcall(function() botWindow:setText("NoxBot v" .. version) end)
  pcall(function() botWindow:setColor("#FF3333") end)
  for _, f in ipairs({"verdana-11px-rounded", "verdana-11px-antialised", "verdana-11px-antialiased"}) do
    local ok = false
    pcall(function() botWindow:setFont(f); ok = true end)
    if ok then break end
  end
  pcall(function()
    if botWindow.setTextOffset then botWindow:setTextOffset("24 5") end
    if botWindow.setTextAlign and AlignTopLeft then botWindow:setTextAlign(AlignTopLeft) end
  end)

  local parent = noxTitleBarParent()
  if not parent then return false end

  local header = botWindow.noxTitleHeader
  if header and header.isDestroyed and header:isDestroyed() then
    header = nil
    botWindow.noxTitleHeader = nil
  end
  if not header and parent.getChildById then
    header = parent:getChildById("noxTitleHeader")
  end

  if not header then
    header = g_ui.createWidget("NoxTitleHeader", parent)
    if not header then
      header = g_ui.createWidget("Panel", parent)
      if header then
        pcall(function() header:setSize({ width = 16, height = 16 }) end)
        local img = g_ui.createWidget("UIWidget", header)
        if img then
          img:setId("noxTitleIconImg")
          pcall(function() img:addAnchor(AnchorFill, "parent", AnchorFill) end)
        end
      end
    end
    if not header then return false end
    header:setId("noxTitleHeader")
    botWindow.noxTitleHeader = header
  end

  pcall(function()
    if header.breakAnchors then header:breakAnchors() end
    header:addAnchor(AnchorVerticalCenter, "parent", AnchorVerticalCenter)
    header:addAnchor(AnchorLeft, "parent", AnchorLeft)
    header:setMarginLeft(4)
    header:setSize({ width = 16, height = 16 })
  end)

  local img = header.noxTitleIconImg
  if not img and header.getChildById then
    img = header:getChildById("noxTitleIconImg")
  end
  if img then
    noxPaintTitleImage(img)
    pcall(function() img:show() end)
  end

  pcall(function() header:show() end)
  pcall(function() header:raise() end)
  return true
end

local NOX_SETUP_BTN_IDS = {
  setup = true, settings = true, alerts = true, push = true, edit = true, combos = true,
  editList = true, editContList = true, conditionList = true, dropSqmSetup = true,
}

local function noxApplySetupButton(btn)
  if not btn or not btn.setText then return end
  pcall(function() btn:setText("Setup") end)
  pcall(function() btn:setFont("verdana-11px-rounded") end)
end

local function noxSetupTextBroken(txt)
  txt = tostring(txt or ""):lower()
  if txt == "setup" then return false end
  if txt == "$setup" or txt == "$etup" or txt == "etup" then return true end
  return txt:match("^%$?etup$") ~= nil
end

function noxFixAllSetupButtons()
  local function fixWidget(w, depth)
    if not w or depth > 40 then return end
    if w.isDestroyed and w:isDestroyed() then return end
    local id = ""
    pcall(function() id = w:getId() or "" end)
    local txt = ""
    pcall(function() txt = w:getText() or "" end)
    if NOX_SETUP_BTN_IDS[id] or noxSetupTextBroken(txt) then
      noxApplySetupButton(w)
    end
    local children = {}
    pcall(function() children = w:getChildren() end)
    for _, c in pairs(children or {}) do
      fixWidget(c, depth + 1)
    end
  end
  pcall(function()
    if contentsPanel then fixWidget(contentsPanel, 0) end
    if botWindow then fixWidget(botWindow, 0) end
  end)
end

function init()
  -- Nostalrius: UISpinBox.enc llama setMin/Max sobre un metodo nil al crear SpinBox
  pcall(function()
    local cls = UISpinBox
    if cls == nil or cls.__noxSpinPatched then return end
    cls.__noxSpinPatched = true
    local function install(name, field)
      local orig = cls[name]
      cls[name] = function(self, v)
        v = tonumber(v)
        if not self or not v then return end
        if type(orig) == 'function' then
          pcall(orig, self, v)
        end
        pcall(function() self[field] = v end)
      end
    end
    install('setMaximum', 'maximum')
    install('setMinimum', 'minimum')
  end)

  dofile("executor")

  pcall(function()
    modules.nox_bot = modules.nox_bot or {}
    if type(connect) == "function" then modules.nox_bot.connect = connect end
    if type(disconnect) == "function" then modules.nox_bot.disconnect = disconnect end
    modules.nox_bot.noxLogoBytes = noxLogoBytes
    modules.nox_bot.noxPaintLogoWidget = noxPaintTitleImage
  end)

  local function noxImportOtui(path)
    path = tostring(path or ""):gsub("\\", "/")
    if path == "" then return end
    if not g_resources or not g_resources.fileExists or not g_resources.fileExists(path) then return end
    local ok = pcall(function() g_ui.importStyle(path) end)
    if not ok and g_ui.importStyleFromString then
      pcall(function()
        local code = g_resources.readFileContents(path)
        if type(code) == "string" and code ~= "" then
          g_ui.importStyleFromString(code)
        end
      end)
    end
  end

  local packUi = {
    "/noxbot/pack/nox_bot/ui/basic.otui",
    "/noxbot/pack/nox_bot/ui/panels.otui",
    "/noxbot/pack/nox_bot/ui/config.otui",
    "/noxbot/pack/nox_bot/ui/icons.otui",
    "/noxbot/pack/nox_bot/ui/container.otui",
  }
  for _, p in ipairs(packUi) do
    pcall(function() noxImportOtui(p) end)
  end
  pcall(function() g_ui.importStyle("ui/basic.otui") end)
  pcall(function() g_ui.importStyle("ui/panels.otui") end)
  pcall(function() g_ui.importStyle("ui/config.otui") end)
  pcall(function() g_ui.importStyle("ui/icons.otui") end)
  pcall(function() g_ui.importStyle("ui/container.otui") end)
  
  connect(g_game, { 
    onGameStart = online, 
    onGameEnd = offline, 
  })
  
  initCallbacks()  
  
  botButton = { _on = false }
  botButton.setOn = function(self, v) self._on = not not v end
  botButton.isOn = function(self) return self._on end
  botButton.show = function(self) end
  botButton.hide = function(self) end
  botButton.destroy = function(self) end
  botButton:setOn(false)
  botButton:hide()

  pcall(function()
    if g_resources and g_resources.addSearchPath then
      g_resources.addSearchPath("/noxbot/pack/nox_bot", true)
    end
  end)

  botWindow = g_ui.loadUI('bot', modules.game_interface.getLeftPanel())
  botWindow:setup()
  pcall(function() botWindow:show() end)
  -- El Setup de HP quedaba fuera del recuadro negro: ensanchar el MiniWindow.
  pcall(function()
    if botWindow.setWidth then botWindow:setWidth(198) end
    if botWindow.setContentMinimumWidth then botWindow:setContentMinimumWidth(186) end
  end)
  -- Titulo mas grande + icono N a la izquierda
  pcall(function()
    local function noxLoadVersionHelper()
      if type(noxCanonicalVersion) == "function" then return end
      if not g_resources or not g_resources.readFileContents then return end
      local paths = {
        "/noxbot/_template/vBot/nox_version.lua",
        "/noxbot/pack/vBot/nox_version.lua",
      }
      for _, p in ipairs(paths) do
        local ok, chunk = pcall(g_resources.readFileContents, p)
        if ok and type(chunk) == "string" and #chunk > 20 then
          pcall(function() load(chunk, p)() end)
          break
        end
      end
    end
    local function noxReadVersion()
      noxLoadVersionHelper()
      if type(noxCanonicalVersion) == "function" then
        return noxCanonicalVersion()
      end
      local function take(raw)
        if type(raw) ~= "string" then return nil end
        if #raw > 64 then return nil end
        if raw:find("\0", 1, true) then return nil end
        return raw:match("^%s*(%d+%.%d+[%d%.]*)")
      end
      local ver = nil
      pcall(function()
        local d = tostring(DATA or "")
        if d ~= "" and io and io.open then
          local f = io.open(d .. "/version.txt", "r")
          if f then ver = take(f:read("*a")); f:close() end
        end
      end)
      if ver then return ver end
      ver = take(_G.__nox_ver)
      if ver then return ver end
      pcall(function()
        local t = _G.__nox_txt
        if type(t) == "table" then
          ver = take(t["version.txt"]) or take(t["modules/nox_bot/version.txt"])
        end
      end)
      if ver then return ver end
      return take(_G.__nox_ver) or "3.0.34"
    end
    local function refreshTitle()
      local v = noxReadVersion()
      noxMountTitleHeader(v)
      return v
    end
    local ver = refreshTitle()
    pcall(function()
      if g_resources and g_resources.addSearchPath then
        g_resources.addSearchPath("/noxbot/pack/nox_bot", true)
      end
    end)
    if type(scheduleEvent) == "function" then
      scheduleEvent(function() refreshTitle() end, 50)
      scheduleEvent(function() refreshTitle() end, 250)
      scheduleEvent(function() refreshTitle() end, 1000)
      scheduleEvent(function() refreshTitle() end, 3000)
    end
    pcall(function()
      if botWindow.setDraggable then botWindow:setDraggable(true) end
      if botWindow.setMovable then botWindow:setMovable(true) end
    end)
  end)
  pcall(function()
    local bar = modules.client_topmenu.getTopMenu()
    if not bar then return end
    local old = bar:recursiveGetChildById("noxBotLabel")
    if old then old:destroy() end
    local lab = g_ui.createWidget("Label", bar)
    lab:setId("noxBotLabel")
    local ver = "3.0.34"
    pcall(function()
      if type(noxCanonicalVersion) == "function" then
        ver = noxCanonicalVersion()
      else
        local function readVer()
          local function take(raw)
            if type(raw) ~= "string" or #raw > 64 or raw:find("\0", 1, true) then return nil end
            return raw:match("^%s*(%d+%.%d+[%d%.]*)")
          end
          local out = nil
          pcall(function()
            local d = tostring(DATA or "")
            if d ~= "" and io and io.open then
              local f = io.open(d .. "/version.txt", "r")
              if f then out = take(f:read("*a")); f:close() end
            end
          end)
          if out then return out end
          out = take(_G.__nox_ver)
          if out then return out end
          pcall(function()
            local t = _G.__nox_txt
            if type(t) == "table" then
              out = take(t["version.txt"]) or take(t["modules/nox_bot/version.txt"])
            end
          end)
          return out or take(_G.__nox_ver) or "3.0.16"
        end
        ver = readVer()
      end
    end)
    lab:setText("NoxBot v" .. ver)
    lab:setColor('#FF2222')
    pcall(function() lab:setFont('verdana-11px-rounded') end)
    lab:setTextAlign(AlignCenter)
    pcall(function() lab:resizeToText() end)
    lab:setHeight(18)
    if lab:getWidth() < 72 then lab:setWidth(72) end
    lab:addAnchor(AnchorHorizontalCenter, 'parent', AnchorHorizontalCenter)
    lab:addAnchor(AnchorVerticalCenter, 'parent', AnchorVerticalCenter)
    lab.onMouseRelease = function(w, pos, button)
      if button == MouseLeftButton then toggle() return true end
    end
  end)

  contentsPanel = botWindow.contentsPanel
  configList = contentsPanel.config
  enableButton = contentsPanel.enableButton
  statusLabel = contentsPanel.statusLabel
  botMessages = contentsPanel.messages 
  botTabs = contentsPanel.botTabs
  botTabs:setContentWidget(contentsPanel.botPanel)  
  
  editWindow = g_ui.displayUI('edit')
  editWindow:hide()
    
  if g_game.isOnline() then
    clear()
    online()
  end
  -- ImGui muerto: no arrancar el ping hud_ping.json / dump de mapa.
end

function terminate()
  pcall(function()
    if __noxHudTick then removeEvent(__noxHudTick) __noxHudTick = nil end
  end)
  save()
  clear()

  disconnect(g_game, { 
    onGameStart = online, 
    onGameEnd = offline, 
  })
  
  terminateCallbacks()
  editWindow:destroy()

  botWindow:destroy()
  botButton:destroy()   
end

function clear()
  botExecutor = nil
  removeEvent(checkEvent)

  -- Permite recargar vBot completo en cada Off/On (si no, loader.lua hace return y pierdes configs)
  _G.__NOXBOT_LOADER_DONE = false
  _G.__noxbot_loaded_scripts = {}
  -- Invalida cadenas scheduleEvent del loader anterior (si no, el % vuelve al 6%).
  -- En modules.nox_bot: el sandbox ve modules, pero NO rawget ni el _G real.
  pcall(function()
    if modules and modules.nox_bot then
      modules.nox_bot.__noxLoadId = (tonumber(modules.nox_bot.__noxLoadId) or 0) + 1
    end
  end)

  -- optimization, callback is not used when not needed
  g_game.enableTileThingLuaCallback(false)

  botTabs:clearTabs()  
  botTabs:setOn(false)
  
  botMessages:destroyChildren()
  botMessages:updateLayout()
  
  for i, socket in pairs(botWebSockets) do
    g_http.cancel(socket)
    botWebSockets[i] = nil
  end

  pcall(function()
    for i, widget in pairs(g_ui.getRootWidget():getChildren()) do
      if widget.botWidget then
        widget:destroy()
      end
    end
  end)
  pcall(function()
    for i, widget in pairs(modules.game_interface.gameMapPanel:getChildren()) do
      if widget.botWidget then
        widget:destroy()
      end
    end
  end)
  pcall(function()
    for _, widget in pairs({modules.game_interface.getRightPanel(), modules.game_interface.getLeftPanel()}) do
      for i, child in pairs(widget:getChildren()) do
        if child.botWidget then
          child:destroy()
        end
      end
    end
  end)
  
  local gameMapPanel = modules.game_interface.getMapPanel()
  if gameMapPanel then
    gameMapPanel:unlockVisibleFloor()   
  end
  
  if g_sounds then
    g_sounds.getChannel(SoundChannels.Bot):stop()
  end  
end


local __noxRefreshing = false

local function sanitizeChar(n)
  return tostring(n or ""):gsub("%s+", "_")
end

local function charStatePath(charCfg)
  return "/noxbot/" .. charCfg .. "/storage/noxbot_ui.json"
end

local function loadCharState(charCfg)
  local path = charStatePath(charCfg)
  if not g_resources.fileExists(path) then return nil end
  local ok, data = pcall(function()
    return json.decode(g_resources.readFileContents(path))
  end)
  if ok and type(data) == "table" then return data end
  return nil
end

local function saveCharState(charCfg, enabled, configName)
  local dir = "/noxbot/" .. charCfg .. "/storage"
  pcall(function()
    local acc = ""
    for part in dir:gmatch("[^/]+") do
      acc = acc .. "/" .. part
      pcall(function() g_resources.makeDir(acc) end)
    end
  end)
  local path = charStatePath(charCfg)
  local payload = json.encode({ enabled = not not enabled, config = configName or charCfg }, 2)
  pcall(function() g_resources.writeFileContents(path, payload) end)
end

local function noxVirtMkdir(path)
  local acc = ""
  for part in tostring(path or ""):gmatch("[^/]+") do
    acc = acc .. "/" .. part
    pcall(function() if g_resources.makeDir then g_resources.makeDir(acc) end end)
  end
end

local function noxCopyFromTemplate(src, dst)
  if not g_resources.fileExists or not g_resources.fileExists(src) then return false end
  local ok, data = pcall(function() return g_resources.readFileContents(src) end)
  if not ok or type(data) ~= "string" or data == "" then return false end
  local parent = tostring(dst):match("^(.*)/[^/]+$")
  if parent then noxVirtMkdir(parent) end
  pcall(function() g_resources.writeFileContents(dst, data) end)
  return true
end

local function noxProfileHasScripts(dir)
  if g_resources.directoryExists(dir .. "/vBot") then return true end
  if g_resources.directoryExists(dir .. "/cavebot") then return true end
  if g_resources.fileExists(dir .. "/loader.lua") then return true end
  return false
end

local function noxSyncScriptDirFromTemplate(srcDir, dstDir, subdir, onlyMissing)
  if not g_resources.directoryExists(srcDir) then return end
  noxVirtMkdir(dstDir)
  local files = {}
  pcall(function() files = g_resources.listDirectoryFiles(srcDir, true, false) or {} end)
  for _, file in ipairs(files) do
    local path = tostring(file):gsub("\\", "/")
    if g_resources.fileExists(path) then
      local name = path:match("([^/]+)$") or ""
      local ext = name:match("%.([%w]+)$")
      if ext then
        local el = ext:lower()
        if el == "lua" or el == "otui" or el == "png" then
          local rel = path:match("/" .. subdir .. "/(.+)$") or name
          local dst = dstDir .. "/" .. rel
          if onlyMissing and g_resources.fileExists(dst) then
          else
            noxCopyFromTemplate(path, dst)
          end
        end
      end
    end
  end
end

local function noxSyncCommunityFromTemplate(charCfg)
  if charCfg == "" or charCfg == "_template" then return end
  local src = "/noxbot/_template/vBot/community"
  local dst = "/noxbot/" .. charCfg .. "/vBot/community"
  if not g_resources.directoryExists(src) then return end
  noxVirtMkdir(dst)
  local files = {}
  pcall(function() files = g_resources.listDirectoryFiles(src, false, false) or {} end)
  for _, file in ipairs(files) do
    local name = tostring(file):match("([^/\\]+)$") or tostring(file)
    if name:match("%.(%w+)$") then
      noxCopyFromTemplate(src .. "/" .. name, dst .. "/" .. name)
    end
  end
end

local noxUiPanelLua = {
  "main.lua", "nox_version.lua", "nox_community.lua", "noxbot_scripts.lua", "panel_widgets.lua",
  "HealBot.lua", "alarms.lua", "Conditions.lua", "Equipper.lua",
  "eat_food.lua", "manatrain.lua", "combo.lua", "Dropper.lua", "Containers.lua",
  "new_healer.lua", "AttackBot.lua", "pushmax.lua", "Sio.lua", "Simulator.lua",
  "makers.lua", "player_training.lua", "auto_trap.lua",
  "cavebot_control_panel.lua", "hud.lua", "nox_logo_b64.lua", "nox_mini_b64.lua",
  "noxbot_logo_top.png", "noxbot_mini.png", "noxbot_icon.png",
}

local noxUiPanelOtui = {
  "AttackBot.otui",
}

local function noxSyncUiPanelsFromTemplate(charCfg)
  if charCfg == "" or charCfg == "_template" then return end
  local srcBase = "/noxbot/_template/vBot"
  local dstBase = "/noxbot/" .. charCfg .. "/vBot"
  for _, name in ipairs(noxUiPanelLua) do
    noxCopyFromTemplate(srcBase .. "/" .. name, dstBase .. "/" .. name)
  end
  for _, name in ipairs(noxUiPanelOtui) do
    noxCopyFromTemplate(srcBase .. "/" .. name, dstBase .. "/" .. name)
  end
end

local function noxStripTestBotConfigs(dir)
  pcall(function() g_resources.deleteFile(dir .. "/cavebot_configs/test.cfg") end)
  pcall(function() g_resources.deleteFile(dir .. "/targetbot_configs/test.json") end)
  local storageDir = dir .. "/storage"
  if not g_resources.directoryExists(storageDir) then return end
  local files = {}
  pcall(function() files = g_resources.listDirectoryFiles(storageDir, false, false) or {} end)
  for _, file in ipairs(files) do
    local name = tostring(file):match("([^/\\]+)$") or tostring(file)
    if name:match("%.json$") then
      local path = storageDir .. "/" .. name
      local ok, raw = pcall(function() return g_resources.readFileContents(path) end)
      if ok and type(raw) == "string" and raw:find("test", 1, true) then
        raw = raw:gsub('"selected"%s*:%s*"test"', '"selected": ""')
        raw = raw:gsub('"selected"%s*:%s*\'test\'', '"selected": ""')
        pcall(function() g_resources.writeFileContents(path, raw) end)
      end
    end
  end
end

local function noxEnsureCharProfile(charCfg)
  if charCfg == "" or charCfg == "_template" then return end
  local src = "/noxbot/_template"
  local dst = "/noxbot/" .. charCfg
  if not g_resources.directoryExists(src) then return end
  noxVirtMkdir(dst)
  noxVirtMkdir(dst .. "/storage")
  noxVirtMkdir(dst .. "/cavebot_configs")
  noxVirtMkdir(dst .. "/targetbot_configs")
  noxVirtMkdir(dst .. "/vBot_configs")
  for i = 0, 10 do
    noxVirtMkdir(dst .. "/vBot_configs/profile_" .. i)
  end
  local isNew = not noxProfileHasScripts(dst)
  local onlyMissing = not isNew
  for _, sub in ipairs({ "cavebot", "targetbot", "vBot" }) do
    noxSyncScriptDirFromTemplate(src .. "/" .. sub, dst .. "/" .. sub, sub, onlyMissing)
  end
  if isNew then
    local rootFiles = {}
    pcall(function() rootFiles = g_resources.listDirectoryFiles(src, false, false) or {} end)
    for _, file in ipairs(rootFiles) do
      local name = tostring(file):match("([^/\\]+)$") or tostring(file)
      if name == "loader.lua" or name == "_Loader.lua" or name == "noxbot_ok.lua" then
      elseif name:match("%.lua$") or name:match("%.otui$") then
        noxCopyFromTemplate(src .. "/" .. name, dst .. "/" .. name)
      end
    end
    pcall(function()
      local storageFiles = g_resources.listDirectoryFiles(src .. "/storage", false, false) or {}
      for _, file in ipairs(storageFiles) do
        local name = tostring(file):match("([^/\\]+)$") or tostring(file)
        if name ~= "" then
          noxCopyFromTemplate(src .. "/storage/" .. name, dst .. "/storage/" .. name)
        end
      end
    end)
  end
  noxCopyFromTemplate(src .. "/loader.lua", dst .. "/loader.lua")
  noxSyncCommunityFromTemplate(charCfg)
  pcall(function() g_resources.deleteFile(dst .. "/_Loader.lua") end)
  pcall(function() noxDeployLogoAssets(charCfg) end)
  noxSyncUiPanelsFromTemplate(charCfg)
  noxStripTestBotConfigs(dst)
end

local __noxSaving = false

-- Rutas fisicas: solo NoxBot-Dev/noxbot_data y perfil Nostalrius
local function noxPhysRoots()
  local roots = {}
  local function add(p)
    p = tostring(p or ""):gsub("\\", "/"):gsub("/+$", "")
    if p == "" then return end
    for _, e in ipairs(roots) do if e == p then return end end
    roots[#roots + 1] = p
  end
  if type(DATA) == "string" then add(DATA) end
  pcall(function()
    if g_resources.getWriteDir then add(g_resources.getWriteDir()) end
  end)
  pcall(function()
    local home = os.getenv and (os.getenv("USERPROFILE") or os.getenv("HOME"))
    if home and home ~= "" then
      add(home .. "/Desktop/Proyecto Nox/NoxBot-Dev/noxbot_data")
      add(home .. "/AppData/Roaming/Nostalrius/Nostalrius_Profiles")
    end
  end)
  return roots
end

local function noxWriteFile(virtPath, contents)
  virtPath = tostring(virtPath or ""):gsub("\\", "/")
  if virtPath:sub(1, 1) ~= "/" then virtPath = "/" .. virtPath end
  local parentVirt = virtPath:match("(.+)/[^/]+$")
  if parentVirt then noxVirtMkdir(parentVirt) end
  local ok, err = pcall(function()
    g_resources.writeFileContents(virtPath, contents)
  end)
  -- NUNCA os.execute/mkdir: en Windows abre una CMD por cada tick y peta el cliente.
  local wrote = false
  for _, root in ipairs(noxPhysRoots()) do
    local phys = root .. virtPath
    local f = io and io.open and io.open(phys, "wb")
    if f then
      f:write(contents)
      f:close()
      wrote = true
    end
  end
  return ok or wrote, err
end

local function noxPersistLogoFiles(charCfg)
  charCfg = tostring(charCfg or "")
  if charCfg == "" or charCfg == "_template" then return end
  for _, name in ipairs({ "noxbot_logo_top.png", "noxbot_mini.png", "noxbot_icon.png" }) do
    local path = "/noxbot/" .. charCfg .. "/vBot/" .. name
    local ok, data = pcall(g_resources.readFileContents, path)
    if ok and type(data) == "string" and #data > 100 then
      noxWriteFile(path, data)
    end
  end
end

local function noxReadFile(virtPath)
  virtPath = tostring(virtPath or ""):gsub("\\", "/")
  if virtPath:sub(1, 1) ~= "/" then virtPath = "/" .. virtPath end
  local best, bestLen = nil, 0
  for _, root in ipairs(noxPhysRoots()) do
    local phys = root .. virtPath
    local f = io and io.open and io.open(phys, "rb")
    if f then
      local data = f:read("*a")
      f:close()
      if type(data) == "string" and #data > bestLen then
        best, bestLen = data, #data
      end
    end
  end
  if best then return best end
  local ok, data = pcall(function()
    if g_resources.fileExists(virtPath) then
      return g_resources.readFileContents(virtPath)
    end
  end)
  if ok and type(data) == "string" and data ~= "" then return data end
  return nil
end

local function noxEncode(tbl)
  local function copy(v, seen)
    seen = seen or {}
    local t = type(v)
    if t == "boolean" or t == "number" or t == "string" then return v end
    if t ~= "table" then return nil end
    if seen[v] then return seen[v] end
    local out = {}
    seen[v] = out
    local n = 0
    for k, val in pairs(v) do
      local key
      if type(k) == "string" then
        key = k
      elseif type(k) == "number" then
        key = tostring(k)
        if k > n then n = k end
      end
      if key then
        local cv = copy(val, seen)
        if cv ~= nil then out[key] = cv end
      end
    end
    -- OTC json.encode pierde arrays [1],[2]. Claves "1","2" + _n si sobreviven.
    if n > 0 and out._n == nil then out._n = n end
    return out
  end
  local data = copy(tbl or {}) or {}
  local ok, payload = pcall(function()
    return json.encode(data, 2)
  end)
  if not (ok and type(payload) == "string") then
    ok, payload = pcall(function()
      return json.encode(data)
    end)
  end
  if ok and type(payload) == "string" then return payload end
  -- Si el Setup anidado rompe el encode, guarda flags + healSetupJson (string)
  local fallback = {}
  for k, v in pairs(tbl or {}) do
    if type(k) == "string" then
      local vt = type(v)
      if vt == "boolean" or vt == "number" or vt == "string" then
        fallback[k] = v
      elseif k == "_macros" and vt == "table" then
        fallback[k] = v
      end
    end
  end
  ok, payload = pcall(function() return json.encode(fallback, 2) end)
  if not (ok and type(payload) == "string") then
    ok, payload = pcall(function() return json.encode(fallback) end)
  end
  if ok and type(payload) == "string" then return payload end
  return "{}"
end

local function noxHpOn(v)
  return v == true or v == 1 or v == "1" or v == "on" or v == "true"
end

local function noxHpOff(v)
  return v == false or v == 0 or v == "0" or v == "off" or v == "false"
end

local function noxSettingsHpIndex()
  local name, ver = "", ""
  pcall(function() name = tostring(g_game.getCharacterName() or "") end)
  pcall(function() ver = tostring(g_game.getClientVersion() or "") end)
  if name == "" then return nil end
  return name .. "_" .. ver
end

local function noxHpNodeKeys()
  local raw = ""
  pcall(function() raw = tostring(g_game.getCharacterName() or "") end)
  local san = sanitizeChar(raw)
  local ver = ""
  pcall(function() ver = tostring(g_game.getClientVersion() or "") end)
  return { san, raw, (raw ~= "" and ver ~= "") and (raw .. "_" .. ver) or "" }
end

local function noxLoadHpNode()
  if not g_settings or not g_settings.getNode then return {} end
  local node = g_settings.getNode("noxbot_hp") or {}
  for _, k in ipairs(noxHpNodeKeys()) do
    if k ~= "" and type(node[k]) == "table" then return node[k] end
  end
  return {}
end

local function noxSaveHpNode(patch)
  if type(patch) ~= "table" or not g_settings or not g_settings.setNode then return end
  local node = g_settings.getNode("noxbot_hp") or {}
  local keys = noxHpNodeKeys()
  local primary = keys[1]
  if primary == "" then return end
  node[primary] = type(node[primary]) == "table" and node[primary] or {}
  for k, v in pairs(patch) do
    node[primary][k] = v and 1 or 0
  end
  for i = 2, #keys do
    if keys[i] ~= "" and keys[i] ~= primary then
      node[keys[i]] = node[primary]
    end
  end
  g_settings.setNode("noxbot_hp", node)
  if g_settings.save then g_settings.save() end
  pcall(function()
    local bits = node[primary]
    local text = string.format("heal=%s\ncond=%s\neq=%s\nfood=%s\n",
      bits.heal == 1 and "1" or "0",
      bits.cond == 1 and "1" or "0",
      bits.eq == 1 and "1" or "0",
      bits.food == 1 and "1" or "0")
    noxWriteFile("/noxbot/" .. primary .. "/storage/hp_onoff.txt", text)
  end)
end

local function noxFindWidget(id)
  local function look(root)
    if not root then return nil end
    local w = nil
    pcall(function()
      if root.recursiveGetChildById then w = root:recursiveGetChildById(id) end
    end)
    if w then return w end
    pcall(function()
      if root.getId and root:getId() == id then w = root end
    end)
    return w
  end
  return look(botWindow) or look(contentsPanel) or look(g_ui.getRootWidget())
end

local function noxHpSwitchOf(panelId, childId)
  local panel = noxFindWidget(panelId)
  if not panel then return nil end
  local child = nil
  pcall(function()
    if panel.recursiveGetChildById then child = panel:recursiveGetChildById(childId) end
  end)
  if child then return child end
  pcall(function() child = panel[childId] end)
  return child
end

local function noxHookHpSwitch(widget, key)
  if not widget or widget.__noxHpHooked then return end
  widget.__noxHpHooked = true
  local prevClick = widget.onClick
  local prevRel = widget.onMouseRelease
  local function persistSoon()
    scheduleEvent(function()
      local on = false
      pcall(function() on = widget:isOn() end)
      noxSaveHpNode({ [key] = on })
      if type(botStorage) == "table" then
        local name = (key == "heal" and "hpHeal") or (key == "cond" and "hpCond")
          or (key == "eq" and "hpEq") or "hpFood"
        botStorage[name] = on and "on" or "off"
        if key == "heal" then botStorage.healBotEnabled = on end
        if key == "cond" then botStorage.conditionsEnabled = on end
        if key == "eq" then
          botStorage.EquipperPanel = type(botStorage.EquipperPanel) == "table" and botStorage.EquipperPanel or {}
          botStorage.EquipperPanel.enabled = on
        end
        if key == "food" then
          botStorage.eatFood = type(botStorage.eatFood) == "table" and botStorage.eatFood or {}
          botStorage.eatFood.enabled = on
        end
      end
    end, 20)
  end
  widget.onClick = function(w, ...)
    if type(prevClick) == "function" then pcall(prevClick, w, ...) end
    persistSoon()
  end
  widget.onMouseRelease = function(w, pos, button)
    local r
    if type(prevRel) == "function" then
      local ok, v = pcall(prevRel, w, pos, button)
      if ok then r = v end
    end
    persistSoon()
    return r
  end
end

local function noxRestoreHpButtons()
  local bits = noxLoadHpNode()
  local flags = {
    heal = noxHpOn(bits.heal) or noxHpOn(bits.hpHeal),
    cond = noxHpOn(bits.cond) or noxHpOn(bits.hpCond),
    eq = noxHpOn(bits.eq) or noxHpOn(bits.hpEq),
    food = noxHpOn(bits.food) or noxHpOn(bits.hpFood),
  }
  -- nil if never saved
  if bits.heal == nil and bits.hpHeal == nil then flags.heal = nil end
  if bits.cond == nil and bits.hpCond == nil then flags.cond = nil end
  if bits.eq == nil and bits.hpEq == nil then flags.eq = nil end
  if bits.food == nil and bits.hpFood == nil then flags.food = nil end
  if flags.heal == nil and flags.cond == nil and flags.eq == nil and flags.food == nil then
    return
  end
  local ctx = botExecutor and botExecutor.context
  if ctx then
    if flags.heal ~= nil and ctx.HealBot and type(ctx.HealBot.restore) == "function" then
      pcall(ctx.HealBot.restore, flags.heal)
    end
    if ctx.vBot then
      if flags.cond ~= nil then
        if type(ctx.vBot.restoreConditionsUi) == "function" then
          pcall(ctx.vBot.restoreConditionsUi, flags.cond)
        elseif type(ctx.vBot.syncConditionsUi) == "function" then
          pcall(ctx.vBot.syncConditionsUi, flags.cond)
        end
      end
      if flags.eq ~= nil and type(ctx.vBot.syncEquipperUi) == "function" then
        pcall(ctx.vBot.syncEquipperUi, flags.eq)
      end
      if flags.food ~= nil and type(ctx.vBot.syncEatFoodUi) == "function" then
        pcall(ctx.vBot.syncEatFoodUi, flags.food)
      end
    end
  end
  local map = {
    { "healbot", "title", flags.heal },
    { "ConditionPanel", "title", flags.cond },
    { "EquipperPanel", "switch", flags.eq },
    { "eatFood", "title", flags.food },
  }
  for _, row in ipairs(map) do
    if row[3] ~= nil then
      local w = noxHpSwitchOf(row[1], row[2])
      if w then pcall(function() w:setOn(row[3]) end) end
    end
  end
end

local function noxHookHpButtons()
  noxHookHpSwitch(noxHpSwitchOf("healbot", "title"), "heal")
  noxHookHpSwitch(noxHpSwitchOf("ConditionPanel", "title"), "cond")
  noxHookHpSwitch(noxHpSwitchOf("EquipperPanel", "switch"), "eq")
  noxHookHpSwitch(noxHpSwitchOf("eatFood", "title"), "food")
  noxRestoreHpButtons()
end

-- Mismo sitio que el On/Off del motor: g_settings node 'noxbot_hp' (NO 'noxbot':
-- refresh() reescribe ese nodo y borraba las 4 teclas).
local function noxMergeSettingsHp(st)
  if type(st) ~= "table" then return end
  local s = noxLoadHpNode()
  if type(s) ~= "table" then return end
  if noxHpOn(s.heal) or noxHpOn(s.hpHeal) or noxHpOff(s.heal) or noxHpOff(s.hpHeal) then
    st.healBotEnabled = noxHpOn(s.heal) or noxHpOn(s.hpHeal)
    st.hpHeal = st.healBotEnabled and "on" or "off"
  end
  if noxHpOn(s.cond) or noxHpOn(s.hpCond) or noxHpOff(s.cond) or noxHpOff(s.hpCond) then
    st.conditionsEnabled = noxHpOn(s.cond) or noxHpOn(s.hpCond)
    st.hpCond = st.conditionsEnabled and "on" or "off"
  end
  if noxHpOn(s.eq) or noxHpOn(s.hpEq) or noxHpOff(s.eq) or noxHpOff(s.hpEq) then
    st.EquipperPanel = type(st.EquipperPanel) == "table" and st.EquipperPanel or {}
    st.EquipperPanel.enabled = noxHpOn(s.eq) or noxHpOn(s.hpEq)
    st.hpEq = st.EquipperPanel.enabled and "on" or "off"
  end
  if noxHpOn(s.food) or noxHpOn(s.hpFood) or noxHpOff(s.food) or noxHpOff(s.hpFood) then
    st.eatFood = type(st.eatFood) == "table" and st.eatFood or {}
    st.eatFood.enabled = noxHpOn(s.food) or noxHpOn(s.hpFood)
    st.hpFood = st.eatFood.enabled and "on" or "off"
  end
end

local function noxWriteSettingsHp(st)
  if type(st) ~= "table" then return end
  local patch = {}
  if st.hpHeal == "on" or noxHpOn(st.healBotEnabled) then patch.heal = true
  elseif st.hpHeal == "off" then patch.heal = false
  end
  if st.hpCond == "on" or noxHpOn(st.conditionsEnabled) then patch.cond = true
  elseif st.hpCond == "off" then patch.cond = false
  end
  if st.hpEq == "on" or (type(st.EquipperPanel) == "table" and noxHpOn(st.EquipperPanel.enabled)) then
    patch.eq = true
  elseif st.hpEq == "off" then patch.eq = false
  end
  if st.hpFood == "on" or (type(st.eatFood) == "table" and noxHpOn(st.eatFood.enabled)) then
    patch.food = true
  elseif st.hpFood == "off" then patch.food = false
  end
  if next(patch) then noxSaveHpNode(patch) end
end

local function noxWriteOnOffTxt(st, dir)
  st = st or {}
  local eat = type(st.eatFood) == "table" and st.eatFood or {}
  local eq = type(st.EquipperPanel) == "table" and st.EquipperPanel or {}
  local text = string.format("heal=%s\ncond=%s\neq=%s\nfood=%s\n",
    st.healBotEnabled and "1" or "0",
    st.conditionsEnabled and "1" or "0",
    eq.enabled and "1" or "0",
    eat.enabled and "1" or "0")
  noxWriteFile(dir .. "/hp_onoff.txt", text)
end

local function noxMergeOnOffTxt(st, dir)
  if type(st) ~= "table" then return end
  local raw = noxReadFile(dir .. "/hp_onoff.txt")
  if type(raw) ~= "string" or raw == "" then return end
  local function bit(key)
    local v = raw:match(key .. "%s*=%s*(%w+)")
    if v == "1" or v == "true" or v == "on" then return true end
    if v == "0" or v == "false" or v == "off" then return false end
    return nil
  end
  local h, c, e, f = bit("heal"), bit("cond"), bit("eq"), bit("food")
  if h ~= nil then st.healBotEnabled = h end
  if c ~= nil then st.conditionsEnabled = c end
  if e ~= nil then
    st.EquipperPanel = type(st.EquipperPanel) == "table" and st.EquipperPanel or {}
    st.EquipperPanel.enabled = e
  end
  if f ~= nil then
    st.eatFood = type(st.eatFood) == "table" and st.eatFood or {}
    st.eatFood.enabled = f
  end
end

local function noxWriteHpState(st, dir)
  st = st or {}
  pcall(function() noxWriteOnOffTxt(st, dir) end)
  local eat = type(st.eatFood) == "table" and st.eatFood or {}
  local eq = type(st.EquipperPanel) == "table" and st.EquipperPanel or {}
  local flags = string.format(
    '{"healBotEnabled":%s,"conditionsEnabled":%s,"eqEnabled":%s,"eatFoodEnabled":%s}',
    st.healBotEnabled and "true" or "false",
    st.conditionsEnabled and "true" or "false",
    eq.enabled and "true" or "false",
    eat.enabled and "true" or "false"
  )
  noxWriteFile(dir .. "/hp_flags.json", flags)
  local blob = {
    healBotEnabled = not not st.healBotEnabled,
    conditionsEnabled = not not st.conditionsEnabled,
    eatFoodEnabled = not not eat.enabled,
    eqEnabled = not not eq.enabled,
    eatFood = eat,
    EquipperPanel = eq,
    healSetupJson = type(st.healSetupJson) == "string" and st.healSetupJson or "",
  }
  noxWriteFile(dir .. "/hp_state.json", noxEncode(blob))
end

local function noxMergeHpState(st, dir)
  if type(st) ~= "table" then return end
  -- Solo el Setup (spells). NUNCA el On/Off: eso pisa storage como Manatrain.
  local raw = noxReadFile(dir .. "/hp_state.json")
  if type(raw) ~= "string" or #raw < 8 then return end
  local ok, src = pcall(function() return json.decode(raw) end)
  if ok and type(src) == "table" and type(src.healSetupJson) == "string" and #src.healSetupJson > 8 then
    st.healSetupJson = src.healSetupJson
  end
end

function refresh()
  if not g_game.isOnline() then return end
  if __noxRefreshing then return end
  __noxRefreshing = true
  local okRefresh, errRefresh = pcall(function()
  -- Solo guardar si hay algo real. Si no, refresh pisa current.json con []
  if type(botStorage) == "table" and next(botStorage) ~= nil then
    pcall(save)
  end
  clear()
  
  -- create bot dir
  if not g_resources.directoryExists("/noxbot") then
    g_resources.makeDir("/noxbot")
    if not g_resources.directoryExists("/noxbot") then
      return onError("Can't create bot directory in " .. g_resources.getWriteDir())
    end
  end
  
  -- get list of configs
  createDefaultConfigs()

  configList.onOptionChange = nil
  enableButton.onClick = nil
  configList:clearOptions()
  -- Perfil FIJO: solo el personaje logueado (como 1.0.80)
  local charCfg = sanitizeChar(g_game.getCharacterName())
  if charCfg == "" then charCfg = "_template" end
  local okProf, errProf = pcall(function() noxEnsureCharProfile(charCfg) end)
  if not okProf then
    return onError(tostring(errProf))
  end
  pcall(function() noxPersistLogoFiles(charCfg) end)
  _G.__noxbot_char_cfg = charCfg

  local charState = loadCharState(charCfg)

  configList:clearOptions()
  configList:addOption(charCfg)

  local settings = g_settings.getNode('noxbot') or {}
  local index = g_game.getCharacterName() .. "_" .. g_game.getClientVersion()
  if settings[index] == nil then
    settings[index] = { enabled=false, config="" }
  end

  settings[index].config = charCfg
  if type(settings[index].enabled) ~= "boolean" then
    if charState and type(charState.enabled) == "boolean" then
      settings[index].enabled = charState.enabled
    else
      settings[index].enabled = false
    end
  end

  configList:setCurrentOption(charCfg)
  enableButton:setOn(settings[index].enabled)

  configList.onOptionChange = function(widget)
    settings[index].config = charCfg
    g_settings.setNode('noxbot', settings)
    g_settings.save()
    refresh()
  end

  enableButton.onClick = function(widget)
    local turningOff = settings[index].enabled
    if turningOff then
      pcall(save)
    end
    local fresh = g_settings.getNode('noxbot') or {}
    if type(fresh[index]) == "table" then
      for k, v in pairs(fresh[index]) do
        if k ~= "enabled" and k ~= "config" then
          settings[index][k] = v
        end
      end
    end
    settings[index].enabled = not settings[index].enabled
    settings[index].config = charCfg
    saveCharState(charCfg, settings[index].enabled, charCfg)
    g_settings.setNode('noxbot', settings)
    g_settings.save()
    refresh()
  end

  if not g_game.isOnline() or not settings[index].enabled then
    statusLabel:setOn(true)
    statusLabel:setText("Status: disabled\nPress off button to enable")
    saveCharState(charCfg, false, charCfg)
    return
  end

  saveCharState(charCfg, true, charCfg)

  local configName = charCfg

  local function ensurePath(path)
    local acc = ""
    for part in tostring(path):gmatch("[^/]+") do
      acc = acc .. "/" .. part
      pcall(function() g_resources.makeDir(acc) end)
    end
  end

  ensurePath("/noxbot/" .. configName)
  ensurePath("/noxbot/" .. configName .. "/storage")
  ensurePath("/noxbot/" .. configName .. "/vBot_configs")
  ensurePath("/noxbot/" .. configName .. "/cavebot_configs")
  ensurePath("/noxbot/" .. configName .. "/targetbot_configs")
  for i = 0, 10 do
    ensurePath("/noxbot/" .. configName .. "/vBot_configs/profile_" .. i)
  end

  local prof = 1
  pcall(function() prof = tonumber(g_settings.getNumber("profile")) or 1 end)
  if not prof or prof < 0 then prof = 1 end
  local sdir = "/noxbot/" .. configName .. "/storage"
  botStorageFile = sdir .. "/profile_" .. prof .. ".json"

  botStorage = {}
  local raw = noxReadFile(sdir .. "/current.json")
    or noxReadFile(botStorageFile)
    or noxReadFile(sdir .. "/profile_1.json")
    or noxReadFile(sdir .. "/profile_0.json")
  if raw and raw ~= "" and raw ~= "{}" then
    local status, result = pcall(function() return json.decode(raw) end)
    if status and type(result) == "table" then
      botStorage = result
    end
  end
  pcall(function() noxMergeHpState(botStorage, sdir) end)

  -- run script
  local status, result = pcall(function() 
    return executeBot(configName, botStorage, botTabs, message, save, refresh, botWebSockets) end
  )
  if not status then
    return onError(result)
  end
  
  statusLabel:setOn(false)
  botExecutor = result
  check()
  showPanel()
  end) -- pcall refresh body
  __noxRefreshing = false
  if not okRefresh then
    pcall(function() onError(tostring(errRefresh)) end)
  end
end

function writeBotStorage()
  botStorage = botStorage or {}
  local charCfg = _G.__noxbot_char_cfg or sanitizeChar(g_game.getCharacterName())
  if charCfg == "" then charCfg = "_template" end
  local prof = 1
  pcall(function() prof = tonumber(g_settings.getNumber("profile")) or 1 end)
  if not prof or prof < 0 then prof = 1 end
  local dir = "/noxbot/" .. charCfg .. "/storage"
  botStorageFile = dir .. "/profile_" .. prof .. ".json"
  -- El txt se escribe SIEMPRE, aunque el json del OTC salga vacio.
  pcall(function() noxWriteOnOffTxt(botStorage, dir) end)
  pcall(function() noxWriteSettingsHp(botStorage) end)
  local payload = noxEncode(botStorage)
  -- No pisar un JSON bueno con vacio (refresh llamaba save antes de cargar)
  if payload == "{}" or payload == "[]" or payload == "{\n}" then
    local existing = noxReadFile(dir .. "/current.json") or noxReadFile(botStorageFile)
    if type(existing) == "string" and #existing > 8 then
      return true
    end
  end
  if payload:len() > 100 * 1024 * 1024 then
    return onError("Storage file is too big, above 100MB, it won't be saved")
  end
  noxWriteFile(botStorageFile, payload)
  noxWriteFile(dir .. "/current.json", payload)
  pcall(function() noxWriteHpState(botStorage, dir) end)
  noxWriteFile(dir .. "/last_save.txt", "saved " .. tostring(os.date and os.date() or "")
    .. " macros=" .. tostring(botStorage._macros and "yes" or "no")
    .. " heal=" .. tostring(botStorage.healBotEnabled)
    .. " cond=" .. tostring(botStorage.conditionsEnabled)
    .. " eq=" .. tostring(botStorage.EquipperPanel and botStorage.EquipperPanel.enabled)
    .. " food=" .. tostring(botStorage.eatFood and botStorage.eatFood.enabled)
    .. " setup=" .. tostring(type(botStorage.healSetupJson) == "string" and #botStorage.healSetupJson or 0))
  return true
end

-- Guarda storage + HealBot/Cave/Target. Sin recursion (saveAll ya no llama a save).
function save()
  if __noxSaving then return end
  __noxSaving = true
  local ok, err = pcall(function()
    writeBotStorage()
    if botExecutor and botExecutor.saveModules then
      botExecutor.saveModules()
    end
  end)
  __noxSaving = false
  if not ok and type(onError) == "function" then
    pcall(function() onError("save: " .. tostring(err)) end)
  end
end

function onMiniWindowClose()
  botButton:setOn(false)
end

local lastToggleMs = 0
function toggle()
  if not botWindow then return end
  local now = 0
  pcall(function()
    if g_clock and g_clock.millis then now = g_clock.millis() end
  end)
  if now > 0 and lastToggleMs > 0 and (now - lastToggleMs) < 280 then return end
  lastToggleMs = now
  if botWindow:isVisible() then
    botWindow:hide()
    botButton:setOn(false)
  else
    showPanel()
    botButton:setOn(true)
  end
end

function online()
  pcall(function() botButton:hide() end)
  local skip = false
  pcall(function()
    skip = modules.client_profiles and modules.client_profiles.ChangedProfile
  end)
  if not skip then
    _G.__noxbot_force_logged = true
    scheduleEvent(function() pcall(refresh) end, 200)
  end
end

function offline()
  save()
  clear()
  botButton:hide()
  editWindow:hide()
end

function onError(message)
  pcall(function()
    statusLabel:setOn(true)
    statusLabel:setText("Error:\n" .. tostring(message))
  end)
  pcall(function()
    local d = tostring(DATA or "")
    if d ~= "" and io and io.open then
      local f = io.open(d .. "/last_lua.txt", "w")
      if f then f:write("bot-error " .. tostring(message)) f:close() end
      local log = io.open(d .. "/inject.log", "a")
      if log then
        log:write(os.date("%Y-%m-%d %H:%M:%S ") .. "[lua] ERROR " .. tostring(message):gsub("\r", "") .. "\n")
        log:close()
      end
    end
  end)
end

function edit()
  local configs = g_resources.listDirectoryFiles("/noxbot", false, false)  
  editWindow.manager.upload.config:clearOptions()  
  for i=1,#configs do 
    editWindow.manager.upload.config:addOption(configs[i])
  end
  editWindow.manager.download.config:setText("")
  
  editWindow:show()
  editWindow:focus()
  editWindow:raise()
end

function createDefaultConfigs() return end
function __disabled_createDefaultConfigs()
  local defaultConfigFiles = g_resources.listDirectoryFiles("default_configs", false, false)
  for i, config_name in ipairs(defaultConfigFiles) do
    if not g_resources.directoryExists("/noxbot/" .. config_name) then
      g_resources.makeDir("/noxbot/" .. config_name)
      if not g_resources.directoryExists("/noxbot/" .. config_name) then
        return onError("Can't create /noxbot/" .. config_name .. " directory in " .. g_resources.getWriteDir())
      end

      local defaultConfigFiles = g_resources.listDirectoryFiles("default_configs/" .. config_name, true, false)
      for i, file in ipairs(defaultConfigFiles) do
        local baseName = file:split("/")
        baseName = baseName[#baseName]
        if g_resources.directoryExists(file) then
          g_resources.makeDir("/noxbot/" .. config_name .. "/" .. baseName)
          if not g_resources.directoryExists("/noxbot/" .. config_name .. "/" .. baseName) then
            return onError("Can't create /noxbot/" .. config_name  .. "/" .. baseName .. " directory in " .. g_resources.getWriteDir())
          end
          local defaultConfigFiles2 = g_resources.listDirectoryFiles("default_configs/" .. config_name .. "/" .. baseName, true, false)
          for i, file in ipairs(defaultConfigFiles2) do
            local baseName2 = file:split("/")
            baseName2 = baseName2[#baseName2]
            local contents = g_resources.fileExists(file) and g_resources.readFileContents(file) or ""
            if contents:len() > 0 then
              g_resources.writeFileContents("/noxbot/" .. config_name .. "/" .. baseName .. "/" .. baseName2, contents)
            end  
          end
        else
          local contents = g_resources.fileExists(file) and g_resources.readFileContents(file) or ""
          if contents:len() > 0 then
            g_resources.writeFileContents("/noxbot/" .. config_name .. "/" .. baseName, contents)
          end
        end
      end
    end
  end
end

function uploadConfig()
  local config = editWindow.manager.upload.config:getCurrentOption().text
  local archive = compressConfig(config)
  if not archive then
      return displayErrorBox(tr("Config upload failed"), tr("Config %s is invalid (can't be compressed)", config))
  end
  if archive:len() > 1024 * 1024 then
      return displayErrorBox(tr("Config upload failed"), tr("Config %s is too big, maximum size is 1024KB. Now it has %s KB.", config, math.floor(archive:len() / 1024)))
  end
  
  local infoBox = displayInfoBox(tr("Uploading config"), tr("Uploading config %s. Please wait.", config))
  
  HTTP.postJSON(configManagerUrl .. "?config=" .. config:gsub("%s+", "_"), archive, function(data, err)
    if infoBox then
      infoBox:destroy()
    end
    if err or data["error"] then      
      return displayErrorBox(tr("Config upload failed"), tr("Error while upload config %s:\n%s", config, err or data["error"]))
    end
    displayInfoBox(tr("Succesful config upload"), tr("Config %s has been uploaded.\n%s", config, data["message"]))
  end)  
end

function downloadConfig()
  local hash = editWindow.manager.download.config:getText()
  if hash:len() == 0 then
      return displayErrorBox(tr("Config download error"), tr("Enter correct config hash"))  
  end
  local infoBox = displayInfoBox(tr("Downloading config"), tr("Downloading config with hash %s. Please wait.", hash))
  HTTP.download(configManagerUrl .. "?hash=" .. hash, hash .. ".zip", function(path, checksum, err)
    if infoBox then
      infoBox:destroy()
    end
    if err then
      return displayErrorBox(tr("Config download error"), tr("Config with hash %s cannot be downloaded", hash))      
    end
    modules.client_textedit.show("", {
      title="Enter name for downloaded config",
      description="Config with hash " .. hash .. " has been downloaded. Enter name for new config.\nWarning: if config with same name already exist, it will be overwritten!",
      width=500
    }, function(configName)
      decompressConfig(configName, "/downloads/" .. path)
      refresh()
      edit()
    end)
  end)
end

function compressConfig(configName)
  if not g_resources.directoryExists("/noxbot/" .. configName) then
    return onError("Config " .. configName .. " doesn't exist")
  end
  local forArchive = {}
  for _, file in ipairs(g_resources.listDirectoryFiles("/noxbot/" .. configName)) do
    local fullPath = "/noxbot/" .. configName .. "/" .. file
    if g_resources.fileExists(fullPath) then -- regular file
        forArchive[file] = g_resources.readFileContents(fullPath)
    else -- dir
      for __, file2 in ipairs(g_resources.listDirectoryFiles(fullPath)) do
        local fullPath2 = fullPath .. "/" .. file2
        if g_resources.fileExists(fullPath2) then -- regular file
            forArchive[file .. "/" .. file2] = g_resources.readFileContents(fullPath2)
        end
      end
    end
  end
  return g_resources.createArchive(forArchive)
end

function decompressConfig(configName, archive)
  if g_resources.directoryExists("/noxbot/" .. configName) then
    g_resources.deleteFile("/noxbot/" .. configName) -- also delete dirs
  end
  local files = g_resources.decompressArchive(archive)
  g_resources.makeDir("/noxbot/" .. configName)
  if not g_resources.directoryExists("/noxbot/" .. configName) then
    return onError("Can't create /noxbot/" .. configName .. " directory in " .. g_resources.getWriteDir())
  end
  
  for file, contents in pairs(files) do
    local split = file:split("/")
    split[#split] = nil -- remove file name
    local dirPath = "/noxbot/" .. configName
    for _, s in ipairs(split) do
      dirPath = dirPath .. "/" .. s
      if not g_resources.directoryExists(dirPath) then
        g_resources.makeDir(dirPath)
        if not g_resources.directoryExists(dirPath) then
          return onError("Can't create " .. dirPath .. " directory in " .. g_resources.getWriteDir())
        end
      end
    end
    g_resources.writeFileContents("/noxbot/" .. configName .. file, contents)
  end
end

-- Executor
function message(category, msg)
  if category == "error" or category == "warn" then
    pcall(function()
      local ts = os.date("%H:%M:%S")
      local line = ts .. " [" .. tostring(category) .. "] " .. tostring(msg):gsub("\r", "") .. "\n"
      local prev = noxReadFile("/noxbot/noxbot_runtime.log") or ""
      if #prev > 512000 then prev = prev:sub(-256000) end
      noxWriteFile("/noxbot/noxbot_runtime.log", prev .. line)
    end)
    pcall(function()
      local d = tostring(DATA or "")
      if d ~= "" and io and io.open then
        local f = io.open(d .. "/inject.log", "a")
        if f then
          f:write(os.date("%Y-%m-%d %H:%M:%S ") .. "[lua] " .. string.upper(tostring(category))
            .. " " .. tostring(msg):gsub("\r", "") .. "\n")
          f:close()
        end
      end
    end)
  end
  local widget = g_ui.createWidget('BotLabel', botMessages)
  widget.added = g_clock.millis()
  if category == 'error' then
    widget:setText(msg)
    widget:setColor("red")
  elseif category == 'warn' then
    widget:setText(msg)        
    widget:setColor("yellow")
  elseif category == 'info' then
    widget:setText(msg)        
    widget:setColor("white")
  end
  
  if botMessages:getChildCount() > 5 then
    botMessages:getFirstChild():destroy()
  end
end

function check()
  removeEvent(checkEvent)
  if not botExecutor then
    return
  end

  checkEvent = scheduleEvent(check, 10)

  local status, result = pcall(function() 
    return botExecutor.script() 
  end)
  if not status then  
    botExecutor = nil -- critical
    return onError(result)
  end 
  
  -- remove old messages
  local widget = botMessages:getFirstChild()
  if widget and widget.added + 5000 < g_clock.millis() then
    widget:destroy()
  end
end

-- Callbacks
function initCallbacks()
  connect(rootWidget, {
    onKeyDown = botKeyDown,
    onKeyUp = botKeyUp,
    onKeyPress = botKeyPress 
  })

  connect(g_game, { 
    onTalk = botOnTalk,
    onTextMessage = botOnTextMessage,
    onLoginAdvice = botOnLoginAdvice,
    onUse = botOnUse,
    onUseWith = botOnUseWith,
    onChannelList = botChannelList,
    onOpenChannel = botOpenChannel,
    onCloseChannel = botCloseChannel,
    onChannelEvent = botChannelEvent,
    onImbuementWindow = botImbuementWindow,
    onModalDialog = botModalDialog,
    onAttackingCreatureChange = botAttackingCreatureChange,
    onAddItem = botContainerAddItem,
    onRemoveItem = botContainerRemoveItem,
    onGameEditText = botGameEditText,
    onSpellCooldown = botSpellCooldown,
    onSpellGroupCooldown = botGroupSpellCooldown
  })
  
  connect(Tile, {
    onAddThing = botAddThing,
    onRemoveThing = botRemoveThing 
  })

  connect(Creature, {
    onAppear = botCreatureAppear,
    onDisappear = botCreatureDisappear,
    onPositionChange = botCreaturePositionChange,
    onHealthPercentChange = botCraetureHealthPercentChange,
    onTurn = botCreatureTurn,
    onWalk = botCreatureWalk,
  })
  
  connect(LocalPlayer, {
    onPositionChange = botCreaturePositionChange,
    onHealthPercentChange = botCraetureHealthPercentChange,
    onTurn = botCreatureTurn,
    onWalk = botCreatureWalk,
    onManaChange = botManaChange,
    onStatesChange = botStatesChange,
    onInventoryChange = botInventoryChange
  })
  
  connect(Container, {
    onOpen = botContainerOpen,
    onClose = botContainerClose,
    onUpdateItem = botContainerUpdateItem,
    onAddItem = botContainerAddItem,
    onRemoveItem = botContainerRemoveItem,
  })
  
  connect(g_map, { 
    onMissle = botOnMissle,
    onAnimatedText = botOnAnimatedText,
    onStaticText = botOnStaticText
  })
end

function terminateCallbacks()
  disconnect(rootWidget, {
    onKeyDown = botKeyDown,
    onKeyUp = botKeyUp,
    onKeyPress = botKeyPress 
  })
                        
  disconnect(g_game, { 
    onTalk = botOnTalk,
    onTextMessage = botOnTextMessage,
    onLoginAdvice = botOnLoginAdvice,
    onUse = botOnUse,
    onUseWith = botOnUseWith,
    onChannelList = botChannelList,
    onOpenChannel = botOpenChannel,
    onCloseChannel = botCloseChannel,
    onChannelEvent = botChannelEvent,
    onImbuementWindow = botImbuementWindow,
    onModalDialog = botModalDialog,
    onAttackingCreatureChange = botAttackingCreatureChange,
    onGameEditText = botGameEditText,
    onSpellCooldown = botSpellCooldown,
    onSpellGroupCooldown = botGroupSpellCooldown
  })
  
  disconnect(Tile, {
    onAddThing = botAddThing,
    onRemoveThing = botRemoveThing 
  })

  disconnect(Creature, {
    onAppear = botCreatureAppear,
    onDisappear = botCreatureDisappear,
    onPositionChange = botCreaturePositionChange,
    onHealthPercentChange = botCraetureHealthPercentChange,
    onTurn = botCreatureTurn,
    onWalk = botCreatureWalk,
  })  
  
  disconnect(LocalPlayer, {
    onPositionChange = botCreaturePositionChange,
    onHealthPercentChange = botCraetureHealthPercentChange,
    onTurn = botCreatureTurn,
    onWalk = botCreatureWalk,
    onManaChange = botManaChange,
    onStatesChange = botStatesChange,
    onInventoryChange = botInventoryChange
  })
  
  disconnect(Container, {
    onOpen = botContainerOpen,
    onClose = botContainerClose,
    onUpdateItem = botContainerUpdateItem,
    onAddItem = botContainerAddItem, 
    onRemoveItem = botContainerRemoveItem
  })
  
  disconnect(g_map, { 
    onMissle = botOnMissle,
    onAnimatedText = botOnAnimatedText,
    onStaticText = botOnStaticText
  })
end

function safeBotCall(func)
  local status, result = pcall(func)
  if not status then    
    onError(result)
  end
end

function botKeyDown(widget, keyCode, keyboardModifiers)
  if botExecutor == nil then return false end
  if keyCode == KeyUnknown then return end
  safeBotCall(function() botExecutor.callbacks.onKeyDown(keyCode, keyboardModifiers) end)
end

function botKeyUp(widget, keyCode, keyboardModifiers)
  if botExecutor == nil then return false end
  if keyCode == KeyUnknown then return end
  safeBotCall(function() botExecutor.callbacks.onKeyUp(keyCode, keyboardModifiers) end)
end

function botKeyPress(widget, keyCode, keyboardModifiers, autoRepeatTicks)
  if botExecutor == nil then return false end
  if keyCode == KeyUnknown then return end
  safeBotCall(function() botExecutor.callbacks.onKeyPress(keyCode, keyboardModifiers, autoRepeatTicks) end)
end

function botOnTalk(name, level, mode, text, channelId, pos)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onTalk(name, level, mode, text, channelId, pos) end)
end

function botOnTextMessage(mode, text)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onTextMessage(mode, text) end)
end

function botOnLoginAdvice(message)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onLoginAdvice(message) end)
end

function botAddThing(tile, thing)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onAddThing(tile, thing) end)
end

function botRemoveThing(tile, thing)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onRemoveThing(tile, thing) end)
end

function botCreatureAppear(creature)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onCreatureAppear(creature) end)
end

function botCreatureDisappear(creature)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onCreatureDisappear(creature) end)
end

function botCreaturePositionChange(creature, newPos, oldPos)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onCreaturePositionChange(creature, newPos, oldPos) end)
end

function botCraetureHealthPercentChange(creature, healthPercent)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onCreatureHealthPercentChange(creature, healthPercent) end)
end

function botOnUse(pos, itemId, stackPos, subType)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onUse(pos, itemId, stackPos, subType) end)
end

function botOnUseWith(pos, itemId, target, subType)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onUseWith(pos, itemId, target, subType) end)
end

function botContainerOpen(container, previousContainer)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onContainerOpen(container, previousContainer) end)
end

function botContainerClose(container)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onContainerClose(container) end)
end

function botContainerUpdateItem(container, slot, item, oldItem)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onContainerUpdateItem(container, slot, item, oldItem) end)
end

function botOnMissle(missle)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onMissle(missle) end)
end

function botOnAnimatedText(thing, text)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onAnimatedText(thing, text) end)
end

function botOnStaticText(thing, text)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onStaticText(thing, text) end)
end

function botChannelList(channels)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onChannelList(channels) end)
end

function botOpenChannel(channelId, name)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onOpenChannel(channelId, name) end)
end

function botCloseChannel(channelId)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onCloseChannel(channelId) end)
end

function botChannelEvent(channelId, name, event)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onChannelEvent(channelId, name, event) end)
end

function botCreatureTurn(creature, direction)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onTurn(creature, direction) end)
end

function botCreatureWalk(creature, oldPos, newPos)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onWalk(creature, oldPos, newPos) end)
end

function botImbuementWindow(itemId, slots, activeSlots, imbuements, needItems)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onImbuementWindow(itemId, slots, activeSlots, imbuements, needItems) end)
end

function botModalDialog(id, title, message, buttons, enterButton, escapeButton, choices, priority)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onModalDialog(id, title, message, buttons, enterButton, escapeButton, choices, priority) end)
end

function botGameEditText(id, itemId, maxLength, text, writer, time)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onGameEditText(id, itemId, maxLength, text, writer, time) end)
end

function botAttackingCreatureChange(creature, oldCreature)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onAttackingCreatureChange(creature,oldCreature) end)
end

function botManaChange(player, mana, maxMana, oldMana, oldMaxMana)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onManaChange(player, mana, maxMana, oldMana, oldMaxMana) end)
end

function botStatesChange(player, states, oldStates)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onStatesChange(player, states, oldStates) end)
end

function botContainerAddItem(container, slot, item, oldItem)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onAddItem(container, slot, item, oldItem) end)
end

function botContainerRemoveItem(container, slot, item)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onRemoveItem(container, slot, item) end)
end

function botSpellCooldown(iconId, duration)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onSpellCooldown(iconId, duration) end)
end

function botGroupSpellCooldown(iconId, duration)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onGroupSpellCooldown(iconId, duration) end)
end

function hidePanel()
  pcall(function()
    if botWindow then botWindow:hide() end
    if botButton then botButton:setOn(false) end
  end)
end

function showPanel()
  pcall(function()
    if botWindow then
      botWindow:show()
      botWindow:raise()
      botWindow:focus()
    end
  end)
  pcall(noxFixAllSetupButtons)
  pcall(function()
    if scheduleEvent then
      scheduleEvent(noxFixAllSetupButtons, 80)
      scheduleEvent(noxFixAllSetupButtons, 400)
    end
  end)
end

function botInventoryChange(player, slot, item, oldItem)
  if botExecutor == nil then return false end
  safeBotCall(function() botExecutor.callbacks.onInventoryChange(player, slot, item, oldItem) end)
end