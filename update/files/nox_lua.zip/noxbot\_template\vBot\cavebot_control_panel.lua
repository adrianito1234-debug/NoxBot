-- CaveBot extras (Force Refill, etc.). Sin loadUIFromString ni grid flow (cuelga Nostalrius).
if type(setDefaultTab) ~= "function" then
  function setDefaultTab(name) end
end
pcall(function() setDefaultTab("Cave") end)

if type(storage.caveBot) ~= "table" then
  storage.caveBot = {
    forceRefill = false,
    backStop = false,
    backTrainers = false,
    backOffline = false,
  }
end

local ok, err = pcall(function()
  local panel = setupUI([[
Panel
  margin-top: 5
  layout:
    type: verticalBox
    fit-children: true

  HorizontalSeparator

  Label
    text-align: center
    text: CaveBot Control Panel
    font: verdana-11px-rounded
    margin-top: 3

  HorizontalSeparator

  Panel
    id: buttons
    margin-top: 2
    height: 44
    layout:
      type: grid
      cell-size: 86 20
      cell-spacing: 1
      num-columns: 2

  HorizontalSeparator
    margin-top: 3
]])

  if not panel or not panel.buttons then return end

  UI.Button("Force Refill", function()
    storage.caveBot.forceRefill = true
    print("[CaveBot] Going back on refill on next supply check.")
  end, panel.buttons)

  UI.Button("Back & Stop", function()
    storage.caveBot.backStop = true
    print("[CaveBot] Going back to city on next supply check and turning off CaveBot on depositer action.")
  end, panel.buttons)

  UI.Button("To Trainers", function()
    storage.caveBot.backTrainers = true
    print("[CaveBot] Going back to city on next supply check and going to label 'toTrainers' on depositer action.")
  end, panel.buttons)

  UI.Button("Offline", function()
    storage.caveBot.backOffline = true
    print("[CaveBot] Going back to city on next supply check and going to label 'toOfflineTraining' on depositer action.")
  end, panel.buttons)
end)

if not ok and type(warn) == "function" then
  warn("cavebot_control_panel: " .. tostring(err))
end
