setDefaultTab("Tools")

local SPELLS = {
  {words = "utani hur", name = "Haste", duration = 33, group = "haste"},
  {words = "utani gran hur", name = "Strong Haste", duration = 22, group = "haste"},
  {words = "utani tempo hur", name = "Charge", duration = 5, group = "haste"},
  {words = "utamo vita", name = "Magic Shield", duration = 200, group = "shield"},
  {words = "utana vid", name = "Invisibility", duration = 200, group = "invisible"},
  {words = "utamo tempo", name = "Protector", duration = 13, group = "protector"},
  {words = "utamo tempo san", name = "Swift Foot", duration = 10, group = "swiftfoot"},
  {words = "utito tempo", name = "Blood Rage", duration = 10, group = "bloodrage"},
  {words = "utito tempo san", name = "Sharpshooter", duration = 10, group = "sharpshooter"},
  {words = "utura", name = "Recovery", duration = 60, group = "recovery"},
  {words = "utura gran", name = "Intense Recovery", duration = 60, group = "recovery"},
}

local CHECKS = {
  haste = function() return hasHaste() end,
  shield = function() return hasManaShield() end,
  invisible = function() return player and player:isInvisible() end,
}

local byWords = {}
local fallbackSpell = {}
for _, spell in ipairs(SPELLS) do
  byWords[spell.words] = spell
  if CHECKS[spell.group] and not fallbackSpell[spell.group] then
    fallbackSpell[spell.group] = spell
  end
end

local active = {}
local rows = {}

local function mapPanel()
  local gi = modules and modules.game_interface
  if not gi then
    return nil
  end
  if gi.gameMapPanel then
    return gi.gameMapPanel
  end
  if type(gi.getMapPanel) == "function" then
    local ok, panel = pcall(gi.getMapPanel)
    if ok then
      return panel
    end
  end
  return nil
end

local hud
local hudParent = mapPanel()
if hudParent then
  local existing = hudParent:getChildById("spellTimersHud")
  if existing then
    existing:destroy()
  end
  hud = setupUI([[
Panel
  id: spellTimersHud
  anchors.top: parent.top
  anchors.left: parent.left
  margin-top: 40
  margin-left: 10
  width: 130
  phantom: true
  layout:
    type: verticalBox
    fit-children: true
]], hudParent)
end

local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.fill: parent
    text-align: center
    !text: tr('Show Spell Times')
]])
ui:setId("spellTimers")

if storage.showSpellTimes == nil then
  storage.showSpellTimes = false
end

local function removeRow(group)
  if rows[group] then
    rows[group]:destroy()
    rows[group] = nil
  end
end

local function ensureRow(group)
  if not hud or rows[group] then
    return
  end
  local row = UI.createWidget("BotLabel", hud)
  row:setColor("#7ef77e")
  rows[group] = row
end

local function clearAll()
  active = {}
  for group in pairs(rows) do
    rows[group]:destroy()
  end
  rows = {}
end

local function startTimer(spell)
  active[spell.group] = {
    name = spell.name,
    startedAt = now,
    endsAt = now + spell.duration * 1000,
  }
  ensureRow(spell.group)
end

ui.title:setOn(storage.showSpellTimes)
ui.title.onClick = function(widget)
  storage.showSpellTimes = not storage.showSpellTimes
  widget:setOn(storage.showSpellTimes)
  if not storage.showSpellTimes then
    clearAll()
  end
end

onTalk(function(speaker, level, mode, text, channelId, pos)
  if not storage.showSpellTimes then
    return
  end
  if speaker ~= name() then
    return
  end
  local spell = byWords[text:lower()]
  if spell then
    startTimer(spell)
  end
end)

macro(200, function()
  if not storage.showSpellTimes then
    return
  end
  for group, timer in pairs(active) do
    local check = CHECKS[group]
    local remaining = math.ceil((timer.endsAt - now) / 1000)
    local drop = false
    if check then
      if now - timer.startedAt > 2000 and not check() then
        drop = true
      elseif remaining < 0 then
        remaining = 0
      end
    elseif remaining <= 0 then
      drop = true
    end
    if drop then
      active[group] = nil
      removeRow(group)
    else
      ensureRow(group)
      if rows[group] then
        local t
        if remaining >= 60 then
          t = string.format("%d:%02d", math.floor(remaining / 60), remaining % 60)
        else
          t = remaining .. "s"
        end
        rows[group]:setText(timer.name .. ": " .. t)
      end
    end
  end
  for group, check in pairs(CHECKS) do
    if not active[group] and check() and fallbackSpell[group] then
      startTimer(fallbackSpell[group])
    end
  end
end)
