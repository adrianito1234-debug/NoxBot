-- NoxBot Private Script: Wave Spell
noxCommunityScript(function(config)
  if type(config.enabled) ~= "boolean" then config.enabled = false end

local wave=macro(250, "Wave Spell",  function()
  if g_game.isAttacking() then
      local target = g_game.getAttackingCreature() 
      if  target:isMonster() then
        if (manapercent() >= config.manaPercent2) and (hppercent() >= config.hpPercent2) then
            say(config.wave)

        end
      else
        if (manapercent() >= config.manaPercent2) and (hppercent() >= config.hpPercent2) then
            say(config.pvp)

        end
      end
  end
  end)
  local ICON_ID = 13415 -- id ikony
  addIcon("wave", {item={id = ICON_ID}, movable=true}, function(icon, isOn)
      wave.setOn(isOn) 
  end)
  UI.Label("Wave Spell:")
  UI.TextEdit(config.wave or "Ki Repulsion", function(widget, text)
      config.wave = text
  end)
    UI.Label("Pvp:")
  UI.TextEdit(config.pvp or "hell granade", function(widget, text)
      config.pvp = text
  end)
  UI.Label("Mana Percent:")
  UI.TextEdit(tostring(config.manaPercent2 or 20), function(widget, text)
      config.manaPercent2 = tonumber(text)
  end)
  
  UI.Label("HP Percent:")
  UI.TextEdit(tostring(config.hpPercent2 or 20), function(widget, text)
      config.hpPercent2 = tonumber(text)
  end)
end)