--[[
  Manifest NoxBot Scripts (comunidad)
  ───────────────────────────────────
  Añade una fila por script. NO cargues .lua aquí — solo metadatos (rápido).

  Campos:
    id      — nombre del archivo sin .lua (único, ej. "comm_antitrap")
    title   — texto en el panel Main
    kind    — "toggle" (solo switch) o "maker" (switch + Setup)
    window  — (maker) nombre OTUI, ej. "CommExampleWindow"
    button  — (maker) texto botón, default "Setup"

  Para 20-50 scripts: solo edita esta lista; cada .lua se carga lazy al activar.
]]

return {
  {
    id = "comm_example",
    title = "Example (plantilla)",
    kind = "toggle",
  },
  -- {
  --   id = "comm_my_tool",
  --   title = "My Tool",
  --   kind = "maker",
  --   window = "CommMyToolWindow",
  --   button = "Setup",
  -- },
}
