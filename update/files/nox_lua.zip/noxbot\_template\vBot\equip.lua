-- config
setDefaultTab("HP")
local scripts = 2 -- if you want more auto equip panels you can change 2 to higher value

-- script by kondrah, don't edit below unless you know what you are doing
UI.Label("Auto equip")
if type(storage.autoEquip) ~= "table" then
  storage.autoEquip = {}
end
-- JSON OTC: claves "1","2". Sin noxAsList, autoEquip[1] es nil y se reseteaba a life rings.
if type(noxAsList) == "function" then
  storage.autoEquip = noxAsList(storage.autoEquip)
end
for i = 1, scripts do
  local row = storage.autoEquip[i]
  if type(row) ~= "table" then
    -- Defaults vacios (NO life rings 3052/3089).
    storage.autoEquip[i] = { on = false, title = "Auto Equip", item1 = 0, item2 = 0, slot = i == 1 and 9 or 0 }
  else
    storage.autoEquip[i] = row
    row.item1 = tonumber(row.item1) or 0
    row.item2 = tonumber(row.item2) or 0
    row.slot = tonumber(row.slot) or (i == 1 and 9 or 0)
    if type(row.on) ~= "boolean" then row.on = not not row.on end
    if type(row.title) ~= "string" then row.title = "Auto Equip" end
  end
  UI.TwoItemsAndSlotPanel(storage.autoEquip[i], function(widget, newParams)
    storage.autoEquip[i] = newParams
    storage.autoEquip._n = scripts
    if type(noxPersist) == "function" then
      noxPersist(false)
    elseif type(saveConfig) == "function" then
      saveConfig()
    end
  end)
end
storage.autoEquip._n = scripts

-- Energy Ring: misma fila que Auto Equip. -% = poner, +% = quitar.
-- 3051 en backpack, 3088 puesto.
if type(storage.energyEquip) ~= "table" then
  storage.energyEquip = {}
end
local er = storage.energyEquip
if type(er.on) ~= "boolean" then er.on = false end
if type(er.item1) ~= "number" or er.item1 < 1 then er.item1 = 3051 end
if type(er.item2) ~= "number" or er.item2 < 1 then er.item2 = 3088 end
if type(er.onHp) ~= "number" then er.onHp = 50 end
if type(er.offHp) ~= "number" then er.offHp = 80 end

local erUi = setupUI([[
Panel
  height: 56
  margin-top: 4

  BotItem
    id: item1
    anchors.left: parent.left
    anchors.top: parent.top
    margin-top: 1

  BotItem
    id: item2
    anchors.left: prev.right
    anchors.top: prev.top
    margin-left: 1

  SmallBotSwitch
    id: title
    anchors.left: prev.right
    anchors.right: parent.right
    anchors.top: parent.top
    text-align: center
    margin-left: 2
    margin-top: 0
    !text: tr('Auto Equip')

  Label
    id: eqLabel
    anchors.left: title.left
    anchors.top: title.bottom
    margin-top: 3
    margin-left: 2
    text: Equip
    font: verdana-11px-rounded

  BotTextEdit
    id: onHp
    anchors.right: title.right
    anchors.verticalCenter: eqLabel.verticalCenter
    width: 28
    height: 17
    font: verdana-11px-rounded

  Label
    id: uqLabel
    anchors.left: title.left
    anchors.top: eqLabel.bottom
    margin-top: 4
    margin-left: 2
    text: Unequip
    font: verdana-11px-rounded

  BotTextEdit
    id: offHp
    anchors.right: title.right
    anchors.verticalCenter: uqLabel.verticalCenter
    width: 28
    height: 17
    font: verdana-11px-rounded
]])

erUi.title:setOn(er.on)
erUi.title.onClick = function()
  er.on = not er.on
  erUi.title:setOn(er.on)
end
erUi.item1:setItemId(er.item1)
erUi.item1.onItemChange = function()
  er.item1 = tonumber(erUi.item1:getItemId()) or 3051
end
erUi.item2:setItemId(er.item2)
erUi.item2.onItemChange = function()
  er.item2 = tonumber(erUi.item2:getItemId()) or 3088
end
local function editBox(w)
  pcall(function()
    if modules.client_textedit and modules.client_textedit.show then
      modules.client_textedit.show(w)
    end
  end)
end
erUi.onHp:setText(tostring(er.onHp))
erUi.onHp.onClick = function(widget) editBox(widget) end
erUi.onHp.onTextChange = function(widget, text)
  er.onHp = tonumber(text) or 50
end
erUi.offHp:setText(tostring(er.offHp))
erUi.offHp.onClick = function(widget) editBox(widget) end
erUi.offHp.onTextChange = function(widget, text)
  er.offHp = tonumber(text) or 80
end

local function fingerId()
  local id = 0
  pcall(function()
    local it = getFinger and getFinger()
    if it and it.getId then id = tonumber(it:getId()) or 0 end
  end)
  return id
end

local function wearingEnergy()
  local a = tonumber(er.item1) or 3051
  local b = tonumber(er.item2) or 3088
  local id = fingerId()
  return id == a or id == b
end

local function findOpenContainer()
  local dest = nil
  pcall(function()
    local list = getContainers and getContainers()
    if type(list) ~= "table" then return end
    for _, container in pairs(list) do
      if dest then return end
      if container then
        local cap, count = 0, 0
        pcall(function() cap = tonumber(container:getCapacity()) or 0 end)
        pcall(function() count = tonumber(container:getItemsCount()) or 0 end)
        if cap > 0 and count < cap then dest = container end
      end
    end
  end)
  return dest
end

local energyBusyUntil = 0
local ENERGY_LOCK_MS = 220

local function energyBusy()
  return now and energyBusyUntil > 0 and now < energyBusyUntil
end

local function markEnergyBusy()
  if now then
    energyBusyUntil = now + ENERGY_LOCK_MS
  end
end

local function putEnergyOn()
  if wearingEnergy() or energyBusy() then return false end
  local id = tonumber(er.item1) or 3051
  local item = nil
  pcall(function() item = findItem(id) end)
  if not item then return false end
  local okId = 0
  pcall(function()
    if item.getId then okId = tonumber(item:getId()) or 0 end
  end)
  if okId ~= id then return false end
  local slot = SlotFinger or 9
  local sent = false
  pcall(function()
    if moveToSlot then
      moveToSlot(item, slot)
    else
      g_game.move(item, { x = 65535, y = slot, z = 0 }, 1)
    end
    sent = true
  end)
  if sent then markEnergyBusy() end
  return sent
end

local function takeEnergyOff()
  if not wearingEnergy() or energyBusy() then return false end
  local finger = nil
  pcall(function() finger = getFinger and getFinger() end)
  if not finger then return false end
  local dest = findOpenContainer()
  if not dest then return false end
  local sent = false
  pcall(function()
    local pos = dest:getSlotPosition(dest:getItemsCount())
    if not pos then return end
    g_game.move(finger, pos, 1)
    sent = true
  end)
  if sent then markEnergyBusy() end
  return sent
end

-- Primer packet al instante (HP del jugador). Sin onHealthChange global:
-- en OTC eso pega en cada bicho y peta el cliente. Lock 220ms = no reenviar
-- el mismo move con el item en transito.
local function energyHp()
  local hp = 100
  pcall(function()
    if type(hppercent) == "function" then
      hp = tonumber(hppercent()) or 100
    elseif player and player.getHealthPercent then
      hp = tonumber(player:getHealthPercent()) or 100
    end
  end)
  return hp
end

local function energyNow()
  if not er.on then return end
  if not player then return end
  if type(g_game.isOnline) == "function" then
    local online = true
    pcall(function() online = g_game.isOnline() end)
    if not online then return end
  end
  if energyBusy() then return end
  local onHp = tonumber(er.onHp) or 50
  local offHp = tonumber(er.offHp) or 80
  if offHp <= onHp then offHp = math.min(100, onHp + 10) end
  local hp = energyHp()
  if hp <= 0 then return end
  local wearing = wearingEnergy()
  if hp <= onHp then
    if not wearing then putEnergyOn() end
    return
  end
  if hp >= offHp and wearing then
    takeEnergyOff()
  end
end

macro(100, function()
  pcall(energyNow)
end)

pcall(function()
  onPlayerHealthChange(function()
    pcall(energyNow)
  end)
end)

macro(250, function()
  local containers = g_game.getContainers()
  for index, autoEquip in ipairs(storage.autoEquip) do
    if autoEquip.on then
      local slotItem = nil
      pcall(function() slotItem = getSlot(autoEquip.slot) end)
      local sid = 0
      pcall(function()
        if slotItem and slotItem.getId then sid = tonumber(slotItem:getId()) or 0 end
      end)
      if sid ~= autoEquip.item1 and sid ~= autoEquip.item2 then
        for _, container in pairs(containers) do
          local items = nil
          pcall(function() items = container:getItems() end)
          if type(items) == "table" then
            for __, item in ipairs(items) do
              local iid = 0
              pcall(function() iid = item:getId() end)
              if iid == autoEquip.item1 or iid == autoEquip.item2 then
                pcall(function()
                  g_game.move(item, { x = 65535, y = autoEquip.slot, z = 0 }, item:getCount())
                end)
                delay(1000, "equip")
                return
              end
            end
          end
        end
      end
    end
  end
end)
