function executeBot(config, storage, tabs, msgCallback, saveConfigCallback, reloadCallback, websockets)
  local configFiles = g_resources.listDirectoryFiles("/noxbot/" .. config, true, false)
  local luaFiles = {}
  local uiFiles = {}
  local seenLua = {}
  for i, file in ipairs(configFiles) do
    local ext = file:split(".")
    local f = tostring(file):gsub("\\", "/"):lower()
    local base = (tostring(file):match("([^/\\]+)%.[^.]+$") or ""):lower()
    if ext[#ext]:lower() == "lua" then
      -- SOLO loader.lua (noxbot_ok no se ejecuta: evita doble init)
      if base == "loader" and not seenLua["loader"] then
        seenLua["loader"] = true
        table.insert(luaFiles, file)
      end
    end
    if ext[#ext]:lower() == "ui" or ext[#ext]:lower() == "otui" then
      if not f:find("cavebot/") and not f:find("targetbot/") and not f:find("vbot/") then
        table.insert(uiFiles, file)
      end
    end
  end

  if #luaFiles == 0 then
    local fallbacks = {
      "/noxbot/" .. config .. "/loader.lua",
      "/noxbot/_template/loader.lua",
    }
    for _, path in ipairs(fallbacks) do
      local ok = false
      pcall(function()
        if g_resources and g_resources.fileExists and g_resources.fileExists(path) then
          luaFiles[#luaFiles + 1] = path
          ok = true
        end
      end)
      if ok then break end
    end
  end
  if #luaFiles == 0 then
    return error("Config (/noxbot/" .. config .. ") doesn't have lua files (falta loader.lua)")
  end
  -- Preferir path relativo corto si hay varios
  if #luaFiles > 1 then
    table.sort(luaFiles, function(a, b) return #tostring(a) < #tostring(b) end)
    luaFiles = { luaFiles[1] }
  end

  -- init bot variables
  local realG = _G
  local context = {}
  context._G = context
  setmetatable(context, {
    __index = function(t, k)
      if k == "_G" then return t end
      local v = rawget(t, k)
      if v ~= nil then return v end
      return realG[k]
    end,
    __newindex = function(t, k, v)
      rawset(t, k, v)
    end,
  })
  context.configDir = "/noxbot/".. config
  context.tabs = tabs
  context.mainTab = context.tabs:addTab("Main", g_ui.createWidget('BotPanel')).tabPanel.content
  context.panel = context.mainTab
  context.saveConfig = saveConfigCallback
  context.reload = reloadCallback
  context.noxSave = saveConfigCallback

  context.storage = storage
  if context.storage._macros == nil then
    context.storage._macros = {} -- active macros
  end

  -- websockets, macros, hotkeys, scheduler, icons, callbacks
  context._websockets = websockets
  context._macros = {}
  context._hotkeys = {}
  context._scheduler = {}
  context._callbacks = {
    onKeyDown = {},
    onKeyUp = {},
    onKeyPress = {},
    onTalk = {},
    onTextMessage = {},
    onLoginAdvice = {},
    onAddThing = {},
    onRemoveThing = {},
    onCreatureAppear = {},
    onCreatureDisappear = {},
    onCreaturePositionChange = {},
    onCreatureHealthPercentChange = {},
    onUse = {},
    onUseWith = {},
    onContainerOpen = {},
    onContainerClose = {},
    onContainerUpdateItem = {},
    onMissle = {},
    onAnimatedText = {},
    onStaticText = {},
    onChannelList = {},
    onOpenChannel = {},
    onCloseChannel = {},
    onChannelEvent = {},
    onTurn = {},
    onWalk = {},
    onImbuementWindow = {},
    onModalDialog = {},
    onAttackingCreatureChange = {},
    onManaChange = {},
    onStatesChange = {},
    onAddItem = {},
    onGameEditText = {},
    onGroupSpellCooldown = {},
    onSpellCooldown = {},
    onRemoveItem = {},
    onInventoryChange = {}
  }
  
  -- basic functions & classes
  context.print = print
  context.bit32 = bit32
  context.bit = bit
  context.pairs = pairs
  context.ipairs = ipairs
  context.next = next
  context.tostring = tostring
  context.math = math
  context.table = table
  context.setmetatable = setmetatable
  context.string = string
  context.tonumber = tonumber
  context.type = type
  context.pcall = pcall
  if type(debug) == "table" then context.debug = debug end
  context.os = {
    time = os.time,
    difftime = os.difftime,
    date = os.date,
    clock = os.clock
  }
  context.load = function(str)
    local fn, err = load(str, nil, nil, context)
    if not fn and loadstring then fn, err = loadstring(str) end
    if not fn then return error(err) end
    if type(setfenv) == "function" then pcall(setfenv, fn, context) end
    return fn
  end
  context.loadstring = context.load

  -- Nostalrius: fuerza entorno bot (Lua 5.1 setfenv / load+env)
  local function runBotChunk(code, chunkName)
    if type(code) ~= "string" or code == "" then return nil, "empty" end
    local name = tostring(chunkName or "botchunk")
    local fn, err = load(code, name, nil, context)
    if not fn then
      if loadstring then fn, err = loadstring(code, name) else fn, err = load(code, name) end
    end
    if not fn then return nil, err end
    if type(setfenv) == "function" then
      pcall(setfenv, fn, context)
    end
    return fn
  end

  local function looksLikeLua(code)
    if type(code) ~= "string" or #code < 6 then return false end
    if code:sub(1, 4) == "NXL1" then return false end
    if code:find("\0", 1, true) then return false end
    local head = code:sub(1, 240)
    -- UTF-8 BOM
    if head:byte(1) == 0xEF and head:byte(2) == 0xBB and head:byte(3) == 0xBF then
      head = head:sub(4)
    end
    head = head:match("^[%s\r\n]*(.*)$") or head
    if head:match("^%-%-") then return true end
    if head:match("^local%s") or head:match("^function%s") then return true end
    if head:match("^return%s") or head:match("^if%s") or head:match("^for%s") then return true end
    if head:match("^[%w_%.]+%s*=") then return true end
    if head:match("^[%w_%.]+%s*%(") then return true end
    if head:match("^context%.") or head:match("^modules%.") then return true end
    return false
  end

  local function readScript(path)
    path = tostring(path or ""):gsub("\\", "/")
    if path == "" then return nil end

    -- Un script de perfil (/noxbot/<char>/...) nunca puede caer en un fichero
    -- del motor: vBot/tools.lua, vBot/main.lua y cavebot/config.lua chocan de
    -- nombre con functions/*.lua y se acababa ejecutando el interno, que abre
    -- con "local context = G.botContext" y revienta con context nil.
    local relPath = path:gsub("^/+", "")
    local isProfile = relPath:match("^noxbot/") ~= nil
      and relPath:match("^noxbot/pack/nox_bot/") == nil

    local function fromSlots(p)
      local raw = nil
      pcall(function()
        local t = rawget(_G, "__nox_txt") or rawget(realG, "__nox_txt")
        if type(t) ~= "table" then return end
        local k = p:gsub("^/+", "")
        raw = t[k]
          or t[k:gsub("^noxbot/pack/nox_bot/", "")]
          or t[k:gsub("^modules/nox_bot/", "")]
          or t[k:gsub("^engine/modules/nox_bot/", "")]
        if raw == nil and not isProfile then
          local leaf = k:match("([^/]+)$") or k
          raw = t["functions/" .. leaf] or t["panels/" .. leaf] or t[leaf]
        end
      end)
      if looksLikeLua(raw) then return raw end
      return nil
    end

    local function fromDisk(p)
      local raw = nil
      local data = tostring(rawget(_G, "DATA") or rawget(realG, "DATA") or ""):gsub("\\", "/"):gsub("/+$", "")
      local tryOpen = function(disk)
        if type(raw) == "string" and raw ~= "" then return end
        pcall(function()
          if not io or not io.open then return end
          local f = io.open(disk:gsub("/", "\\"), "rb")
          if f then raw = f:read("*a"); f:close() end
        end)
        if type(raw) == "string" and raw ~= "" then return end
        -- FFI: Nostalrius a menudo quita io pero deja leer disco
        pcall(function()
          local okF, ffi = pcall(require, "ffi")
          if not okF or not ffi then return end
          pcall(function()
            ffi.cdef[[
              typedef void* HANDLE;
              HANDLE CreateFileW(const wchar_t*, unsigned long, unsigned long, void*, unsigned long, unsigned long, void*);
              int ReadFile(HANDLE, void*, unsigned long, unsigned long*, void*);
              int CloseHandle(HANDLE);
              int MultiByteToWideChar(unsigned int, unsigned long, const char*, int, wchar_t*, int);
              unsigned long GetFileSize(HANDLE, unsigned long*);
            ]]
          end)
          local win = disk:gsub("/", "\\")
          local n = ffi.C.MultiByteToWideChar(65001, 0, win, #win, nil, 0)
          if not n or n <= 0 then return end
          local wbuf = ffi.new("wchar_t[?]", n + 1)
          ffi.C.MultiByteToWideChar(65001, 0, win, #win, wbuf, n)
          wbuf[n] = 0
          local INVALID = ffi.cast("HANDLE", -1)
          local h = ffi.C.CreateFileW(wbuf, 0x80000000, 1, nil, 3, 0x80, nil)
          if h == nil or h == INVALID then return end
          local sz = tonumber(ffi.C.GetFileSize(h, nil)) or 0
          if sz <= 0 or sz > 8 * 1024 * 1024 then
            ffi.C.CloseHandle(h)
            return
          end
          local buf = ffi.new("char[?]", sz)
          local rd = ffi.new("unsigned long[1]")
          if ffi.C.ReadFile(h, buf, sz, rd, nil) == 0 then
            ffi.C.CloseHandle(h)
            return
          end
          ffi.C.CloseHandle(h)
          raw = ffi.string(buf, tonumber(rd[0]) or sz)
        end)
      end
      if p:match("^%a:[/\\]") or p:match("^\\\\") then
        tryOpen(p)
        if looksLikeLua(raw) then return raw end
      end
      if data ~= "" then
        local rel = p:gsub("^/+", "")
        local leaf = rel:match("([^/]+)$") or rel
        local motorRel = rel
          :gsub("^noxbot/pack/nox_bot/", "")
          :gsub("^modules/nox_bot/", "")
          :gsub("^engine/modules/nox_bot/", "")
        local cands = { data .. "/" .. rel }
        if not isProfile then
          cands[#cands + 1] = data .. "/engine/modules/nox_bot/" .. motorRel
          cands[#cands + 1] = data .. "/noxbot/pack/nox_bot/" .. motorRel
          cands[#cands + 1] = data .. "/engine/modules/nox_bot/functions/" .. leaf
          cands[#cands + 1] = data .. "/noxbot/pack/nox_bot/functions/" .. leaf
          cands[#cands + 1] = data .. "/engine/modules/nox_bot/panels/" .. leaf
          cands[#cands + 1] = data .. "/noxbot/pack/nox_bot/panels/" .. leaf
        end
        for _, disk in ipairs(cands) do
          raw = nil
          tryOpen(disk)
          if looksLikeLua(raw) then return raw end
        end
      end
      return nil
    end

    local function fromVfs(p)
      local raw = nil
      pcall(function()
        if g_resources and g_resources.readFileContents then
          raw = g_resources.readFileContents(p)
        end
      end)
      -- Nostalrius VFS firmado: a menudo basura/encriptado. Solo aceptar Lua real.
      if looksLikeLua(raw) then return raw end
      return nil
    end

    -- Orden: ranuras bridge (zip embebido) → disco DATA → VFS (solo si es Lua)
    local code = fromSlots(path) or fromDisk(path) or fromVfs(path)
    if looksLikeLua(code) then return code end
    if type(nox_crypto) == "table" and type(nox_crypto.readScript) == "function" then
      local ok, c = pcall(nox_crypto.readScript, path)
      if ok and looksLikeLua(c) then return c end
    end
    return nil
  end
  context.readScript = readScript

  pcall(function()
    local ncPath = "/modules/nox_bot/nox_crypto.lua"
    if g_resources.fileExists(ncPath) then
      local nc = g_resources.readFileContents(ncPath)
      if type(nc) == "string" and nc ~= "" then
        local fn = load(nc, "nox_crypto.lua", nil, context)
        if fn then
          if type(setfenv) == "function" then pcall(setfenv, fn, context) end
          fn()
        end
        if type(nox_crypto) == "table" then context.nox_crypto = nox_crypto end
      end
    end
  end)
  context.assert = assert
  -- Anti-duplicados: /vBot/x.lua y vBot/x.lua = mismo path.
  -- NO usar solo basename (vBot/cavebot.lua != cavebot/cavebot.lua).
  local loadedDofiles = {}
  context.dofile = function(file)
    local f = tostring(file or ""):gsub("\\", "/")
    local rel = f:gsub("^/+", "")
    local key = rel:lower()
    if loadedDofiles[key] then return end
    loadedDofiles[key] = true
    local full = "/noxbot/" .. config .. "/" .. rel
    if g_resources.fileExists and not g_resources.fileExists(full) then
      local tpl = "/noxbot/_template/" .. rel
      if g_resources.fileExists(tpl) then
        full = tpl
      else
        return
      end
    end
    local code = readScript(full)
    if type(code) ~= "string" or code == "" then return end
    local fn, err = runBotChunk(code, rel)
    if not fn then
      pcall(function() context.error(tostring(err)) end)
      return
    end
    fn()
  end
  context.gcinfo = gcinfo
  context.tr = tr
  context.json = json
  context.base64 = base64
  context.regexMatch = regexMatch
  context.getDistanceBetween = function(p1, p2)
    return math.max(math.abs(p1.x - p2.x), math.abs(p1.y - p2.y))
  end
  context.isMobile = g_app.isMobile
  context.getVersion = g_app.getVersion
  
  -- classes
  context.g_resources = g_resources
  context.g_game = g_game
  context.g_map = g_map
  context.g_ui = g_ui
  context.g_sounds = g_sounds
  context.g_window = g_window
  context.g_mouse = g_mouse
  context.g_keyboard = g_keyboard
  context.g_things = g_things
  context.g_settings = g_settings
  if g_clock then context.g_clock = g_clock end
  if g_app then context.g_app = g_app end
  if g_http then context.g_http = g_http end
  if g_crypt then context.g_crypt = g_crypt end
  if g_platform then context.g_platform = g_platform end
  -- Sandbox externo: copiar cualquier g_* del OT que falte
  if _G then
    for name, value in pairs(_G) do
      if type(name) == "string" and name:sub(1, 2) == "g_" and context[name] == nil and value ~= nil then
        context[name] = value
      end
    end
  end

  context.Item = Item
  context.Creature = Creature
  context.ThingType = ThingType
  context.Effect = Effect
  context.Missile = Missile
  context.Player = Player
  context.Monster = Monster
  context.StaticText = StaticText
  context.HTTP = HTTP
  context.OutputMessage = OutputMessage
  context.modules = modules

  -- Para carga escalonada del loader (no depende del tick de macros).
  if type(scheduleEvent) == "function" then
    context.scheduleEvent = scheduleEvent
  end
  if type(removeEvent) == "function" then
    context.removeEvent = removeEvent
  end

  local function noxImportOtuiFile(path)
    path = tostring(path or ""):gsub("\\", "/")
    if path == "" then return end
    if not g_resources or not g_resources.fileExists or not g_resources.fileExists(path) then return end
    pcall(function() g_ui.importStyle(path) end)
    pcall(function()
      if g_ui.importStyleFromString then
        local code = g_resources.readFileContents(path)
        if type(code) == "string" and code ~= "" then
          g_ui.importStyleFromString(code)
        end
      end
    end)
  end

  local function noxImportAllStyles(cfgName)
    for _, p in ipairs({
      "/noxbot/pack/nox_bot/ui/basic.otui",
      "/noxbot/pack/nox_bot/ui/panels.otui",
      "/noxbot/pack/nox_bot/ui/config.otui",
      "/noxbot/pack/nox_bot/ui/icons.otui",
      "/noxbot/pack/nox_bot/ui/container.otui",
    }) do
      noxImportOtuiFile(p)
    end
    local otuiNames = {
      "use_item_messages.otui", "legacy_hotkeys.otui", "HealBot.otui", "supplies.otui",
      "AttackBot.otui", "extras.otui", "energy_equip.otui", "new_healer.otui",
      "analyzer.otui", "stop_cavebot_if.otui", "siolist.otui", "equipper.otui",
      "script_manager.otui", "pushmax.otui", "eat_food.otui", "player_training.otui",
      "Dropper.otui", "playerlist.otui", "depositer_config.otui", "Conditions.otui",
      "manatrain.otui", "combo.otui", "makers.otui", "BotServer.otui", "Jitter.otui", "alarms.otui",
    }
    local caveOtui = {
      "cavebot.otui", "config.otui", "editor.otui", "minimap_waypoints.otui", "lure_monsters.otui",
    }
    local cfgBases = { "/noxbot/" .. cfgName, "/noxbot/_template" }
    for _, base in ipairs(cfgBases) do
      for _, name in ipairs(otuiNames) do
        noxImportOtuiFile(base .. "/vBot/" .. name)
      end
      for _, name in ipairs(caveOtui) do
        noxImportOtuiFile(base .. "/cavebot/" .. name)
      end
      noxImportOtuiFile(base .. "/targetbot/looting.otui")
      noxImportOtuiFile(base .. "/targetbot/target.otui")
      noxImportOtuiFile(base .. "/targetbot/creature_editor.otui")
    end
  end
  noxImportAllStyles(config)

  pcall(function()
    local cls = UISpinBox
    if cls == nil or cls.__noxSpinPatched then return end
    cls.__noxSpinPatched = true
    local function install(name, field)
      local orig = cls[name]
      cls[name] = function(self, v)
        v = tonumber(v)
        if not self or not v then return end
        if type(orig) == 'function' then
          pcall(orig, self, v)
        end
        pcall(function() self[field] = v end)
      end
    end
    install('setMaximum', 'maximum')
    install('setMinimum', 'minimum')
  end)

  -- log functions
  context.info = function(text) return msgCallback("info", tostring(text)) end
  context.warn = function(text) return msgCallback("warn", tostring(text)) end
  context.error = function(text) return msgCallback("error", tostring(text)) end
  context.warning = context.warn      

  -- Siempre desde noxbot_data del zip (DATA / ranuras bridge). Nunca del cliente OT.
  -- Cliente nuevo/protegido: sin io ni VFS → solo __nox_fn del bridge.
  local function noxLoadDir(subdir)
    local data = tostring(rawget(_G, "DATA") or rawget(realG, "DATA") or ""):gsub("\\", "/"):gsub("/+$", "")
    local bases = {
      "/noxbot/pack/nox_bot/" .. subdir,
      "/modules/nox_bot/" .. subdir,
      "/engine/modules/nox_bot/" .. subdir,
    }
    if data ~= "" then
      bases[#bases + 1] = data .. "/noxbot/pack/nox_bot/" .. subdir
      bases[#bases + 1] = data .. "/engine/modules/nox_bot/" .. subdir
    end
    local fallback = {
      functions = {
        "const.lua", "callbacks.lua", "config.lua", "icon.lua", "map.lua",
        "npc.lua", "player.lua", "player_conditions.lua", "player_inventory.lua",
        "server.lua", "sound.lua", "tools.lua", "main.lua", "ui_legacy.lua",
        "ui.lua", "ui_elements.lua", "ui_windows.lua", "script_loader.lua",
      },
      panels = {
        "basic.lua", "healing.lua", "looting.lua", "attacking.lua",
        "tools.lua", "war.lua", "waypoints.lua",
      },
    }

    local function slotTable()
      return rawget(_G, "__nox_fn") or rawget(realG, "__nox_fn")
    end

    local function runEngineSlot(name)
      -- 1) Texto en ranura → cargar en sandbox (preferido)
      local txtKeys = {
        subdir .. "/" .. name,
        "functions/" .. name,
        "panels/" .. name,
        name,
      }
      local texts = rawget(_G, "__nox_txt") or rawget(realG, "__nox_txt")
      if type(texts) == "table" then
        for _, k in ipairs(txtKeys) do
          local src = texts[k]
          if looksLikeLua(src) then
            local fn, err = runBotChunk(src, subdir .. "/" .. name)
            if fn then
              local ok, e2 = pcall(fn)
              if ok then return true end
              pcall(function() context.error("NoxBot txt " .. k .. ": " .. tostring(e2)) end)
            elseif err then
              pcall(function() context.error(tostring(err)) end)
            end
          end
        end
      end
      -- 2) Ranura precompilada: asegurar G.botContext en _G real
      local fns = slotTable()
      if type(fns) ~= "table" then return false end
      local slot = nil
      for _, k in ipairs(txtKeys) do
        if type(fns[k]) == "function" then slot = fns[k]; break end
      end
      if type(slot) ~= "function" then return false end
      pcall(function()
        realG.G = realG.G or G or {}
        realG.G.botContext = context
        _G.G = realG.G
        _G.G.botContext = context
      end)
      if type(setfenv) == "function" then pcall(setfenv, slot, context) end
      local ok, err = pcall(slot)
      if not ok then
        pcall(function() context.error("NoxBot slot " .. subdir .. "/" .. name .. ": " .. tostring(err)) end)
        return false
      end
      return true
    end

    local function loadLuaFile(name)
      if runEngineSlot(name) then return true end
      for _, base in ipairs(bases) do
        local path = base .. "/" .. name
        local code = readScript(path)
        if type(code) == "string" and code ~= "" then
          local fn, err = runBotChunk(code, path)
          if not fn then
            pcall(function() context.error(tostring(err)) end)
          else
            fn()
            return true
          end
        end
      end
      return false
    end

    local files = {}
    local seen = {}
    local function addName(n)
      n = tostring(n or ""):match("([^/\\]+)$") or tostring(n or "")
      local low = n:lower()
      if not low:match("%.lua$") then return end
      if seen[low] then return end
      seen[low] = true
      files[#files + 1] = n
    end
    for _, base in ipairs(bases) do
      local listed = {}
      pcall(function()
        listed = g_resources.listDirectoryFiles(base, false, false) or {}
      end)
      if type(listed) == "table" then
        for _, f in ipairs(listed) do addName(f) end
      end
    end
    -- Ranuras del bridge (zip embebido → engine en memoria)
    do
      local fns = slotTable()
      if type(fns) == "table" then
        local prefix = subdir .. "/"
        for k, v in pairs(fns) do
          if type(v) == "function" and type(k) == "string" then
            local kk = k:gsub("\\", "/")
            if kk:sub(1, #prefix) == prefix then
              addName(kk:sub(#prefix + 1))
            end
          end
        end
      end
    end
    if #files == 0 and fallback[subdir] then
      for _, n in ipairs(fallback[subdir]) do addName(n) end
    end
    -- Siempre asegurar la lista critica aunque VFS haya listado basura
    if fallback[subdir] then
      for _, n in ipairs(fallback[subdir]) do addName(n) end
    end
    table.sort(files)
    local loaded = 0
    for _, name in ipairs(files) do
      if loadLuaFile(name) then loaded = loaded + 1 end
    end
    return loaded > 0
  end
  dofiles = function(subdir) noxLoadDir(subdir) end

  -- init context
  context.now = g_clock.millis()
  context.time = g_clock.millis()
  context.player = g_game.getLocalPlayer()

  -- init functions
  G = G or {}
  G.botContext = context
  context.G = G
  do
    local ps = PlayerStates
    if type(ps) ~= "table" and _G and type(_G.PlayerStates) == "table" then ps = _G.PlayerStates end
    if type(ps) ~= "table" and modules and modules.gamelib and type(modules.gamelib.PlayerStates) == "table" then
      ps = modules.gamelib.PlayerStates
    end
    if type(ps) ~= "table" then
      ps = {
        None = 0, Poison = 1, Burn = 2, Energy = 4, Drunk = 8,
        ManaShield = 16, Paralyze = 32, Haste = 64, Swords = 128,
        Drowning = 256, Freezing = 512, Dazzled = 1024, Cursed = 2048,
        PartyBuff = 4096, PzBlock = 8192, Pz = 16384, Bleeding = 32768, Hungry = 65536,
      }
    end
    context.PlayerStates = ps
  end
  if modules.client_profiles then modules.client_profiles.dirForConfigs = "/noxbot/" .. config end
  context.dirForConfigs = "/noxbot/" .. config
  dofiles("functions")
  -- Reintento forzoso de APIs criticas (cliente fresco sin VFS)
  do
    local need = {
      { key = "setupUI", file = "ui_legacy.lua" },
      { key = "UI", file = "ui_elements.lua" },
      { key = "onAttackingCreatureChange", file = "callbacks.lua" },
    }
    local function missing(k)
      local v = rawget(context, k)
      return v == nil or (k == "UI" and type(v) ~= "table") or (k ~= "UI" and type(v) ~= "function")
    end
    local fns = rawget(_G, "__nox_fn") or rawget(realG, "__nox_fn")
    for _, n in ipairs(need) do
      if missing(n.key) then
        local ok = false
        if type(fns) == "table" then
          local slot = fns["functions/" .. n.file] or fns[n.file]
          if type(slot) == "function" then
            if type(setfenv) == "function" then pcall(setfenv, slot, context) end
            ok = pcall(slot)
          end
        end
        if not ok or missing(n.key) then
          local paths = {
            "/noxbot/pack/nox_bot/functions/" .. n.file,
            "/modules/nox_bot/functions/" .. n.file,
            "/engine/modules/nox_bot/functions/" .. n.file,
          }
          local data = tostring(rawget(_G, "DATA") or rawget(realG, "DATA") or ""):gsub("\\", "/"):gsub("/+$", "")
          if data ~= "" then
            paths[#paths + 1] = data .. "/noxbot/pack/nox_bot/functions/" .. n.file
            paths[#paths + 1] = data .. "/engine/modules/nox_bot/functions/" .. n.file
          end
          for _, path in ipairs(paths) do
            local code = readScript(path)
            if type(code) == "string" and code ~= "" then
              local fn = select(1, runBotChunk(code, path))
              if fn then pcall(fn); break end
            end
          end
        end
      end
    end
    if type(rawget(context, "setupUI")) ~= "function" then
      pcall(function() context.error("NoxBot: setupUI missing — functions/ no cargo desde el pack") end)
    end
    if type(rawget(context, "UI")) ~= "table" then
      pcall(function() context.error("NoxBot: UI missing — ui_elements.lua no cargo") end)
    end
  end
  -- Clientes sin modulo game_cooldown: evita nil en vBot/Conditions.lua etc.
  pcall(function()
    if type(modules) ~= "table" then return end
    if modules.game_cooldown then return end
    modules.game_cooldown = {
      isGroupCooldownIconActive = function() return false end,
      isCooldownIconActive = function() return false end,
    }
  end)
  context.Panels = {}
  dofiles("panels")
  -- Aliases para vBot (sandbox usa context como _G)
  context.context = context
  context.macro = context.macro
  context.UI = context.UI
  context.setupUI = context.setupUI
  context.delay = context.delay
  context.schedule = context.schedule
  context.storage = context.storage
  context.info = context.info
  context.warn = context.warn
  context.warning = context.warning
  context.error = context.error
  context.now = context.now
  context.time = context.time
  context.player = context.player
  context.rootWidget = g_ui.getRootWidget()
  if context.say then context.say = context.say end
  if context.walk then context.walk = context.walk end
  -- Mantener botContext durante la carga del loader (algunos scripts lo miran)
  G.botContext = context

  -- run ui scripts
  for i, file in ipairs(uiFiles) do
    g_ui.importStyle(file)
  end

  -- run lua script
  for i, file in ipairs(luaFiles) do
    local ok, err = pcall(function()
      local fn, lerr = runBotChunk(readScript(file) or "", file)
      assert(fn, lerr)
      fn()
    end)
    if not ok then
      pcall(function() context.error(tostring(err)) end)
    end
    context.panel = context.mainTab -- reset default tab
  end
  G.botContext = nil

  -- Solo modulos (NO llama a save/saveConfig: eso era recursion infinita y no escribia nada)
  local function saveModules()
    pcall(function()
      if type(context.vBotConfigSave) == "function" then
        context.vBotConfigSave("heal")
        context.vBotConfigSave("atk")
        context.vBotConfigSave("supply")
      end
    end)
    pcall(function()
      if context.CaveBot and type(context.CaveBot.save) == "function" then
        context.CaveBot.save()
      end
    end)
    pcall(function()
      if context.TargetBot and type(context.TargetBot.save) == "function" then
        context.TargetBot.save()
      end
    end)
  end
  local function saveAll()
    saveModules()
  end

  return {
    script = function()
      context.now = g_clock.millis()
      context.time = g_clock.millis()
      context.player = g_game.getLocalPlayer()
      context.rootWidget = g_ui.getRootWidget()
      for i, macro in ipairs(context._macros) do
        if macro.enabled and type(macro.callback) == "function"
            and macro.lastExecution + macro.timeout <= context.now then
          local status, result = pcall(function()
            if macro.callback(macro) then
                macro.lastExecution = context.now
            end
          end)
          if not status then
            context.error("Macro: " .. tostring(macro.name) .. " execution error: " .. result)
          end
        end
      end
      
      while #context._scheduler > 0 and context._scheduler[1].execution <= g_clock.millis() do
        local job = context._scheduler[1]
        if type(job.callback) ~= "function" then
          table.remove(context._scheduler, 1)
        else
        local status, result = pcall(function()
          job.callback()
        end)
        if not status then
          context.error("Schedule execution error: " .. result)
        end
        table.remove(context._scheduler, 1)
        end
      end
    end,
    callbacks = {
      onKeyDown = function(keyCode, keyboardModifiers)
        local keyDesc = determineKeyComboDesc(keyCode, keyboardModifiers)
        for i, macro in ipairs(context._macros) do
          if macro.switch and macro.hotkey == keyDesc then
            macro.switch:onClick()
          end
        end
        local hotkey = context._hotkeys[keyDesc]
        if hotkey then
          if hotkey.single then
            if hotkey.callback() then
              hotkey.lastExecution = context.now            
            end
          end
          if hotkey.switch then
            hotkey.switch:setOn(true)
          end
        end
        for i, callback in ipairs(context._callbacks.onKeyDown) do
          callback(keyDesc)
        end
      end,
      onKeyUp = function(keyCode, keyboardModifiers)
        local keyDesc = determineKeyComboDesc(keyCode, keyboardModifiers)
        local hotkey = context._hotkeys[keyDesc]
        if hotkey then        
          if hotkey.switch then
            hotkey.switch:setOn(false)
          end
        end
        for i, callback in ipairs(context._callbacks.onKeyUp) do
          callback(keyDesc)
        end
      end,
      onKeyPress = function(keyCode, keyboardModifiers, autoRepeatTicks)
        local keyDesc = determineKeyComboDesc(keyCode, keyboardModifiers)
        local hotkey = context._hotkeys[keyDesc]
        if hotkey and not hotkey.single then
          if hotkey.callback() then
            hotkey.lastExecution = context.now          
          end
        end
        for i, callback in ipairs(context._callbacks.onKeyPress) do
          callback(keyDesc, autoRepeatTicks)
        end
      end,
      onTalk = function(name, level, mode, text, channelId, pos)
        for i, callback in ipairs(context._callbacks.onTalk) do
          callback(name, level, mode, text, channelId, pos)
        end
      end,
      onImbuementWindow = function(itemId, slots, activeSlots, imbuements, needItems)
        for i, callback in ipairs(context._callbacks.onImbuementWindow) do
          callback(itemId, slots, activeSlots, imbuements, needItems)
        end
      end,
      onTextMessage = function(mode, text)
        for i, callback in ipairs(context._callbacks.onTextMessage) do
          callback(mode, text)
        end
      end,
      onLoginAdvice = function(message)
        for i, callback in ipairs(context._callbacks.onLoginAdvice) do
          callback(message)
        end
      end,      
      onAddThing = function(tile, thing)
        for i, callback in ipairs(context._callbacks.onAddThing) do
          callback(tile, thing)
        end      
      end,
      onRemoveThing = function(tile, thing)
        for i, callback in ipairs(context._callbacks.onRemoveThing) do
          callback(tile, thing)
        end      
      end,
      onCreatureAppear = function(creature)
        for i, callback in ipairs(context._callbacks.onCreatureAppear) do
          callback(creature)
        end      
      end,
      onCreatureDisappear = function(creature)
        for i, callback in ipairs(context._callbacks.onCreatureDisappear) do
          callback(creature)
        end
      end,
      onCreaturePositionChange = function(creature, newPos, oldPos)
        for i, callback in ipairs(context._callbacks.onCreaturePositionChange) do
          callback(creature, newPos, oldPos)
        end      
      end,
      onCreatureHealthPercentChange = function(creature, healthPercent)
        for i, callback in ipairs(context._callbacks.onCreatureHealthPercentChange) do
          callback(creature, healthPercent)
        end      
      end,
      onUse = function(pos, itemId, stackPos, subType)
        for i, callback in ipairs(context._callbacks.onUse) do
          callback(pos, itemId, stackPos, subType)
        end      
      end,
      onUseWith = function(pos, itemId, target, subType)
        for i, callback in ipairs(context._callbacks.onUseWith) do
          callback(pos, itemId, target, subType)
        end
      end,
      onContainerOpen = function(container, previousContainer)
        for i, callback in ipairs(context._callbacks.onContainerOpen) do
          callback(container, previousContainer)
        end
      end,
      onContainerClose = function(container)
        for i, callback in ipairs(context._callbacks.onContainerClose) do
          callback(container)
        end
      end,
      onContainerUpdateItem = function(container, slot, item, oldItem)
        for i, callback in ipairs(context._callbacks.onContainerUpdateItem) do
          callback(container, slot, item, oldItem)
        end
      end,
      onMissle = function(missle)
        for i, callback in ipairs(context._callbacks.onMissle) do
          callback(missle)
        end
      end,
      onAnimatedText = function(thing, text)
        for i, callback in ipairs(context._callbacks.onAnimatedText) do
          callback(thing, text)
        end
      end,
      onStaticText = function(thing, text)
        for i, callback in ipairs(context._callbacks.onStaticText) do
          callback(thing, text)
        end
      end,
      onChannelList = function(channels)
        for i, callback in ipairs(context._callbacks.onChannelList) do
          callback(channels)
        end      
      end,
      onOpenChannel = function(channelId, channelName)
        for i, callback in ipairs(context._callbacks.onOpenChannel) do
          callback(channels)
        end      
      end,
      onCloseChannel = function(channelId)
        for i, callback in ipairs(context._callbacks.onCloseChannel) do
          callback(channelId)
        end      
      end,
      onChannelEvent = function(channelId, name, event)
        for i, callback in ipairs(context._callbacks.onChannelEvent) do
          callback(channelId, name, event)
        end      
      end,
      onTurn = function(creature, direction)
        for i, callback in ipairs(context._callbacks.onTurn) do
          callback(creature, direction)
        end      
      end,
      onWalk = function(creature, oldPos, newPos)
        for i, callback in ipairs(context._callbacks.onWalk) do
          callback(creature, oldPos, newPos)
        end      
      end,
      onModalDialog = function(id, title, message, buttons, enterButton, escapeButton, choices, priority)
        for i, callback in ipairs(context._callbacks.onModalDialog) do
          callback(id, title, message, buttons, enterButton, escapeButton, choices, priority)
        end
      end,
      onGameEditText = function(id, itemId, maxLength, text, writer, time)
        for i, callback in ipairs(context._callbacks.onGameEditText) do
          callback(id, itemId, maxLength, text, writer, time)
        end
      end,
      onAttackingCreatureChange = function(creature, oldCreature)
        for i, callback in ipairs(context._callbacks.onAttackingCreatureChange) do
          callback(creature, oldCreature)
        end
      end,
      onManaChange = function(player, mana, maxMana, oldMana, oldMaxMana)
        for i, callback in ipairs(context._callbacks.onManaChange) do
          callback(player, mana, maxMana, oldMana, oldMaxMana)
        end
      end,
      onAddItem = function(container, slot, item)
        for i, callback in ipairs(context._callbacks.onAddItem) do
          callback(container, slot, item)
        end
      end,
      onRemoveItem = function(container, slot, item)
        for i, callback in ipairs(context._callbacks.onRemoveItem) do
          callback(container, slot, item)
        end
      end,
      onStatesChange = function(player, states, oldStates)
        for i, callback in ipairs(context._callbacks.onStatesChange) do
          callback(player, states, oldStates)
        end
      end,
      onGroupSpellCooldown = function(iconId, duration)
        for i, callback in ipairs(context._callbacks.onGroupSpellCooldown) do
          callback(iconId, duration)
        end
      end,
      onSpellCooldown = function(iconId, duration)
        for i, callback in ipairs(context._callbacks.onSpellCooldown) do
          callback(iconId, duration)
        end
      end,
      onSpellCooldown = function(iconId, duration)
        for i, callback in ipairs(context._callbacks.onSpellCooldown) do
          callback(iconId, duration)
        end
      end,
      onInventoryChange = function(player, slot, item, oldItem)
        for i, callback in ipairs(context._callbacks.onInventoryChange) do
          callback(player, slot, item, oldItem)
        end
      end
    },
    saveAll = saveAll,
    saveModules = saveModules,
    context = context
  }
end