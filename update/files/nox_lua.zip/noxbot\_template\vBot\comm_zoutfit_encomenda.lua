-- NoxBot Private Script: Outfit Encomenda
noxCommunityScript(function(config)
  if type(config.enabled) ~= "boolean" then config.enabled = false end

-- TITULO
UI.Label(">> Custom Outfit <<"):setColor("yellow")

-- NÃO MEXER
config.outfitChanger = config.outfitChanger or {player:getOutfit()}
config.outfitChanger2 = config.outfitChanger2 or {player:getOutfit()}

-- UI TEXT EDIT
UI.TextEdit(config.outfitChanger.type, function(widget, newText)
  config.outfitChanger.type = newText
end)

-- UI BUTTON, TROCAR OUTFIT
UI.Button("Trocar Outfit",function()
  config.outfitChanger2 = player:getOutfit()
  setOutfit(config.outfitChanger)
end)

-- UI BUTTON, VOLTAR OUTFIT
UI.Button("Voltar Outfit",function()
  setOutfit(config.outfitChanger2)
end)

-- UI BUTTON, COPY OUTFIT
UI.Button("Salvar Cores Atuais",function()
  local oldType = config.outfitChanger.type
  config.outfitChanger = player:getOutfit()
  config.outfitChanger.type = oldType
end)

-- DESCOBRIR OUTFITS DA TELA
UI.Button("Pegar Types da Tela",function()
  local msg = ''
  for s, spec in pairs(getSpectators()) do
    if not spec:isMonster() then
      msg = msg .. spec:getName() .. " " .. spec:getOutfit().type .. ", "
    end
  end
  talkPrivate(player:getName(),msg)
end)

-- PARTY OUTFIT
UI.Label(">> Party Outfit <<"):setColor("yellow")
local pto = macro(12312313, "Outfit Encomenda",function()end)
onTalk(function(name, level, mode, text, channelId, pos)
  if not pto:isOn() then return end
  if channelId ~= getChannelId('Party') then return end
  print("Global onTalk - Name: "..name.." Level: "..level.." Mode: "..mode.." Text: "..text.." ChannelId: "..channelId..posText)
end)
end)